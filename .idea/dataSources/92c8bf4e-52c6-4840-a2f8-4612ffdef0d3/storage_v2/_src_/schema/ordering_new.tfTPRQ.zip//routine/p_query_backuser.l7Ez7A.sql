create
    definer = ordering@`%` procedure p_query_backuser(IN p_city_id int)
begin

    select user_id "用户ID",
           login_language "客户端版本",
           #city_id "城市ID",
           city_name "城市",
           base_area_id "基础区域ID",
           base_area_name "基础区域名称",
           #order_count,
           #order_fee,
           #commission_fee,
           #coupon_fee
           (case when commission_fee <= coupon_fee then "低价值" else "高价值" end) "价值分类",
           (case when order_count < 3 then "低" when order_count = 3 then "中" else "高" end) "频次分类",
           back_order_count "近30天有效订单数",
           back_order_fee "近30天有效订单金额",
           back_commission_fee "近30天有效订单商家抽佣金额",
           back_coupon_fee "近30天有效订单平台优惠券核销金额",
           (case when is_vip = 1 then "是" else "否" end) "是否会员"
    from stat_backuser
    where city_id = p_city_id
    order by 1;

end;

