create definer = ordering@`%` view view_order_log as
select `l`.`id`          AS `id`,
       `l`.`create_time` AS `create_time`,
       `l`.`type`        AS `type`,
       `l`.`oper_id`     AS `oper_id`,
       `l`.`relate_id`   AS `relate_id`,
       `l`.`desc`        AS `desc`
from `ordering_new`.`log` `l`
where (`l`.`type` in
       (1, 2, 3, 4, 5, 9, 20, 21, 34, 29, 31, 32, 40, 41, 1001, 1002, 1003, 1004, 1005, 1006, 1007, 1010, 1011, 1012,
        1017, 1018, 1019, 1119, 1129, 1022, 1023, 1024, 1029, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1039, 1040,
        1041, 1042, 1043, 1044, 1045, 1046, 1052, 1053, 1054, 1058, 1059, 1060, 1061, 1064, 1066, 1070, 1071, 1073,
        1076, 1077, 1084, 1091, 1092, 1093, 1095, 1096, 1097, 1098, 1099, 1100, 1101, 1102, 1103, 1104, 1105, 1106,
        1108, 1121, 1217, 2100, 5060, 8000, 1300, 9005, 9006, 13000));

-- comment on column view_order_log.relate_id not supported: 关联的ID

grant select on table view_order_log to thirdparty;

