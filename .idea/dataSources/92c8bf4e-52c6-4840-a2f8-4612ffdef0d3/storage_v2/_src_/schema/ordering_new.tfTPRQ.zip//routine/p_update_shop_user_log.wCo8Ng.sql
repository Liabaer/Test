create
    definer = ordering@`%` procedure p_update_shop_user_log(IN p_day varchar(10))
begin

    declare v_proc_begintime varchar(19);
    declare v_proc_endtime   varchar(19);
    declare v_proc_duration  int;
    declare v_step_begintime varchar(19);
    declare v_step_endtime   varchar(19);
    declare v_step_duration  int;

    declare v_begintime      varchar(19);
    declare v_endtime        varchar(19);


    set v_proc_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    #1 更新访问时间

    #处理神策日志表时间
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    set v_begintime = concat(p_day,' 00:00:00');
    set v_endtime   = date_format(now(),'%Y.%m.%d 23:59:59');
    call p_update_sensors_localtime(v_begintime,v_endtime,0,'',0);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_update_shop_user_log','update sensors localtime',0);


    #创建临时表，只存要处理的一天数据
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    drop table if exists events_shopclick_tmp;
    create temporary table events_shopclick_tmp
    (
        city_id         int         not null,
        shop_id         int         not null,
        user_id         int         not null,
        min_access_time varchar(20) not null,
        max_access_time varchar(20) not null
    );
    create index idx_events_shopclick_tmp_01 on events_shopclick_tmp(shop_id,user_id);
    set @v_sql = concat('
    insert into events_shopclick_tmp
    select city_id,shop_id,user_id,min(access_time),max(access_time)
    from sensors.events_shopclick
    where access_time >= concat(''',p_day,''', '' 00:00:00'')
      and access_time <  concat(''',p_day,''', '' 23:59:59'')
    group by city_id,shop_id,user_id;
    ');
    #select @v_sql;
    prepare stmt from @v_sql;
    execute stmt;
    deallocate prepare stmt;

    commit;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_update_shop_user_log','create temporary table events_shopclick_tmp',0);


    #1.1 更新old user

    #1.1.1 更新首次访问时间，如果没有首次访问时间，则更新为当天日志里最早的访问时间，是理论上不存在的情况
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    update shop_user_log l, events_shopclick_tmp t
    set l.first_access_time = t.min_access_time
    where l.shop_id = t.shop_id and l.user_id = t.user_id
      and (l.first_access_time is null or l.first_access_time = '' or l.first_access_time > t.min_access_time);
    commit;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_update_shop_user_log','update first_access_time',0);


    #1.1.2 更新末次访问时间
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    update shop_user_log l, events_shopclick_tmp t
    set l.last_access_time = t.max_access_time
    where l.shop_id = t.shop_id and l.user_id = t.user_id and l.last_access_time < t.max_access_time;
    commit;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_update_shop_user_log','update last_access_time',0);


    #1.2 插入new user
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    insert into shop_user_log(city_id,shop_id,user_id,first_access_time,last_access_time)
    select city_id,shop_id,user_id,min_access_time,max_access_time
    from events_shopclick_tmp t
    where not exists (select 1 from shop_user_log l
                      where t.shop_id = l.shop_id and t.user_id = l.user_id);
    commit;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_update_shop_user_log','insert new access user from sensors events',0);


    #2 更新下单时间

    #创建临时表，只存要处理的一天数据
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    drop table if exists order_tmp;
    create temporary table order_tmp
    (
        city_id         int         not null,
        shop_id         int         not null,
        user_id         int         not null,
        min_create_time varchar(20) not null,
        max_create_time varchar(20) not null
    );
    create index idx_order_tmp_01 on order_tmp(shop_id,user_id);
    set @v_sql = concat('
    insert into order_tmp
    select city_id,shop_id,user_id,min(create_time),max(create_time)
    from ordering.order o force index (order_create_time)
    where o.create_time >= concat(''',p_day,''', '' 00:00:00'')
      and o.create_time <  concat(''',p_day,''', '' 23:59:59'')
    group by city_id,shop_id,user_id;
    ');
    #select @v_sql;
    prepare stmt from @v_sql;
    execute stmt;
    deallocate prepare stmt;

    commit;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_update_shop_user_log','create temporary table order_tmp',0);


    #2.1 更新old user

    #2.1.1 更新首次下单时间，如果没有首次下单时间，则更新为当天日志里最早的下单时间
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    update shop_user_log l, order_tmp t
    set l.first_order_time = t.min_create_time
    where l.shop_id = t.shop_id and l.user_id = t.user_id
      and (l.first_order_time is null or l.first_order_time = '' or l.first_order_time > t.min_create_time);
    commit;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_update_shop_user_log','update first_order_time',0);


    #2.1.2 更新末次下单时间
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    update shop_user_log l, order_tmp t
    set l.last_order_time = t.max_create_time
    where l.shop_id = t.shop_id and l.user_id = t.user_id
      and (l.last_order_time is null or l.last_order_time = '' or l.last_order_time < t.max_create_time);
    commit;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_update_shop_user_log','update last_order_time',0);


    #2.2插入new user，未访问有下单，是理论上不存在的情况
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    insert into shop_user_log(city_id,shop_id,user_id,first_access_time,first_order_time,last_access_time,last_order_time)
    select city_id,shop_id,user_id,min_create_time,min_create_time,max_create_time,max_create_time
    from order_tmp t
    where not exists (select 1 from shop_user_log l
                      where t.shop_id = l.shop_id and t.user_id = l.user_id);
    commit;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_update_shop_user_log','insert new order user from order',0);


    #3.更新评价时间

    #创建临时表，只存要处理的一天数据
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    drop table if exists review_tmp;
    create temporary table review_tmp
    (
        shop_id     int         not null,
        user_id     int         not null,
        create_time varchar(20) not null
    );
    create index idx_review_tmp_01 on review_tmp(shop_id,user_id);
    set @v_sql = concat('
    insert into review_tmp
    select shop_id,user_id,max(create_time)
    from ordering.review r
    where r.create_time >= concat(''',p_day,''', '' 00:00:00'')
      and r.create_time <  concat(''',p_day,''', '' 23:59:59'')
    group by shop_id,user_id;
    ');
    #select @v_sql;
    prepare stmt from @v_sql;
    execute stmt;
    deallocate prepare stmt;

    commit;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_update_shop_user_log','create temporary table review_tmp',0);


    #3.1 更新old user

    #3.1.1 更新末次评价时间
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    update shop_user_log l, review_tmp t
    set l.last_review_time = t.create_time
    where l.shop_id = t.shop_id and l.user_id = t.user_id
      and (l.last_review_time is null or l.last_review_time = '' or l.last_review_time < t.create_time);
    commit;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_update_shop_user_log','update last_review_time',0);


    /*
    #3.2 插入new user，未访问未下单有评价，是理论上不存在的情况(不插入此类数据，难以解释)
    */


    #删除临时表
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    drop table if exists events_shopclick_tmp;
    drop table if exists order_tmp;
    drop table if exists review_tmp;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_update_shop_user_log','drop temporary table',0);


    set v_proc_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_proc_duration = timestampdiff(second,v_proc_begintime,v_proc_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_proc_begintime,v_proc_endtime,v_proc_duration,'p_update_shop_user_log',p_day,0);

end;

