create
    definer = ordering@`%` function f_calc_normalization(p_i decimal(10, 2), p_min decimal(10, 2), p_max decimal(10, 2)) returns decimal(10, 2)
begin

    declare v_normalization numeric(10,2);

    if (p_max <> p_min) then
        set v_normalization = round((p_i - p_min)/(p_max - p_min),2);
    else
        set v_normalization = 0.00;
    end if;

    return v_normalization;

end;

