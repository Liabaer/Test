create
    definer = ordering@`%` function f_get_localtime(p_city_id int, p_time varchar(19)) returns varchar(19)
begin

    declare v_timezone varchar(50);

    declare v_time varchar(19);

    select timezone into v_timezone
    from ordering.city
    where id = p_city_id;

    set v_time = date_format(convert_tz(p_time,'Asia/Shanghai',v_timezone),'%Y.%m.%d %H:%i:%s');

    return v_time;

end;

