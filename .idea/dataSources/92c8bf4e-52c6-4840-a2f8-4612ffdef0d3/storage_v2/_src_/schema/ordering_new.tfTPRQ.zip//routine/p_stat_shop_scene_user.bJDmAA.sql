create
    definer = ordering@`%` procedure p_stat_shop_scene_user(IN p_day varchar(10), IN p_city_id varchar(1000))
begin

    declare p_shop_id int;
    declare p_scene_id int;

    declare v_proc_begintime varchar(19);
    declare v_proc_endtime   varchar(19);
    declare v_proc_duration  int;
    declare v_step_begintime varchar(19);
    declare v_step_endtime   varchar(19);
    declare v_step_duration  int;

    set p_shop_id = -1;
    set p_scene_id = -1;


    set v_proc_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');


    #每个场景一段，都是不相关的事件

    #1.粉丝顾客：截止昨日，收藏店铺的顾客
    if (p_scene_id = -1 or p_scene_id = 1) then

    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    delete from stat_shop_scene_user
    where scene_id = 1
      and instr(concat(',',p_city_id,','),concat(',',city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','),concat(',',shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('delete 1|',p_city_id,'|',p_shop_id),0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    insert into stat_shop_scene_user(scene_id,city_id,shop_id,user_id,update_time)
    select 1 scene_id, s.city_id, f.shop_id, f.user_id, max(f.create_time)
    from ordering.fav f,
         ordering.shop s
    where f.create_time < date_format(date_add(p_day,interval 1 day),'%Y.%m.%d 00:00:00')
      and f.shop_id = s.id
      and instr(concat(',',p_city_id,','),concat(',',s.city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','),concat(',',f.shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end)
    group by s.city_id, f.shop_id, f.user_id;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('insert 1|',p_city_id,'|',p_shop_id),0);

    end if;


    #2.进店未下单新客：截止昨日，访问过店铺但是未下单的新顾客
    if (p_scene_id = -1 or p_scene_id = 2) then

    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    delete from stat_shop_scene_user
    where scene_id = 2
      and instr(concat(',',p_city_id,','),concat(',',city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','),concat(',',shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('delete 2|',p_city_id,'|',p_shop_id),0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    insert into stat_shop_scene_user(scene_id,city_id,shop_id,user_id,update_time)
    select 2 scene_id, city_id, shop_id, user_id, last_access_time
    from shop_user_log
    where last_access_time < date_format(date_add(p_day,interval 1 day),'%Y.%m.%d 00:00:00')
      and (first_order_time is null or first_order_time = '')
      and instr(concat(',',p_city_id,','),concat(',',city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','),concat(',',shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('insert 2|',p_city_id,'|',p_shop_id),0);

    end if;


    #3.好评顾客：截止昨日，最近30天80%以上的评价是好评（3星以及以上）的顾客
    if (p_scene_id = -1 or p_scene_id = 3) then

    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    delete from stat_shop_scene_user
    where scene_id = 3
      and instr(concat(',',p_city_id,','),concat(',',city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','),concat(',',shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('delete 3|',p_city_id,'|',p_shop_id),0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    insert into stat_shop_scene_user(scene_id,city_id,shop_id,user_id,update_time)
    select 3 scene_id, t.city_id, t.shop_id, t.user_id, t.last_review_time
    from
    (select s.city_id,
           r.shop_id,
           r.user_id,
           count(1) review_count,
           sum(case when r.service_attitude >= 3 then 1 else 0 end) goodreview_count,
           max(r.create_time) last_review_time
    from ordering.review r,
         ordering.shop s
    where r.create_time >= date_format(date_add(p_day,interval -30+1 day),'%Y.%m.%d 00:00:00')
      and r.create_time <  date_format(date_add(p_day,interval     1 day),'%Y.%m.%d 00:00:00')
      and r.shop_id = s.id
      and instr(concat(',',p_city_id,','),concat(',',s.city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','),concat(',',r.shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end)
    group by s.city_id,r.shop_id,r.user_id) t
    where t.goodreview_count/review_count > 0.8;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('insert 3|',p_city_id,'|',p_shop_id),0);

    end if;


    #4.差评顾客：截止昨日，最近30天，至少有过一条差评（3星以下）的顾客
    if (p_scene_id = -1 or p_scene_id = 4) then

    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    delete from stat_shop_scene_user
    where scene_id = 4
      and instr(concat(',',p_city_id,','), concat(',',city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','), concat(',',shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('delete 4|',p_city_id,'|',p_shop_id),0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    insert into stat_shop_scene_user(scene_id,city_id,shop_id,user_id,update_time)
    select 4 scene_id,
           s.city_id,
           r.shop_id,
           r.user_id,
           max(r.create_time) last_review_time
    from ordering.review r,
         ordering.shop s
    where r.create_time >= date_format(date_add(p_day,interval -30+1 day),'%Y.%m.%d 00:00:00')
      and r.create_time <  date_format(date_add(p_day,interval     1 day),'%Y.%m.%d 00:00:00')
      and r.shop_id = s.id
      and instr(concat(',',p_city_id,','),concat(',',s.city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','),concat(',',r.shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end)
      and r.service_attitude < 3
    group by s.city_id,r.shop_id,r.user_id;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('insert 4|',p_city_id,'|',p_shop_id),0);

    end if;


    #5.写内容的好评顾客：截止昨日，最近30天有完成订单并且给了有内容的好评（有文字或者图片，并且总评分在3星以及以上）的顾客
    if (p_scene_id = -1 or p_scene_id = 5) then

    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    delete from stat_shop_scene_user
    where scene_id = 5
      and instr(concat(',',p_city_id,','), concat(',',city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','), concat(',',shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('delete 5|',p_city_id,'|',p_shop_id),0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    insert into stat_shop_scene_user(scene_id,city_id,shop_id,user_id,update_time)
    select 5 scene_id,
           s.city_id,
           r.shop_id,
           r.user_id,
           max(r.create_time) last_review_time
    from ordering.review r,
         ordering.shop s
    where r.create_time >= date_format(date_add(p_day,interval -30+1 day),'%Y.%m.%d 00:00:00')
      and r.create_time <  date_format(date_add(p_day,interval     1 day),'%Y.%m.%d 00:00:00')
      and r.shop_id = s.id
      and instr(concat(',',p_city_id,','),concat(',',s.city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','),concat(',',r.shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end)
      and r.service_attitude >= 3
      and ((r.user_review is not null and r.user_review <> '')
           or
           (r.image is not null and r.image <> ''))
    group by s.city_id,r.shop_id,r.user_id;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('insert 5|',p_city_id,'|',p_shop_id),0);

    end if;


    #6.不评价顾客：截止昨日，最近30天有完成订单但是未主动评价的顾客
    if (p_scene_id = -1 or p_scene_id = 6) then

    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    delete from stat_shop_scene_user
    where scene_id = 6
      and instr(concat(',',p_city_id,','), concat(',',city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','), concat(',',shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end);

    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('delete 6|',p_city_id,'|',p_shop_id),0);


    insert into stat_shop_scene_user(scene_id,city_id,shop_id,user_id,update_time)
    select 6 scene_id,
           o.city_id,
           o.shop_id,
           o.user_id,
           max(o.create_time) last_review_time
    from ordering.order o force index (order_create_time)
    where o.create_time >= date_format(date_add(p_day,interval -30+1 day),'%Y.%m.%d 00:00:00')
      and o.create_time <  date_format(date_add(p_day,interval     1 day),'%Y.%m.%d 00:00:00')
      and instr(concat(',',p_city_id,','),concat(',',o.city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','),concat(',',o.shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end)
      and o.status = 4
      and not exists (select 1 from ordering.review r
                      where r.create_time >= date_format(date_add(p_day,interval -30+1 day),'%Y.%m.%d 00:00:00')
                        and r.create_time <  date_format(date_add(p_day,interval     1 day),'%Y.%m.%d 00:00:00')
                        and r.shop_id = o.shop_id
                        and r.user_id = o.user_id)
    group by o.city_id,o.shop_id,o.user_id;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('insert 6|',p_city_id,'|',p_shop_id),0);

    end if;


    #创建临时表处理最近30天和31-90天的数据
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    drop table if exists shop_user_order_last30day;
    create temporary table shop_user_order_last30day
    (
        city_id        int           not null,
        shop_id        int           not null,
        user_id        int           not null,
        order_count    int           not null,
        order_fee      numeric(10,2) not null
    );
    create index idx_shop_user_order_last30day_01 on shop_user_order_last30day(shop_id,user_id);

    set @v_sql = concat('
    insert into shop_user_order_last30day(city_id,shop_id,user_id,order_count,order_fee)
    select o.city_id,o.shop_id,o.user_id,count(1),sum(odb.order_fee - (odb.shop_order_fee_discount + odb.merchant_coupon_fee) - odb.credit_note)
    from ordering.order o force index (order_create_time),
         ordering.order_discount_balance odb
    where o.create_time >= date_format(date_add(''',p_day,''',interval -30+1 day),''%Y.%m.%d 06:00:00'')
      and o.create_time <  date_format(date_add(''',p_day,''',interval     1 day),''%Y.%m.%d 06:00:00'')
      and instr(concat('','',''',p_city_id,''','',''),concat('','',o.city_id,'','')) > (case when ''',p_city_id,''' = ''-1'' then -1 else 0 end)
      and instr(concat('','',''',p_shop_id,''','',''),concat('','',o.shop_id,'','')) > (case when ''',p_shop_id,''' = ''-1'' then -1 else 0 end)
      and o.status = 4
      and o.id = odb.order_id
    group by o.city_id,o.shop_id,o.user_id;
    ');
    #select @v_sql;
    prepare stmt from @v_sql;
    execute stmt;
    deallocate prepare stmt;

    #select count(1) from shop_user_order_last30day;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user','create temporary table shop_user_order_last30day',0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    drop table if exists shop_order_last30day;
    create temporary table shop_order_last30day
    (
        city_id            int           not null,
        shop_id            int           not null,
        order_count        int           not null,
        order_fee          numeric(10,2) not null,
        avg_order_count    numeric(10,2) not null,
        avg_order_fee      numeric(10,2) not null
    );
    create index idx_shop_order_last30day_01 on shop_order_last30day(shop_id);

    insert into shop_order_last30day(city_id,shop_id,order_count,order_fee,avg_order_count,avg_order_fee)
    select city_id,shop_id,sum(order_count),sum(order_fee),avg(order_count),sum(order_fee)/sum(order_count)
    from shop_user_order_last30day
    group by city_id,shop_id;

    #select count(1) from shop_order_last30day;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user','create temporary table shop_order_last30day',0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    drop table if exists shop_user_order_31to90day;
    create temporary table shop_user_order_31to90day
    (
        city_id        int           not null,
        shop_id        int           not null,
        user_id        int           not null,
        order_count    int           not null,
        order_fee      numeric(10,2) not null
    );
    create index idx_shop_user_order_31to90day_01 on shop_user_order_31to90day(shop_id,user_id);

    set @v_sql = concat('
    insert into shop_user_order_31to90day(city_id,shop_id,user_id,order_count,order_fee)
    select o.city_id,o.shop_id,o.user_id,count(1),sum(odb.order_fee - (odb.shop_order_fee_discount + odb.merchant_coupon_fee) - odb.credit_note)
    from ordering.order o force index (order_create_time),
         ordering.order_discount_balance odb
    where o.create_time >= date_format(date_add(''',p_day,''',interval -90+1 day),''%Y.%m.%d 06:00:00'')
      and o.create_time <  date_format(date_add(''',p_day,''',interval -30+1 day),''%Y.%m.%d 06:00:00'')
      and instr(concat('','',''',p_city_id,''','',''),concat('','',o.city_id,'','')) > (case when ''',p_city_id,''' = ''-1'' then -1 else 0 end)
      and instr(concat('','',''',p_shop_id,''','',''),concat('','',o.shop_id,'','')) > (case when ''',p_shop_id,''' = ''-1'' then -1 else 0 end)
      and o.status = 4
      and o.id = odb.order_id
    group by o.city_id,o.shop_id,o.user_id;
    ');
    #select @v_sql;
    prepare stmt from @v_sql;
    execute stmt;
    deallocate prepare stmt;

    #select count(1) from shop_user_order_31to90day;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user','create temporary table shop_user_order_31to90day',0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    drop table if exists shop_order_31to90day;
    create temporary table shop_order_31to90day
    (
        city_id            int           not null,
        shop_id            int           not null,
        order_count        int           not null,
        order_fee          numeric(10,2) not null,
        avg_order_count    numeric(10,2) not null,
        avg_order_fee      numeric(10,2) not null
    );
    create index idx_shop_order_31to90day_01 on shop_order_31to90day(shop_id);
    insert into shop_order_31to90day(city_id,shop_id,order_count,order_fee,avg_order_count,avg_order_fee)
    select city_id,shop_id,sum(order_count),sum(order_fee),avg(order_count),sum(order_fee)/sum(order_count)
    from shop_user_order_31to90day
    group by city_id,shop_id;

    #select count(1) from shop_order_31to90day;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user','create temporary table shop_order_31to90day',0);


    #7.高消费熟客：最近30天的下单数和单均价高于店铺平均值
    if (p_scene_id = -1 or p_scene_id = 7) then

    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    delete from stat_shop_scene_user
    where scene_id = 7
      and instr(concat(',',p_city_id,','), concat(',',city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','), concat(',',shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('delete 7|',p_city_id,'|',p_shop_id),0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    insert into stat_shop_scene_user(scene_id,city_id,shop_id,user_id,update_time)
    select 7,city_id, shop_id, user_id, concat(p_day,' 23:59:59')
    from shop_user_order_last30day u
    where exists (select 1 from shop_order_last30day s
                  where u.order_count > s.avg_order_count
                    and u.order_fee/u.order_count > s.avg_order_fee
                    and u.shop_id = s.shop_id);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('insert 7|',p_city_id,'|',p_shop_id),0);

    end if;


    #8.需重点关怀的流失熟客：最近90-30天的下单数和单均价高于店铺平均值，但是最近30天没有下单
    if (p_scene_id = -1 or p_scene_id = 8) then

    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    delete from stat_shop_scene_user
    where scene_id = 8
      and instr(concat(',',p_city_id,','), concat(',',city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','), concat(',',shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('delete 8|',p_city_id,'|',p_shop_id),0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    insert into stat_shop_scene_user(scene_id,city_id,shop_id,user_id,update_time)
    select 8,city_id, shop_id, user_id, concat(p_day,' 23:59:59')
    from shop_user_order_31to90day u
    where exists (select 1 from shop_order_31to90day s
                  where u.order_count > s.avg_order_count
                    and u.order_fee/u.order_count > s.avg_order_fee
                    and u.shop_id = s.shop_id)
      and not exists(select 1 from shop_user_order_last30day s30
                     where u.shop_id = s30.shop_id
                       and u.user_id = s30.user_id);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('insert 8|',p_city_id,'|',p_shop_id),0);

    end if;


    #9.需要重点发展的潜力顾客：最近30天的下单数低于店铺平均，但是单均价高于店铺平均
    if (p_scene_id = -1 or p_scene_id = 9) then

    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    delete from stat_shop_scene_user
    where scene_id = 9
      and instr(concat(',',p_city_id,','), concat(',',city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','), concat(',',shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('delete 9|',p_city_id,'|',p_shop_id),0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    insert into stat_shop_scene_user(scene_id,city_id,shop_id,user_id,update_time)
    select 9,city_id, shop_id, user_id, concat(p_day,' 23:59:59')
    from shop_user_order_last30day u
    where exists (select 1 from shop_order_last30day s
                  where u.order_count < s.avg_order_count
                    and u.order_fee/u.order_count > s.avg_order_fee
                    and u.shop_id = s.shop_id);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('insert 9|',p_city_id,'|',p_shop_id),0);

    end if;


    #10.需要重点挽留的流失顾客：最近90-30天的下单数低于店铺平均，但是单均价高于店铺平均值，并且最近30天没有下单
    if (p_scene_id = -1 or p_scene_id = 10) then

    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    delete from stat_shop_scene_user
    where scene_id = 10
      and instr(concat(',',p_city_id,','), concat(',',city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','), concat(',',shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('delete 10|',p_city_id,'|',p_shop_id),0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    insert into stat_shop_scene_user(scene_id,city_id,shop_id,user_id,update_time)
    select 10,city_id, shop_id, user_id, concat(p_day,' 23:59:59')
    from shop_user_order_31to90day u
    where exists (select 1 from shop_order_31to90day s
                  where u.order_count < s.avg_order_count
                    and u.order_fee/u.order_count > s.avg_order_fee
                    and u.shop_id = s.shop_id)
      and not exists(select 1 from shop_user_order_last30day s30
                     where u.shop_id = s30.shop_id
                       and u.user_id = s30.user_id);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('insert 10|',p_city_id,'|',p_shop_id),0);

    end if;


    #11.低消费熟客：最近30天下单数高于平均，但是单均价低于平均
    if (p_scene_id = -1 or p_scene_id = 11) then

    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    delete from stat_shop_scene_user
    where scene_id = 11
      and instr(concat(',',p_city_id,','), concat(',',city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','), concat(',',shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('delete 11|',p_city_id,'|',p_shop_id),0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    insert into stat_shop_scene_user(scene_id,city_id,shop_id,user_id,update_time)
    select 11,city_id, shop_id, user_id, concat(p_day,' 23:59:59')
    from shop_user_order_last30day u
    where exists (select 1 from shop_order_last30day s
                  where u.order_count > s.avg_order_count
                    and u.order_fee/u.order_count < s.avg_order_fee
                    and u.shop_id = s.shop_id);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('insert 11|',p_city_id,'|',p_shop_id),0);

    end if;


    #12.需要一般关怀的流失熟客：最近90-30天的下单数高于店铺平均，但是单均价低于店铺平均值，并且最近30天没有下单
    if (p_scene_id = -1 or p_scene_id = 12) then

    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    delete from stat_shop_scene_user
    where scene_id = 12
      and instr(concat(',',p_city_id,','), concat(',',city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','), concat(',',shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('delete 12|',p_city_id,'|',p_shop_id),0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    insert into stat_shop_scene_user(scene_id,city_id,shop_id,user_id,update_time)
    select 12,city_id, shop_id, user_id, concat(p_day,' 23:59:59')
    from shop_user_order_31to90day u
    where exists (select 1 from shop_order_31to90day s
                  where u.order_count > s.avg_order_count
                    and u.order_fee/u.order_count < s.avg_order_fee
                    and u.shop_id = s.shop_id)
      and not exists(select 1 from shop_user_order_last30day s30
                     where u.shop_id = s30.shop_id
                       and u.user_id = s30.user_id);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user',concat('insert 12|',p_city_id,'|',p_shop_id),0);

    end if;


    #删除临时表
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    drop table if exists shop_user_order_last30day;
    drop table if exists shop_order_last30day;
    drop table if exists shop_user_order_31to90day;
    drop table if exists shop_order_31to90day;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_scene_user','drop temporary table',0);


    set v_proc_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_proc_duration = timestampdiff(second,v_proc_begintime,v_proc_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_proc_begintime,v_proc_endtime,v_proc_duration,'p_stat_shop_scene_user',concat(p_day,'|',p_scene_id,'|',p_city_id,'|',p_shop_id),0);


end;

