create
    definer = ordering@`%` function f_get_courier_area_id(p_courier_id int, p_area_type int) returns int
begin

    declare v_base_area_id int;
    declare v_fence_area_id int;
    declare v_area_id int;

        select base_area_id, base_area_id into v_area_id, v_base_area_id
        from ordering.base_area_map
        where relate_type = 2
          and relate_id = p_courier_id
        order by update_time desc
        limit 1;

    if (p_area_type = 2) then

        select fence_area_id, fence_area_id into v_area_id, v_fence_area_id
        from ordering.base_area_use_level
        where type in (2,3)
          and level = 1
          and base_area_id = v_base_area_id
        order by update_time desc
        limit 1;

    end if;

    return v_area_id;

end;

