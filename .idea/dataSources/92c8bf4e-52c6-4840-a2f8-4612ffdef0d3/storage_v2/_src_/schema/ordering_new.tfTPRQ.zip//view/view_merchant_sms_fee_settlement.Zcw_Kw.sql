create definer = ordering@`%` view view_merchant_sms_fee_settlement as
select `ordering_new`.`merchant_sms_send_log`.`city_id`                              AS `city_id`,
       `ordering_new`.`merchant_sms_send_log`.`shop_id`                              AS `shop_id`,
       sum(`ordering_new`.`merchant_sms_send_log`.`fee`)                             AS `fee_total`,
       date_format(`ordering_new`.`merchant_sms_send_log`.`create_time`, '%Y.%m.%d') AS `day`
from `ordering_new`.`merchant_sms_send_log`
group by `ordering_new`.`merchant_sms_send_log`.`shop_id`, `day`;

