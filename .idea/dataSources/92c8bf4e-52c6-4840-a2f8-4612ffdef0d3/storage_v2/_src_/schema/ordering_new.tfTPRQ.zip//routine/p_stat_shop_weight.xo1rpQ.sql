create
    definer = ordering@`%` procedure p_stat_shop_weight(IN p_day varchar(10), IN p_city_id varchar(1000))
begin

    declare p_shop_id int;

    declare v_proc_begintime varchar(19);
    declare v_proc_endtime   varchar(19);
    declare v_proc_duration  int;
    declare v_step_begintime varchar(19);
    declare v_step_endtime   varchar(19);
    declare v_step_duration  int;

    set p_shop_id = -1;


    set v_proc_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');


    #计算曝光、进店、下单量及用户数
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    drop table if exists stat_shop_weight_tmp;
    create temporary table stat_shop_weight_tmp
    (
        #city_id                               int                     not null,
        #base_area_id                          int                     not null,
        shop_id                               int                     not null,
        exposure_count                        int           default 0 not null,
        access_count                          int           default 0 not null,
        order_count                           int           default 0 not null,
        gmv                                   numeric(10,2) default 0 not null,
        exposure_user_count                   int           default 0 not null,
        access_user_count                     int           default 0 not null,
        order_user_count                      int           default 0 not null,
        review_count                          int           default 0 not null,
        goodreview_count                      int           default 0 not null
    );
    create index idx_stat_shop_weight_tmp_01 on stat_shop_weight_tmp(shop_id);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_weight','create temporary table stat_shop_weight_tmp',0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    set @v_sql = concat('
    insert into stat_shop_weight_tmp(#city_id,
                                     #base_area_id,
                                     shop_id,
                                     exposure_count,
                                     exposure_user_count)
    select #e.city_id,
           #f_get_shop_area_id(e.shop_id,1),
           e.shop_id,
           count(1),
           count(distinct e.user_id)
    from sensors.events_shopexposure e
    where e.exposure_time >= date_format(date_add(''',p_day,''',interval -90+1 day),''%Y.%m.%d 00:00:00'')
      and e.exposure_time <  date_format(date_add(''',p_day,''',interval     1 day),''%Y.%m.%d 00:00:00'')
      and instr(concat('','',''',p_city_id,''','',''),concat('','',e.city_id,'','')) > (case when ''',p_city_id,''' = ''-1'' then -1 else 0 end)
      and instr(concat('','',''',p_shop_id,''','',''),concat('','',e.shop_id,'','')) > (case when ''',p_shop_id,''' = ''-1'' then -1 else 0 end)
    group by #e.city_id,
             #f_get_shop_area_id(e.shop_id,1),
             e.shop_id;
    ');
    #select @v_sql;
    prepare stmt from @v_sql;
    execute stmt;
    deallocate prepare stmt;
    #select count(1) from stat_shop_weight_tmp;
    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_weight','insert exposure count',0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    set @v_sql = concat('
    insert into stat_shop_weight_tmp(#city_id,
                                     #base_area_id,
                                     shop_id,
                                     access_count,
                                     access_user_count)
    select #e.city_id,
           #f_get_shop_area_id(e.shop_id,1),
           e.shop_id,
           count(1),
           count(distinct e.user_id)
    from sensors.events_shopclick e
    where e.access_time >= date_format(date_add(''',p_day,''',interval -90+1 day),''%Y.%m.%d 00:00:00'')
      and e.access_time <  date_format(date_add(''',p_day,''',interval     1 day),''%Y.%m.%d 00:00:00'')
      and instr(concat('','',''',p_city_id,''','',''),concat('','',e.city_id,'','')) > (case when ''',p_city_id,''' = ''-1'' then -1 else 0 end)
      and instr(concat('','',''',p_shop_id,''','',''),concat('','',e.shop_id,'','')) > (case when ''',p_shop_id,''' = ''-1'' then -1 else 0 end)
    group by #e.city_id,
             #f_get_shop_area_id(e.shop_id,1),
             e.shop_id;
    ');
    #select @v_sql;
    prepare stmt from @v_sql;
    execute stmt;
    deallocate prepare stmt;
    #select count(1) from stat_shop_weight_tmp;
    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_weight','insert access count',0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    set @v_sql = concat('
    insert into stat_shop_weight_tmp(#city_id,
                                     #base_area_id,
                                     shop_id,
                                     order_count,
                                     gmv,
                                     order_user_count)
    select #o.city_id,
           #f_get_shop_area_id(o.shop_id,1),
           o.shop_id,
           count(1),
           f_calc_order_gmv(o.id),
           count(distinct o.user_id)
    from ordering.order o force index (order_create_time)
    where o.create_time >= date_format(date_add(''',p_day,''',interval -90+1 day),''%Y.%m.%d 00:00:00'')
      and o.create_time <  date_format(date_add(''',p_day,''',interval     1 day),''%Y.%m.%d 00:00:00'')
      and instr(concat('','',''',p_city_id,''','',''),concat('','',o.city_id,'','')) > (case when ''',p_city_id,''' = ''-1'' then -1 else 0 end)
      and instr(concat('','',''',p_shop_id,''','',''),concat('','',o.shop_id,'','')) > (case when ''',p_shop_id,''' = ''-1'' then -1 else 0 end)
      and o.status = 4
    group by #o.city_id,
             #f_get_shop_area_id(o.shop_id,1),
             o.shop_id;
    ');
    #select @v_sql;
    prepare stmt from @v_sql;
    execute stmt;
    deallocate prepare stmt;
    #select count(1) from stat_shop_weight_tmp;
    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_weight','insert order count',0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    set @v_sql = concat('
    insert into stat_shop_weight_tmp(#city_id,
                                     #base_area_id,
                                     shop_id,
                                     review_count,
                                     goodreview_count)
    select #s.city_id,
           #f_get_shop_area_id(r.shop_id,1),
           r.shop_id,
           count(1),
           sum(case when service_attitude >= 3 then 1 else 0 end)
    from ordering.review r,
         ordering.shop s
    where r.create_time >= date_format(date_add(''',p_day,''',interval -90+1 day),''%Y.%m.%d 00:00:00'')
      and r.create_time <  date_format(date_add(''',p_day,''',interval     1 day),''%Y.%m.%d 00:00:00'')
      and r.shop_id = s.id
      and instr(concat('','',''',p_city_id,''','',''),concat('','',s.city_id,'','')) > (case when ''',p_city_id,''' = ''-1'' then -1 else 0 end)
      and instr(concat('','',''',p_shop_id,''','',''),concat('','',r.shop_id,'','')) > (case when ''',p_shop_id,''' = ''-1'' then -1 else 0 end)
    group by #s.city_id,
             #f_get_shop_area_id(r.shop_id,1),
             r.shop_id;
    ');
    #select @v_sql;
    prepare stmt from @v_sql;
    execute stmt;
    deallocate prepare stmt;
    #select count(1) from stat_shop_weight_tmp;
    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_weight','insert review count',0);


    #删除数据
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    delete from stat_shop_weight
    where instr(concat(',',p_city_id,','),concat(',',city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','),concat(',',shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_weight',concat('delete ',p_city_id,'|',p_shop_id),0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    insert into stat_shop_weight
    (
        city_id,
        base_area_id,
        shop_id,
        exposure_count,
        access_count,
        order_count,
        gmv,
        exposure_user_count,
        access_user_count,
        order_user_count,
        review_count,
        goodreview_count,
        update_time
    )
    select s.city_id,
           f_get_shop_area_id(shop_id,1),
           shop_id,
           sum(exposure_count),
           sum(access_count),
           sum(order_count),
           sum(gmv),
           sum(exposure_user_count),
           sum(access_user_count),
           sum(order_user_count),
           sum(review_count),
           sum(goodreview_count),
           concat(p_day,' 23:59:59')
    from stat_shop_weight_tmp t,
         ordering.shop s
    where t.shop_id = s.id
    group by s.city_id,
             f_get_shop_area_id(shop_id,1),
             shop_id;
    #select count(1) from stat_shop_weight;
    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_weight','insert into stat_shop_weight from stat_shop_weight_tmp',0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    update stat_shop_weight
    set exposure2order_rate  = (case when exposure_user_count > 0 then round(100.00*order_user_count/exposure_user_count,2)  else 0.00 end),
        exposure2access_rate = (case when exposure_user_count > 0 then round(100.00*access_user_count/exposure_user_count,2) else 0.00 end),
        access2order_rate    = (case when access_user_count   > 0 then round(100.00*order_user_count/access_user_count,2)    else 0.00 end),
        goodreview_rate      = (case when review_count        > 0 then round(100.00*goodreview_count/review_count,2)         else 0.00 end)
    where instr(concat(',',p_city_id,','),concat(',',city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','),concat(',',shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_weight','calc rate',0);


    #计算区域数据(归一化公式的最小值和最大值)
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    drop table if exists stat_area_weight_tmp;
    create temporary table stat_area_weight_tmp
    (
        city_id                     int                     not null,
        base_area_id                int                     not null,
        min_order_count             int           default 0 not null,
        max_order_count             int           default 0 not null,
        min_gmv                     numeric(10,2) default 0 not null,
        max_gmv                     numeric(10,2) default 0 not null,
        min_exposure2order_rate     numeric(10,2) default 0 not null,
        max_exposure2order_rate     numeric(10,2) default 0 not null,
        min_exposure2access_rate    numeric(10,2) default 0 not null,
        max_exposure2access_rate    numeric(10,2) default 0 not null,
        min_access2order_rate       numeric(10,2) default 0 not null,
        max_access2order_rate       numeric(10,2) default 0 not null,
        min_goodreview_rate         numeric(10,2) default 0 not null,
        max_goodreview_rate         numeric(10,2) default 0 not null
    );
    create index idx_stat_area_weight_tmp_01 on stat_area_weight_tmp(city_id,base_area_id);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_weight','create temporary table stat_area_weight_tmp',0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    insert into stat_area_weight_tmp
    (
        city_id,
        base_area_id,
        min_order_count,
        max_order_count,
        min_gmv,
        max_gmv,
        min_exposure2order_rate,
        max_exposure2order_rate,
        min_exposure2access_rate,
        max_exposure2access_rate,
        min_access2order_rate,
        max_access2order_rate,
        min_goodreview_rate,
        max_goodreview_rate
    )
    select city_id,
           base_area_id,
           min(order_count),
           max(order_count),
           min(gmv),
           max(gmv),
           min(exposure2order_rate),
           max(exposure2order_rate),
           min(exposure2access_rate),
           max(exposure2access_rate),
           min(access2order_rate),
           max(access2order_rate),
           min(goodreview_rate),
           max(goodreview_rate)
    from stat_shop_weight
    where instr(concat(',',p_city_id,','),concat(',',city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','),concat(',',shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end)
    group by city_id,
             base_area_id;
    #select count(1) from stat_area_weight_tmp;
    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_weight','calc min and max',0);


    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    #按基础单元区域归一化
    update stat_shop_weight s, stat_area_weight_tmp a
    set s.order_count_normalization          = f_calc_normalization(s.order_count,a.min_order_count,a.max_order_count),
        s.gmv_normalization                  = f_calc_normalization(s.gmv,a.min_gmv,a.max_gmv),
        s.exposure2order_rate_normalization  = f_calc_normalization(s.exposure2order_rate,a.min_exposure2order_rate,a.max_exposure2order_rate),
        s.exposure2access_rate_normalization = f_calc_normalization(s.exposure2access_rate,a.min_exposure2access_rate,a.max_exposure2access_rate),
        s.access2order_rate_normalization    = f_calc_normalization(s.access2order_rate,a.min_access2order_rate,a.max_access2order_rate),
        s.goodreview_rate_normalization      = f_calc_normalization(s.goodreview_rate,a.min_goodreview_rate,a.max_goodreview_rate)
    where instr(concat(',',p_city_id,','),concat(',',s.city_id,',')) > (case when p_city_id = -1 then -1 else 0 end)
      and instr(concat(',',p_shop_id,','),concat(',',s.shop_id,',')) > (case when p_shop_id = -1 then -1 else 0 end)
      and s.city_id = a.city_id
      and s.base_area_id = a.base_area_id;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_weight','calc normalization',0);


    #删除临时表
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    drop table if exists stat_shop_weight_tmp;
    drop table if exists stat_area_weight_tmp;

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_shop_weight','drop temporary table',0);


    set v_proc_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_proc_duration = timestampdiff(second,v_proc_begintime,v_proc_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_proc_begintime,v_proc_endtime,v_proc_duration,'p_stat_shop_weight',concat(p_day,'|',p_city_id,'|',p_shop_id),0);


end;

