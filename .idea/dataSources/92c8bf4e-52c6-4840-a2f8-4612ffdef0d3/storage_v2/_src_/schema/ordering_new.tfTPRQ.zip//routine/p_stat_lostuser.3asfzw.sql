create
    definer = ordering@`%` procedure p_stat_lostuser(IN p_day varchar(10), IN p_city_id int)
begin

    declare v_begintime1  varchar(19);
    declare v_endtime1    varchar(19);

    declare v_begintime2  varchar(19);
    declare v_endtime2    varchar(19);

    declare v_begintime3  varchar(19);
    declare v_endtime3    varchar(19);

    #T-60 到 T-30天
    set v_begintime1 = date_format(date_add(p_day, interval -60+1 day),'%Y.%m.%d 06:00:00');
    set v_endtime1   = date_format(date_add(p_day, interval -30+1 day),'%Y.%m.%d 06:00:00');

    #T-30天 到 昨天
    set v_begintime2 = date_format(date_add(p_day, interval -30+1 day),'%Y.%m.%d 06:00:00');
    set v_endtime2   = date_format(date_add(p_day, interval     1 day),'%Y.%m.%d 06:00:00');

    #T-7天 到 昨天
    set v_begintime3 = date_format(date_add(p_day, interval -7+1 day),'%Y.%m.%d 06:00:00');
    set v_endtime3   = date_format(date_add(p_day, interval    1 day),'%Y.%m.%d 06:00:00');


    #近60-31天有下单的用户
    drop table if exists tmp_user1;
    create temporary table tmp_user1
    (
        user_id        int not null,
        order_count    int not null,
        order_fee      decimal(15,2) not null,
        commission_fee decimal(15,2) not null,
        coupon_fee     decimal(15,2) not null
    );
    create index idx_tmp_user1_01 on tmp_user1(user_id);
    set @v_sql = concat('insert into tmp_user1
    select o.user_id,
           count(1),
           sum(odb.order_fee),
           sum(odb.commission_fee),
           sum(odb.coupon_fee)
    from ordering.order o force index(order_create_time),
         ordering.order_discount_balance odb,
         ordering.user u
    where o.create_time >= ''',v_begintime1,'''
      and o.create_time <  ''',v_endtime1,'''
      and o.status = 4
      and o.id = odb.order_id
      and o.user_id = u.id
      and u.city_id = ',p_city_id,'
    group by o.user_id');
    #select @v_sql;
    prepare stmt from @v_sql;
    execute stmt;
    deallocate prepare stmt;
    #select count(1) from tmp_user1;


    #近30天有下单的用户
    drop table if exists tmp_user2;
    create temporary table tmp_user2
    (
        user_id int not null
    );
    create index idx_tmp_user2_01 on tmp_user2(user_id);
    set @v_sql = concat('insert into tmp_user2
    select distinct user_id
    from ordering.order o force index(order_create_time),
         ordering.user u
    where o.create_time >= ''',v_begintime2,'''
      and o.create_time <  ''',v_endtime2,'''
      and o.status = 4
      and o.user_id = u.id
      and u.city_id = ',p_city_id,';');
    #select @v_sql;
    prepare stmt from @v_sql;
    execute stmt;
    deallocate prepare stmt;
    #select count(1) from tmp_user2;


    #近30天未下单，近60天内有下单 的用户
    drop table if exists tmp_user1_minus_user2;
    create temporary table tmp_user1_minus_user2
    (
        user_id        int not null,
        order_count    int not null,
        order_fee      decimal(15,2) not null,
        commission_fee decimal(15,2) not null,
        coupon_fee     decimal(15,2) not null
    );
    create index idx_tmp_user1_minus_user2_01 on tmp_user1_minus_user2(user_id);
    set @v_sql = concat('insert into tmp_user1_minus_user2
    select user_id,
           order_count,
           order_fee,
           commission_fee,
           coupon_fee
    from tmp_user1 t1
    where not exists (select 1 from tmp_user2 t2
                      where t1.user_id = t2.user_id);');
    #select @v_sql;
    prepare stmt from @v_sql;
    execute stmt;
    deallocate prepare stmt;
    #select count(1) from tmp_user1_minus_user2;


    #((上周：近30天未下单，近60天内有下单) and 本周有下单用户) 的用户
    drop table if exists tmp_user3;
    create temporary table tmp_user3
    (
        user_id        int not null,
        order_count    int not null,
        order_fee      decimal(15,2) not null,
        commission_fee decimal(15,2) not null,
        coupon_fee     decimal(15,2) not null
    );
    create index idx_tmp_user3_01 on tmp_user3(user_id);
    set @v_sql = concat('insert into tmp_user3
    select o.user_id,
           count(1),
           sum(odb.order_fee),
           sum(odb.commission_fee),
           sum(odb.coupon_fee)
    from ordering.order o force index(order_create_time),
         ordering.order_discount_balance odb
    where o.create_time >= ''',v_begintime3,'''
      and o.create_time <  ''',v_endtime3,'''
      and o.status = 4
      and o.id = odb.order_id
      and exists (select 1 from stat_lostuser sl where o.user_id = sl.user_id and sl.city_id = ',p_city_id,')
    group by o.user_id');
    #select @v_sql;
    prepare stmt from @v_sql;
    execute stmt;
    deallocate prepare stmt;
    #select count(1) from tmp_user3;


    #召回用户近60天数据
    drop table if exists tmp_user4;
    create temporary table tmp_user4
    (
        user_id        int not null,
        order_count    int not null,
        order_fee      decimal(15,2) not null,
        commission_fee decimal(15,2) not null,
        coupon_fee     decimal(15,2) not null
    );
    create index idx_tmp_user4_01 on tmp_user4(user_id);
    set @v_sql = concat('insert into tmp_user4
    select o.user_id,
           count(1),
           sum(odb.order_fee),
           sum(odb.commission_fee),
           sum(odb.coupon_fee)
    from ordering.order o force index(order_create_time),
         ordering.order_discount_balance odb
    where o.create_time >= ''',v_begintime1,'''
      and o.create_time <  ''',v_endtime3,'''
      and o.status = 4
      and o.id = odb.order_id
      and exists (select 1 from tmp_user3 t3 where o.user_id = t3.user_id)
    group by o.user_id');
    #select @v_sql;
    prepare stmt from @v_sql;
    execute stmt;
    deallocate prepare stmt;
    #select count(1) from tmp_user4;


    #更新召回用户数据
    delete from stat_backuser where city_id = p_city_id;

    insert into stat_backuser(
    user_id,
    login_language,
    city_id,
    city_name,
    base_area_id,
    base_area_name,
    order_count,
    order_fee,
    commission_fee,
    coupon_fee,
    back_order_count,
    back_order_fee,
    back_commission_fee,
    back_coupon_fee,
    is_vip,
    update_time
    )
    select t4.user_id,
           u.login_language,
           u.city_id,
           c.name,
           ordering_dw.f_get_user_area_id(t4.user_id,1),
           ordering_dw.f_get_user_area_name(t4.user_id,1),
           t4.order_count,
           t4.order_fee,
           t4.commission_fee,
           t4.coupon_fee,
           t3.order_count,
           t3.order_fee,
           t3.commission_fee,
           t3.coupon_fee,
           (case when (uvs.expire_time > date_format(now(),'%Y.%m.%d 00:00:00')) then 1 else 0 end),
           concat(p_day,' 23:59:59')
    from tmp_user4 t4
    join tmp_user3 t3 on t4.user_id = t3.user_id
    join ordering.user u on t4.user_id = u.id and u.status = 1 and u.city_id = p_city_id
    join ordering.city c on u.city_id = c.id and c.id = p_city_id
    left join ordering.user_vip_status uvs on t4.user_id = uvs.user_id and uvs.city_id = p_city_id;


    #更新流失用户数据
    delete from stat_lostuser where city_id = p_city_id;

    insert into stat_lostuser(
    user_id,
    login_language,
    city_id,
    city_name,
    base_area_id,
    base_area_name,
    order_count,
    order_fee,
    commission_fee,
    coupon_fee,
    update_time
    )
    select t.user_id,
           u.login_language,
           u.city_id,
           c.name,
           ordering_dw.f_get_user_area_id(t.user_id,1),
           ordering_dw.f_get_user_area_name(t.user_id,1),
           t.order_count,
           t.order_fee,
           t.commission_fee,
           t.coupon_fee,
           concat(p_day,' 23:59:59')
    from tmp_user1_minus_user2 t,
         ordering.user u,
         ordering.city c
    where t.user_id = u.id
      and u.status = 1
      and u.city_id = p_city_id
      and u.city_id = c.id
      and c.id = p_city_id;

/*
select * from tmp_user1;
select * from tmp_user2;
select * from tmp_user1_minus_user2;
select * from tmp_user3;
select * from tmp_user4;
*/

drop table if exists tmp_user1;
drop table if exists tmp_user2;
drop table if exists tmp_user1_minus_user2;
drop table if exists tmp_user3;
drop table if exists tmp_user4;

end;

