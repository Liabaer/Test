create
    definer = ordering@`%` procedure p_statdata_clear()
begin

    declare v_proc_begintime varchar(19);
    declare v_proc_endtime   varchar(19);
    declare v_proc_duration  int;
    declare v_step_begintime varchar(19);
    declare v_step_endtime   varchar(19);
    declare v_step_duration  int;

    declare v_deletetime    varchar(19);

    declare v_tablename     varchar(100);
    declare v_timecolumn    varchar(100);
    declare v_timeformat    int;
    declare v_keepdays      int;

    declare v_sql varchar(1000);
		declare v_rowcount int;
		declare v_delcount int;

    declare table_done boolean default 0;
    declare cur_table cursor for
    select tablename, timecolumn, timeformat, keepdays
    from table_config
    where keepdays > 0
    order by 1;
    declare continue handler for not found set table_done = 1;


    set v_proc_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');


    open cur_table;

        fetch next from cur_table into v_tablename, v_timecolumn, v_timeformat, v_keepdays;
        #select table_done;

        while (table_done <> 1) do
        select v_tablename, v_timecolumn, v_timeformat, v_keepdays;


            if (v_timeformat = 11) then
                set v_deletetime = date_format(date_add(now(),interval -v_keepdays day),'%Y.%m.%d');
            elseif (v_timeformat = 12) then
                set v_deletetime = date_format(date_add(now(),interval -v_keepdays day),'%Y.%m');
            else
                set v_deletetime = date_format(date_add(now(),interval -v_keepdays day),'%Y.%m.%d 00:00:00');
            end if;
            select v_deletetime;


            set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

            set v_rowcount = 1;
						set v_delcount = 0;

            set @v_sql = concat('delete from ',v_tablename,' where ',v_timecolumn,' < ''',v_deletetime,''' limit 2000;');
            select @v_sql;
            prepare stmt1 from @v_sql;

            del_loop:loop

                execute stmt1;
                select row_count() into v_rowcount;
                select v_rowcount;
								set v_delcount = v_delcount + v_rowcount;
                select v_delcount;

                if (v_rowcount = 0) then
                    leave del_loop;
                end if;

            end loop del_loop;

            deallocate prepare stmt1;

            set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
            set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

            insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
            values (date_format(now(),'%Y.%m.%d'),v_step_begintime,v_step_endtime,v_step_duration,'p_statdata_clear',concat('[',v_delcount,' rows]',@v_sql),0);


            fetch next from cur_table into v_tablename, v_timecolumn, v_timeformat, v_keepdays;

        end while;

    close cur_table;


    set v_proc_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_proc_duration = timestampdiff(second,v_proc_begintime,v_proc_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (date_format(now(),'%Y.%m.%d'),v_proc_begintime,v_proc_endtime,v_proc_duration,'p_statdata_clear','',0);

end;

