create
    definer = ordering@`%` procedure p_query_lostuser(IN p_city_id int)
begin

    select user_id "用户ID",
           login_language "客户端版本",
           #city_id "城市ID",
           city_name "城市",
           base_area_id "基础区域ID",
           base_area_name "基础区域名称",
           #order_count,
           #order_fee,
           #commission_fee,
           #coupon_fee
           (case when commission_fee <= coupon_fee then "低价值" else "高价值" end) "价值分类",
           (case when order_count < 3 then "低" when order_count = 3 then "中" else "高" end) "频次分类"
    from stat_lostuser
    where city_id = p_city_id
    order by 1;

end;

