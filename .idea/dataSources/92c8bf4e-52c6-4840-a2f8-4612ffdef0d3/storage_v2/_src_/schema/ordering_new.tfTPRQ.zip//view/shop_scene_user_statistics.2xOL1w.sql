create definer = ordering@`%` view shop_scene_user_statistics as
select `ordering_new`.`stat_shop_scene_user`.`scene_id`    AS `scene_id`,
       `ordering_new`.`stat_shop_scene_user`.`shop_id`     AS `shop_id`,
       `ordering_new`.`stat_shop_scene_user`.`user_id`     AS `user_id`,
       `ordering_new`.`stat_shop_scene_user`.`update_time` AS `update_time`
from `ordering_new`.`stat_shop_scene_user`;

