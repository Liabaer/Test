create
    definer = ordering@`%` procedure p_update_sensors_localtime(IN p_begintime varchar(19), IN p_endtime varchar(19),
                                                                IN p_step int, IN p_tablename varchar(100),
                                                                IN p_forceupdate int)
begin

    declare v_curtime varchar(19);

    if (p_step = 1) then
        set v_curtime = date_format(p_begintime,'%Y.%m.%d');
    elseif (p_step = 2) then
        set v_curtime = date_format(p_begintime,'%Y.%m');
    else
        set v_curtime = date_format(p_begintime,'%Y.%m.%d %H');
    end if;
    #select v_curtime;

    while (v_curtime <= p_endtime) do

        if (p_tablename = '' or p_tablename = 'events_shopexposure') then

            set @v_sql = concat('update sensors.events_shopexposure set exposure_time = f_get_localtime(city_id,original_time) where original_time like ''',v_curtime,'%''');

            if p_forceupdate = 0 then
                set @v_sql = concat(@v_sql,' and (exposure_time is null or exposure_time = '''')');
            end if;

            #select @v_sql;
            prepare stmt from @v_sql;
            execute stmt;
            deallocate prepare stmt;

            commit;

        end if;

        if (p_tablename = '' or p_tablename = 'events_shopclick') then

            set @v_sql = concat('update sensors.events_shopclick set access_time = f_get_localtime(city_id,original_time) where original_time like ''',v_curtime,'%''');

            if p_forceupdate = 0 then
                set @v_sql = concat(@v_sql,' and (access_time is null or access_time = '''')');
            end if;

            #select @v_sql;
            prepare stmt from @v_sql;
            execute stmt;
            deallocate prepare stmt;

            commit;

        end if;

        if (p_tablename = '' or p_tablename = 'events_appstart') then

            set @v_sql = concat('update sensors.events_appstart set start_time = f_get_localtime(city_id,original_time) where original_time like ''',v_curtime,'%''');

            if p_forceupdate = 0 then
                set @v_sql = concat(@v_sql,' and (start_time is null or start_time = '''')');
            end if;

            #select @v_sql;
            prepare stmt from @v_sql;
            execute stmt;
            deallocate prepare stmt;

            commit;

        end if;

        if (p_step = 1) then
            set v_curtime = date_format(date_add(concat(v_curtime,' 00:00:00'),interval 1 day),'%Y.%m.%d');
        elseif (p_step = 2) then
            set v_curtime = date_format(date_add(concat(v_curtime,'.01 00:00:00'),interval 1 month),'%Y.%m');
                else
            set v_curtime = date_format(date_add(concat(v_curtime,':00:00'),interval 1 hour),'%Y.%m.%d %H');
        end if;
        #select v_curtime;

    end while;

end;

