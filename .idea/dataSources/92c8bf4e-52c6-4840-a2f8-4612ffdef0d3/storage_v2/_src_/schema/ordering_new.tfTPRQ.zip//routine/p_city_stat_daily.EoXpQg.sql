create
    definer = ordering@`%` procedure p_city_stat_daily()
begin

    declare v_proc_begintime varchar(19);
    declare v_proc_endtime   varchar(19);
    declare v_proc_duration  int;
    declare v_step_begintime varchar(19);
    declare v_step_endtime   varchar(19);
    declare v_step_duration  int;

    declare v_statday  varchar(10);

    declare v_procname varchar(100);
    declare v_taskperiod varchar(1);
    declare v_taskday varchar(2);
    declare v_tasktime varchar(19);
    declare v_taskcity int;

    declare v_city_id   varchar(1000);
    declare v_localtime varchar(19);

    declare v_sql varchar(1000);

    declare task_done boolean default 0;
    declare cur_task cursor for
    select procname, taskperiod, taskday, tasktime, taskcity
    from task_config
    order by 2;
    declare continue handler for not found set task_done = 1;


    set v_proc_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');


    open cur_task;

        fetch next from cur_task into v_procname, v_taskperiod, v_taskday, v_tasktime, v_taskcity;
        #select task_done;

        while (task_done <> 1) do
        #select v_procname, v_taskperiod, v_taskday, v_tasktime, v_taskcity;

            #墨本尔时间到tasktime执行不区分城市
            if (v_taskcity = -1) then
            begin

                set v_localtime = date_format(convert_tz(v_proc_begintime,'UTC','Australia/Melbourne'),'%Y.%m.%d %H:00:00');

                if ((substr(v_localtime,12,8) = v_tasktime and v_taskperiod = 'D')
                    or
                    (substr(v_localtime,12,8) = v_tasktime and v_taskperiod = 'W' and weekday(v_localtime) = v_taskday)
                    or
                    (substr(v_localtime,12,8) = v_tasktime and v_taskperiod = 'M' and substr(v_localtime,9,2) = v_taskday))
                then

                    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');
                    set v_statday = date_format(date_add(v_localtime, interval -1 day),'%Y.%m.%d');
                    set @v_sql = concat('call ',v_procname,'(''',v_statday,''',',v_taskcity,');');
                    #select @v_sql;
                    prepare stmt1 from @v_sql;
                    execute stmt1;
                    deallocate prepare stmt1;

                    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
                    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

                    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
                    values (date_format(now(),'%Y.%m.%d'),v_step_begintime,v_step_endtime,v_step_duration,'p_city_stat_daily',concat('[',v_localtime,']','call ',v_procname,'(''',v_statday,''',',v_taskcity,');'),0);
                end if;

            end;
            #0-每个城市本地时间到tasktime才执行,N-只在city_id=N的城市本地时间到tasktime才执行
            else

                begin
                    declare city_done boolean default 0;
                    #顺序执行多个城市可能会超过1小时，那么判断是否执行当前城市的任务的localtime不能取now()应该取v_proc_begintime
                    declare cur_city cursor for
                    select group_concat(id), date_format(convert_tz(v_proc_begintime,'UTC',timezone),'%Y.%m.%d %H:00:00')
                    from ordering.city
                    where id = (case when v_taskcity = 0 then id else v_taskcity end)
                    group by date_format(convert_tz(v_proc_begintime,'UTC',timezone),'%Y.%m.%d %H:00:00');
                    declare continue handler for not found set city_done = 1;

                    open cur_city;

                        fetch next from cur_city into v_city_id, v_localtime;
                        #select city_done;

                        while (city_done <> 1) do
                        #select v_city_id, v_localtime;

                            if ((substr(v_localtime,12,8) = v_tasktime and v_taskperiod = 'D')
                                or
                                (substr(v_localtime,12,8) = v_tasktime and v_taskperiod = 'W' and weekday(v_localtime) = v_taskday)
                                or
                                (substr(v_localtime,12,8) = v_tasktime and v_taskperiod = 'M' and substr(v_localtime,9,2) = v_taskday))
                            then

                                set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

                                set v_statday = date_format(date_add(v_localtime, interval -1 day),'%Y.%m.%d');

                                set @v_sql = concat('call ',v_procname,'(''',v_statday,''',''',v_city_id,''');');
                                #select @v_sql;
                                prepare stmt1 from @v_sql;
                                execute stmt1;
                                deallocate prepare stmt1;

                                set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
                                set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

                                insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
                                values (date_format(now(),'%Y.%m.%d'),v_step_begintime,v_step_endtime,v_step_duration,'p_city_stat_daily',concat('[',v_localtime,']','call ',v_procname,'(''',v_statday,''',''',v_city_id,''');'),0);

                            end if;

                            fetch next from cur_city into v_city_id, v_localtime;

                        end while;

                    close cur_city;

                end;

            end if;

            fetch next from cur_task into v_procname, v_taskperiod, v_taskday, v_tasktime, v_taskcity;

        end while;

    close cur_task;


    set v_proc_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_proc_duration = timestampdiff(second,v_proc_begintime,v_proc_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (date_format(now(),'%Y.%m.%d'),v_proc_begintime,v_proc_endtime,v_proc_duration,'p_city_stat_daily','',0);

end;

