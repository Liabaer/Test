create
    definer = ordering@`%` procedure p_stat_daily(IN p_day varchar(10))
begin

    declare v_proc_begintime varchar(19);
    declare v_proc_endtime   varchar(19);
    declare v_proc_duration  int;
    declare v_step_begintime varchar(19);
    declare v_step_endtime   varchar(19);
    declare v_step_duration  int;

    declare v_begintime      varchar(19);
    declare v_endtime        varchar(19);


    set v_proc_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');


    #过期数据清理
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    call p_statdata_clear();

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_step_begintime,v_step_endtime,v_step_duration,'p_statdata_clear','',0);


    set v_proc_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_proc_duration = timestampdiff(second,v_proc_begintime,v_proc_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_day,v_proc_begintime,v_proc_endtime,v_proc_duration,'p_stat_daily',p_day,0);

end;

