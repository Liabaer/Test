create
    definer = ordering@`%` function f_calc_order_gmv(p_order_id int) returns decimal(10, 2)
begin

    declare v_order_gmv numeric(10,2);

    select odb.order_fee - (odb.shop_order_fee_discount + odb.merchant_coupon_fee) - odb.credit_note + odb.delivery_fee into v_order_gmv
    from ordering.order_discount_balance odb
    where order_id = p_order_id;

    select ifnull(v_order_gmv,0) + ifnull(t.transaction_fee,0) into v_order_gmv
    from ordering.trade t
    where t.order_id = p_order_id
      and t.is_valid = 1;

    return v_order_gmv;

end;

