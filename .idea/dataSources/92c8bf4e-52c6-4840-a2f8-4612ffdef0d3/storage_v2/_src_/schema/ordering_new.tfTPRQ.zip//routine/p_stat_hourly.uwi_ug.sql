create
    definer = ordering@`%` procedure p_stat_hourly(IN p_hour varchar(10))
begin

    declare v_proc_begintime varchar(19);
    declare v_proc_endtime   varchar(19);
    declare v_proc_duration  int;
    declare v_step_begintime varchar(19);
    declare v_step_endtime   varchar(19);
    declare v_step_duration  int;

    declare v_begintime      varchar(19);
    declare v_endtime        varchar(19);


    set v_proc_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');


    #更新shop_user_log
    set v_step_begintime = date_format(now(),'%Y.%m.%d %H:%i:%s');

    call p_update_shop_user_log(p_hour);

    set v_step_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_step_duration = timestampdiff(second,v_step_begintime,v_step_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_hour,v_step_begintime,v_step_endtime,v_step_duration,'p_stat_hourly',concat('call p_update_shop_user_log(''',p_hour,''')'),0);


    set v_proc_endtime = date_format(now(),'%Y.%m.%d %H:%i:%s');
    set v_proc_duration = timestampdiff(second,v_proc_begintime,v_proc_endtime);

    insert into job_execute_log(statday,begintime,endtime,duration,procname,stepdesc,status)
    values (p_hour,v_proc_begintime,v_proc_endtime,v_proc_duration,'p_stat_hourly',p_hour,0);

end;

