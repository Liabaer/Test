create view view_base_area_map_v2 as
select `ordering`.`base_area_map`.`id`             AS `id`,
       `ordering`.`base_area_map`.`relate_id`      AS `relate_id`,
       `ordering`.`base_area_map`.`relate_type`    AS `relate_type`,
       `ordering`.`base_area_map`.`base_area_id`   AS `base_area_id`,
       `ordering`.`base_area_map`.`base_area_type` AS `base_area_type`,
       `ordering`.`base_area_map`.`base_area_name` AS `base_area_name`,
       `ordering`.`base_area_map`.`city_id`        AS `city_id`,
       `ordering`.`base_area_map`.`create_time`    AS `create_time`,
       `ordering`.`base_area_map`.`update_time`    AS `update_time`
from `ordering`.`base_area_map`;

-- comment on column view_base_area_map_v2.relate_id not supported: 关联的使用场景的id

-- comment on column view_base_area_map_v2.relate_type not supported: 关联的使用场景的类型

-- comment on column view_base_area_map_v2.base_area_id not supported: 关联的基础单元区域id

-- comment on column view_base_area_map_v2.base_area_type not supported: 关联的基础单元区域类型

-- comment on column view_base_area_map_v2.base_area_name not supported: 关联的基础单元区域名称

-- comment on column view_base_area_map_v2.city_id not supported: 城市ID

-- comment on column view_base_area_map_v2.create_time not supported: 创建时间

-- comment on column view_base_area_map_v2.update_time not supported: 更新时间

