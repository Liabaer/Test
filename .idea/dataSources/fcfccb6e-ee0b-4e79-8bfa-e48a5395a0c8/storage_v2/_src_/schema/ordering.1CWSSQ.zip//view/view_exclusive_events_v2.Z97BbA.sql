create view view_exclusive_events_v2 as
select `ordering`.`exclusive_events`.`id`                           AS `id`,
       `ordering`.`exclusive_events`.`name`                         AS `name`,
       `ordering`.`exclusive_events`.`user_participate_times_limit` AS `user_participate_times_limit`,
       `ordering`.`exclusive_events`.`priority`                     AS `priority`,
       `ordering`.`exclusive_events`.`start_time`                   AS `start_time`,
       `ordering`.`exclusive_events`.`end_time`                     AS `end_time`,
       `ordering`.`exclusive_events`.`header_img`                   AS `header_img`,
       `ordering`.`exclusive_events`.`header_img_en`                AS `header_img_en`,
       `ordering`.`exclusive_events`.`background_img`               AS `background_img`,
       `ordering`.`exclusive_events`.`background_img_en`            AS `background_img_en`,
       `ordering`.`exclusive_events`.`footer_img`                   AS `footer_img`,
       `ordering`.`exclusive_events`.`footer_img_en`                AS `footer_img_en`,
       `ordering`.`exclusive_events`.`coupon_id_list`               AS `coupon_id_list`,
       `ordering`.`exclusive_events`.`merchant_coupon_id_list`      AS `merchant_coupon_id_list`,
       `ordering`.`exclusive_events`.`is_valid`                     AS `is_valid`,
       `ordering`.`exclusive_events`.`city_id`                      AS `city_id`,
       `ordering`.`exclusive_events`.`create_time`                  AS `create_time`,
       `ordering`.`exclusive_events`.`update_time`                  AS `update_time`
from `ordering`.`exclusive_events`;

