create view view_setting_shop_v2 as
select `ordering`.`setting_shop`.`id`                 AS `id`,
       `ordering`.`setting_shop`.`key`                AS `key`,
       `ordering`.`setting_shop`.`value`              AS `value`,
       `ordering`.`setting_shop`.`city_id`            AS `city_id`,
       `ordering`.`setting_shop`.`is_confirm_receipt` AS `is_confirm_receipt`
from `ordering`.`setting_shop`;

-- comment on column view_setting_shop_v2.is_confirm_receipt not supported: 是否需要确认收货 0-否 1-是

