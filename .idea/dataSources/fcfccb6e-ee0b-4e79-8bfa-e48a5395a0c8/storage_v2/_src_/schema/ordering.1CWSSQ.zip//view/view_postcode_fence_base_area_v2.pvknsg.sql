create view view_postcode_fence_base_area_v2 as
select `pfba`.`id`              AS `id`,
       `pfba`.`type`            AS `type`,
       `pfba`.`name`            AS `name`,
       `pfba`.`location`        AS `location`,
       `pfba`.`location_point`  AS `location_point`,
       `pfba`.`range`           AS `range`,
       `pfba`.`range_polygon`   AS `range_polygon`,
       `pfba`.`is_use_shop`     AS `is_use_shop`,
       `pfba`.`is_use_user`     AS `is_use_user`,
       `pfba`.`is_use_delivery` AS `is_use_delivery`,
       `pfba`.`is_del`          AS `is_del`,
       `pfba`.`city_id`         AS `city_id`,
       `pfba`.`create_time`     AS `create_time`,
       `pfba`.`update_time`     AS `update_time`
from `ordering`.`postcode_fence_base_area` `pfba`;

-- comment on column view_postcode_fence_base_area_v2.type not supported: 区域类型

-- comment on column view_postcode_fence_base_area_v2.name not supported: 基础单元区域名称

-- comment on column view_postcode_fence_base_area_v2.location not supported: 基础单元区域地点

-- comment on column view_postcode_fence_base_area_v2.location_point not supported: 中心点-point格式

-- comment on column view_postcode_fence_base_area_v2.`range` not supported: 基础单元区域范围经纬度

-- comment on column view_postcode_fence_base_area_v2.range_polygon not supported: 范围-polygon格式

-- comment on column view_postcode_fence_base_area_v2.is_use_shop not supported: 是否有被商家类型的区域使用

-- comment on column view_postcode_fence_base_area_v2.is_use_user not supported: 是否有被用户类型的区域使用

-- comment on column view_postcode_fence_base_area_v2.is_use_delivery not supported: 是否有被配送类型的区域使用

-- comment on column view_postcode_fence_base_area_v2.is_del not supported: 是否删除

-- comment on column view_postcode_fence_base_area_v2.city_id not supported: 城市id

-- comment on column view_postcode_fence_base_area_v2.create_time not supported: 创建时间

-- comment on column view_postcode_fence_base_area_v2.update_time not supported: 更新时间

