create view view_city as
select `c`.`id`                   AS `id`,
       `c`.`name`                 AS `name`,
       `c`.`name_en`              AS `name_en`,
       `c`.`country_id`           AS `country_id`,
       `c`.`country_name`         AS `country_name`,
       `c`.`country_name_en`      AS `country_name_en`,
       `c`.`country_iso_code`     AS `country_iso_code`,
       `c`.`country_calling_code` AS `country_calling_code`,
       `c`.`currency`             AS `currency`,
       `c`.`currency_symbol`      AS `currency_symbol`,
       `c`.`currency_symbol_abbr` AS `currency_symbol_abbr`,
       `c`.`domain`               AS `domain`,
       `c`.`timezone_diff`        AS `timezone_diff`,
       `c`.`location_bounds_ne`   AS `location_bounds_ne`,
       `c`.`location_bounds_sw`   AS `location_bounds_sw`,
       `c`.`ranges`               AS `ranges`
from `ordering`.`city` `c`;

-- comment on column view_city.country_id not supported: 国家id

-- comment on column view_city.country_name not supported: 国家名称

-- comment on column view_city.country_name_en not supported: 国家英文名称

-- comment on column view_city.country_iso_code not supported: 国家ISO码

-- comment on column view_city.country_calling_code not supported: 国家区号

-- comment on column view_city.currency not supported: 国家货币, AUD, USD etc.

-- comment on column view_city.currency_symbol not supported: 国家货币符号, AU$, US$, etc.

-- comment on column view_city.currency_symbol_abbr not supported: 国家货币符号缩写, $, etc.

-- comment on column view_city.location_bounds_ne not supported: Google地图的城市范围

-- comment on column view_city.location_bounds_sw not supported: Google地图的城市范围

-- comment on column view_city.ranges not supported: 范围

