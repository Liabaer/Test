create view view_courier_perk_match_log as
select `ordering`.`courier_perk_match_log`.`id`          AS `id`,
       `ordering`.`courier_perk_match_log`.`order_id`    AS `order_id`,
       `ordering`.`courier_perk_match_log`.`courier_id`  AS `courier_id`,
       `ordering`.`courier_perk_match_log`.`perk_id`     AS `perk_id`,
       `ordering`.`courier_perk_match_log`.`rule_id`     AS `rule_id`,
       `ordering`.`courier_perk_match_log`.`reward_fee`  AS `reward_fee`,
       `ordering`.`courier_perk_match_log`.`remark`      AS `remark`,
       `ordering`.`courier_perk_match_log`.`plan_info`   AS `plan_info`,
       `ordering`.`courier_perk_match_log`.`create_time` AS `create_time`
from `ordering`.`courier_perk_match_log`;

-- comment on column view_courier_perk_match_log.perk_id not supported: 补贴方案ID

-- comment on column view_courier_perk_match_log.rule_id not supported: 具体规则ID

-- comment on column view_courier_perk_match_log.reward_fee not supported: 奖励金额

-- comment on column view_courier_perk_match_log.remark not supported: 备注

-- comment on column view_courier_perk_match_log.plan_info not supported: 补贴规则

