create view view_tags_v2 as
select `t`.`id`            AS `id`,
       `t`.`name`          AS `name`,
       `t`.`name_en`       AS `name_en`,
       `t`.`type`          AS `type`,
       `t`.`is_background` AS `is_background`,
       `t`.`city_id`       AS `city_id`,
       `t`.`create_time`   AS `create_time`,
       `t`.`create_by`     AS `create_by`,
       `t`.`update_time`   AS `update_time`,
       `t`.`update_by`     AS `update_by`,
       `t`.`is_deleted`    AS `is_deleted`
from `ordering`.`shop_tag` `t`;

-- comment on column view_tags_v2.name not supported: 标签的中文名

-- comment on column view_tags_v2.name_en not supported: 标签的英文名

-- comment on column view_tags_v2.type not supported: 标签类型，现只有普通和系统标签两种

-- comment on column view_tags_v2.is_background not supported: 前后台标签，0代表前台标签，1代表后台标签

-- comment on column view_tags_v2.city_id not supported: 城市id

-- comment on column view_tags_v2.is_deleted not supported: 是否删除该标签

