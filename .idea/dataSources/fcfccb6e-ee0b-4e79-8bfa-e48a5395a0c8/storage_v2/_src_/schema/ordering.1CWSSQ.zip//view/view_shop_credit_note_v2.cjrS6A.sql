create view view_shop_credit_note_v2 as
select `scn`.`id`               AS `id`,
       `scn`.`city_id`          AS `city_id`,
       `scn`.`scene`            AS `scene`,
       `scn`.`type`             AS `type`,
       `scn`.`shop_id`          AS `shop_id`,
       `scn`.`shop_name`        AS `shop_name`,
       `scn`.`order_id`         AS `order_id`,
       `scn`.`amount`           AS `amount`,
       `scn`.`cash_amount`      AS `cash_amount`,
       `scn`.`coupon_amount`    AS `coupon_amount`,
       `scn`.`refund_reason_id` AS `refund_reason_id`,
       `scn`.`refund_reason`    AS `refund_reason`,
       `scn`.`coupon_scope`     AS `coupon_scope`,
       `scn`.`coupon_id`        AS `coupon_id`,
       `scn`.`user_coupon_id`   AS `user_coupon_id`,
       `scn`.`refund_channel`   AS `refund_channel`,
       `scn`.`remark`           AS `remark`,
       `scn`.`status`           AS `status`,
       `scn`.`is_valid`         AS `is_valid`,
       `scn`.`audit_by`         AS `audit_by`,
       `scn`.`audit_by_name`    AS `audit_by_name`,
       `scn`.`audit_at`         AS `audit_at`,
       `scn`.`created_by`       AS `created_by`,
       `scn`.`created_by_name`  AS `created_by_name`,
       `scn`.`created_at`       AS `created_at`
from `ordering`.`shop_credit_note` `scn`;

-- comment on column view_shop_credit_note_v2.city_id not supported: 城市id

-- comment on column view_shop_credit_note_v2.scene not supported: 业务场景，0外卖，1堂食

-- comment on column view_shop_credit_note_v2.type not supported: 类型, 0部分退款, 1补差价

-- comment on column view_shop_credit_note_v2.shop_id not supported: 商家id

-- comment on column view_shop_credit_note_v2.shop_name not supported: 商家名称

-- comment on column view_shop_credit_note_v2.order_id not supported: 订单id

-- comment on column view_shop_credit_note_v2.amount not supported: 金额

-- comment on column view_shop_credit_note_v2.cash_amount not supported: 退款现金金额

-- comment on column view_shop_credit_note_v2.coupon_amount not supported: 退款优惠券金额

-- comment on column view_shop_credit_note_v2.refund_reason_id not supported: 退款原因id

-- comment on column view_shop_credit_note_v2.refund_reason not supported: 退款原因

-- comment on column view_shop_credit_note_v2.coupon_scope not supported: 发放优惠券范围，0全部商家，1订单商家

-- comment on column view_shop_credit_note_v2.coupon_id not supported: 优惠券id

-- comment on column view_shop_credit_note_v2.user_coupon_id not supported: 用户优惠券id

-- comment on column view_shop_credit_note_v2.refund_channel not supported: 退款方式

-- comment on column view_shop_credit_note_v2.remark not supported: 备注信息

-- comment on column view_shop_credit_note_v2.status not supported: 审核状态，0已取消，1审核中，2已通过，3已驳回

-- comment on column view_shop_credit_note_v2.is_valid not supported: 是否有效, 0无效，1有效

-- comment on column view_shop_credit_note_v2.audit_by not supported: 审核人

-- comment on column view_shop_credit_note_v2.audit_by_name not supported: 申请人名称

-- comment on column view_shop_credit_note_v2.audit_at not supported: 创建时间

-- comment on column view_shop_credit_note_v2.created_by not supported: 申请人

-- comment on column view_shop_credit_note_v2.created_by_name not supported: 申请人名称

-- comment on column view_shop_credit_note_v2.created_at not supported: 创建时间

