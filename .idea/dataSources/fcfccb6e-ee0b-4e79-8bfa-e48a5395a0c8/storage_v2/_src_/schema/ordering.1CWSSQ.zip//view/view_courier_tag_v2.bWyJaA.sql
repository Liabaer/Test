create view view_courier_tag_v2 as
select `ordering`.`courier_tag`.`id`          AS `id`,
       `ordering`.`courier_tag`.`name`        AS `name`,
       `ordering`.`courier_tag`.`city_id`     AS `city_id`,
       `ordering`.`courier_tag`.`type`        AS `type`,
       `ordering`.`courier_tag`.`rule`        AS `rule`,
       `ordering`.`courier_tag`.`create_time` AS `create_time`,
       `ordering`.`courier_tag`.`update_time` AS `update_time`,
       `ordering`.`courier_tag`.`create_by`   AS `create_by`,
       `ordering`.`courier_tag`.`update_by`   AS `update_by`,
       `ordering`.`courier_tag`.`is_del`      AS `is_del`
from `ordering`.`courier_tag`;

-- comment on column view_courier_tag_v2.name not supported: 配送员标签名

-- comment on column view_courier_tag_v2.city_id not supported: 城市id

-- comment on column view_courier_tag_v2.type not supported: 1代表excel文件导入的能够直接查询出来的用户id,2代表时规则类型,用户是按照规则筛选出来的

-- comment on column view_courier_tag_v2.rule not supported: 如果type为2,则该字段保存的是规则,json格式的对象,type为1默认为空字符串

-- comment on column view_courier_tag_v2.create_time not supported: 创建时间

-- comment on column view_courier_tag_v2.update_time not supported: 更新时间

-- comment on column view_courier_tag_v2.create_by not supported: 创建者

-- comment on column view_courier_tag_v2.update_by not supported: 修改者

-- comment on column view_courier_tag_v2.is_del not supported: 是否删除

