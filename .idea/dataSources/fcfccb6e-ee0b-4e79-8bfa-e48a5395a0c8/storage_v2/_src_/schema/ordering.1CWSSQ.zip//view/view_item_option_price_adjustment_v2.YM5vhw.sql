create view view_item_option_price_adjustment_v2 as
select `iopa`.`id`             AS `id`,
       `iopa`.`shop_id`        AS `shop_id`,
       `iopa`.`item_id`        AS `item_id`,
       `iopa`.`item_option_id` AS `item_option_id`,
       `iopa`.`adjust_price`   AS `adjust_price`
from `ordering`.`item_option_price_adjustment` `iopa`;

-- comment on column view_item_option_price_adjustment_v2.shop_id not supported: 商家id

-- comment on column view_item_option_price_adjustment_v2.item_id not supported: 商品id

-- comment on column view_item_option_price_adjustment_v2.item_option_id not supported: 商品选项id

-- comment on column view_item_option_price_adjustment_v2.adjust_price not supported: 调整金额，正数为涨价，负数为降价

