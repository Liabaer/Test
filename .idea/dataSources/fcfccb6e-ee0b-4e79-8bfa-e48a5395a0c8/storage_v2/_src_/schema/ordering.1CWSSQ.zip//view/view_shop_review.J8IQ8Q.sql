create view view_shop_review as
select `r`.`id`               AS `id`,
       `r`.`order_id`         AS `order_id`,
       `r`.`user_id`          AS `user_id`,
       `r`.`shop_id`          AS `shop_id`,
       `r`.`taste`            AS `taste`,
       `r`.`service_attitude` AS `overall_experience`,
       `r`.`user_review`      AS `review`,
       `r`.`create_time`      AS `create_time`
from `ordering`.`review` `r`
where (`r`.`status` = 0);

