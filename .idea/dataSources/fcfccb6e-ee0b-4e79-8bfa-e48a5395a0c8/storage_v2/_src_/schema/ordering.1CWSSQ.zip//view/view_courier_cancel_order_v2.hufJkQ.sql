create view view_courier_cancel_order_v2 as
select `ordering`.`courier_cancel_order`.`id`                   AS `id`,
       `ordering`.`courier_cancel_order`.`order_id`             AS `order_id`,
       `ordering`.`courier_cancel_order`.`courier_id`           AS `courier_id`,
       `ordering`.`courier_cancel_order`.`courier_display_name` AS `courier_display_name`,
       `ordering`.`courier_cancel_order`.`location`             AS `location`,
       `ordering`.`courier_cancel_order`.`city_id`              AS `city_id`,
       `ordering`.`courier_cancel_order`.`create_time`          AS `create_time`,
       `ordering`.`courier_cancel_order`.`update_time`          AS `update_time`,
       `ordering`.`courier_cancel_order`.`order_confirmed_time` AS `order_confirmed_time`,
       `ordering`.`courier_cancel_order`.`order_is_ready`       AS `order_is_ready`,
       `ordering`.`courier_cancel_order`.`app_language`         AS `app_language`,
       `ordering`.`courier_cancel_order`.`reason_id`            AS `reason_id`,
       `ordering`.`courier_cancel_order`.`reason`               AS `reason`,
       `ordering`.`courier_cancel_order`.`remark`               AS `remark`,
       `ordering`.`courier_cancel_order`.`status`               AS `status`,
       `ordering`.`courier_cancel_order`.`is_del`               AS `is_del`
from `ordering`.`courier_cancel_order`;

-- comment on column view_courier_cancel_order_v2.courier_display_name not supported: 配送员display_name

-- comment on column view_courier_cancel_order_v2.location not supported: 配送员申请撤单坐标

-- comment on column view_courier_cancel_order_v2.order_confirmed_time not supported: 总台确认时间

-- comment on column view_courier_cancel_order_v2.order_is_ready not supported: 餐已好/餐未好

-- comment on column view_courier_cancel_order_v2.app_language not supported: app语言

-- comment on column view_courier_cancel_order_v2.reason_id not supported: 配送员申请撤单原因id

-- comment on column view_courier_cancel_order_v2.reason not supported: 配送员申请撤单写的文案

-- comment on column view_courier_cancel_order_v2.remark not supported: 客服对待撤单的操作备注

-- comment on column view_courier_cancel_order_v2.status not supported: 当前撤销订单状态

