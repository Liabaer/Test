create view view_admin_v2 as
select `a`.`id`                     AS `id`,
       `a`.`login_name`             AS `login_name`,
       `a`.`role`                   AS `role`,
       `a`.`shop_area_id`           AS `shop_area_id`,
       `a`.`city_id`                AS `city_id`,
       `a`.`phone_number`           AS `phone_number`,
       `a`.`job_number`             AS `job_number`,
       `a`.`job_title`              AS `job_title`,
       `a`.`customer_service_group` AS `customer_service_group`,
       `a`.`create_time`            AS `create_time`
from `ordering`.`admin` `a`;

-- comment on column view_admin_v2.job_number not supported: 工号

-- comment on column view_admin_v2.job_title not supported: 职位

-- comment on column view_admin_v2.customer_service_group not supported: 管理员客服组

