create view view_shop_settlement_transfer_item_v2 as
select `ordering`.`shop_settlement_transfer_item`.`id`          AS `id`,
       `ordering`.`shop_settlement_transfer_item`.`city_id`     AS `city_id`,
       `ordering`.`shop_settlement_transfer_item`.`transfer_id` AS `transfer_id`,
       `ordering`.`shop_settlement_transfer_item`.`shop_id`     AS `shop_id`,
       `ordering`.`shop_settlement_transfer_item`.`shop_name`   AS `shop_name`,
       `ordering`.`shop_settlement_transfer_item`.`amount`      AS `amount`,
       `ordering`.`shop_settlement_transfer_item`.`group_name`  AS `group_name`,
       `ordering`.`shop_settlement_transfer_item`.`status`      AS `status`,
       `ordering`.`shop_settlement_transfer_item`.`create_time` AS `create_time`,
       `ordering`.`shop_settlement_transfer_item`.`update_time` AS `update_time`
from `ordering`.`shop_settlement_transfer_item`;

-- comment on column view_shop_settlement_transfer_item_v2.city_id not supported: 城市id

-- comment on column view_shop_settlement_transfer_item_v2.transfer_id not supported: 转账id

-- comment on column view_shop_settlement_transfer_item_v2.shop_id not supported: 商家id

-- comment on column view_shop_settlement_transfer_item_v2.shop_name not supported: 商家名称

-- comment on column view_shop_settlement_transfer_item_v2.amount not supported: 转账金额

-- comment on column view_shop_settlement_transfer_item_v2.group_name not supported: 打款分组名称

-- comment on column view_shop_settlement_transfer_item_v2.status not supported: 转账状态, pending=待转账, done=已转账, canceled=已撤销

