create view view_delivery_fee_plan_special_time_part_v2 as
select `ordering`.`delivery_fee_plan_special_time_part`.`id`         AS `id`,
       `ordering`.`delivery_fee_plan_special_time_part`.`start_time` AS `start_time`,
       `ordering`.`delivery_fee_plan_special_time_part`.`end_time`   AS `end_time`
from `ordering`.`delivery_fee_plan_special_time_part`;

-- comment on column view_delivery_fee_plan_special_time_part_v2.start_time not supported: 开始时间

-- comment on column view_delivery_fee_plan_special_time_part_v2.end_time not supported: 截止时间

