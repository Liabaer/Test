create view view_settlement_adjustment_v2 as
select `sa`.`id`                      AS `id`,
       `sa`.`city_id`                 AS `city_id`,
       `sa`.`adjustment_item_id`      AS `adjustment_item_id`,
       `sa`.`adjustment_item_name`    AS `adjustment_item_name`,
       `sa`.`adjustment_item_name_en` AS `adjustment_item_name_en`,
       `sa`.`frequency`               AS `frequency`,
       `sa`.`frequency_value`         AS `frequency_value`,
       `sa`.`start_date`              AS `start_date`,
       `sa`.`end_date`                AS `end_date`,
       `sa`.`amount`                  AS `amount`,
       `sa`.`adjustment_type`         AS `adjustment_type`,
       `sa`.`status`                  AS `status`,
       `sa`.`related_order_id`        AS `related_order_id`,
       `sa`.`remark`                  AS `remark`,
       `sa`.`create_time`             AS `create_time`,
       `sa`.`update_time`             AS `update_time`
from `ordering`.`settlement_adjustment` `sa`;

-- comment on column view_settlement_adjustment_v2.adjustment_item_id not supported: 调账项目id

-- comment on column view_settlement_adjustment_v2.adjustment_item_name not supported: 调账项目名称

-- comment on column view_settlement_adjustment_v2.adjustment_item_name_en not supported: 调账项目英文名称

-- comment on column view_settlement_adjustment_v2.frequency not supported: 调账频率, day天, week周, month月, year年, once一次性

-- comment on column view_settlement_adjustment_v2.frequency_value not supported: 调账频率值

-- comment on column view_settlement_adjustment_v2.start_date not supported: 开始日期

-- comment on column view_settlement_adjustment_v2.end_date not supported: 开始日期

-- comment on column view_settlement_adjustment_v2.amount not supported: 调账金额

-- comment on column view_settlement_adjustment_v2.adjustment_type not supported: 调账类型, courier=配送员, shop=商家

-- comment on column view_settlement_adjustment_v2.status not supported: 调账状态, pending未开始, active进行中, stopped已停止, finished已结束, deleted已删除

-- comment on column view_settlement_adjustment_v2.related_order_id not supported: 相关订单号

-- comment on column view_settlement_adjustment_v2.remark not supported: 备注

