create view view_courier as
select `c`.`id`                      AS `id`,
       `c`.`display_name`            AS `display_name`,
       `c`.`city_id`                 AS `city_id`,
       `c`.`status`                  AS `status`,
       `c`.`driving_type`            AS `driving_type`,
       `c`.`working_status`          AS `working_status`,
       `c`.`passport_no`             AS `passport_no`,
       `c`.`driver_no`               AS `driver_no`,
       `c`.`tfn`                     AS `tfn`,
       `c`.`abn`                     AS `abn`,
       `c`.`bsb_number`              AS `bsb_number`,
       `c`.`acc_number`              AS `acc_number`,
       `c`.`acc_name`                AS `acc_name`,
       `c`.`has_uniform`             AS `has_uniform`,
       `c`.`has_delivery_box`        AS `has_delivery_box`,
       `c`.`has_passport`            AS `has_passport`,
       `c`.`has_abn`                 AS `has_abn`,
       `c`.`is_registered_for_gst`   AS `is_registered_for_gst`,
       `c`.`is_visa_valid`           AS `is_visa_valid`,
       `c`.`custom_manage_fee`       AS `custom_manage_fee`,
       `c`.`min_fee`                 AS `min_fee`,
       `c`.`is_full_time`            AS `is_full_time`,
       `c`.`information_is_complete` AS `information_is_complete`,
       `c`.`create_time`             AS `create_time`
from `ordering`.`courier` `c`;

-- comment on column view_courier.driving_type not supported: 配送员驾驶类型, -1:未设定, 0:自行车, 1:摩托车, 2: 汽车

-- comment on column view_courier.working_status not supported: 快递员在职状态：-1未设定, 0离职, 1在职

-- comment on column view_courier.bsb_number not supported: 配送员BSB number

-- comment on column view_courier.acc_number not supported: 配送员ACC number

-- comment on column view_courier.acc_name not supported: AccountName

-- comment on column view_courier.has_uniform not supported: 是否有制服

-- comment on column view_courier.has_delivery_box not supported: 是否有送餐箱

-- comment on column view_courier.has_passport not supported: 是否有护照，0未知 1有 2无

-- comment on column view_courier.has_abn not supported: 是否有ABN，0未知 1有 2无

-- comment on column view_courier.is_registered_for_gst not supported: 配送员是否注册GST, 0未注册 1已注册

-- comment on column view_courier.is_visa_valid not supported: 签证是否有效

-- comment on column view_courier.custom_manage_fee not supported: 配送员管理费

-- comment on column view_courier.min_fee not supported: 快递员保底金额

-- comment on column view_courier.is_full_time not supported: 是否是全职

-- comment on column view_courier.information_is_complete not supported: 资料是否齐全

