create view view_trade_v2 as
select `t`.`id`                          AS `id`,
       `t`.`order_id`                    AS `order_id`,
       `t`.`city_id`                     AS `city_id`,
       `t`.`shop_id`                     AS `shop_id`,
       `t`.`pay_type`                    AS `pay_type`,
       `t`.`order_source`                AS `order_source`,
       `t`.`trade_type`                  AS `trade_type`,
       `t`.`status`                      AS `status`,
       `t`.`name`                        AS `name`,
       `t`.`scene`                       AS `scene`,
       `t`.`user_id`                     AS `user_id`,
       `t`.`channel_provider`            AS `channel_provider`,
       `t`.`paid_channel_type`           AS `paid_channel_type`,
       `t`.`paid_channel_id`             AS `paid_channel_id`,
       `t`.`paid_channel_name`           AS `paid_channel_name`,
       `t`.`actual_price`                AS `actual_price`,
       `t`.`total_price`                 AS `total_price`,
       `t`.`transaction_fee_rate`        AS `transaction_fee_rate`,
       `t`.`transaction_fee`             AS `transaction_fee`,
       `t`.`is_valid`                    AS `is_valid`,
       `t`.`wx_actual_price`             AS `wx_actual_price`,
       `t`.`wx_transaction_fee_rate`     AS `wx_transaction_fee_rate`,
       `t`.`wx_transaction_fee`          AS `wx_transaction_fee`,
       `t`.`ali_actual_price`            AS `ali_actual_price`,
       `t`.`ali_transaction_fee_rate`    AS `ali_transaction_fee_rate`,
       `t`.`ali_transaction_fee`         AS `ali_transaction_fee`,
       `t`.`paypal_actual_price`         AS `paypal_actual_price`,
       `t`.`paypal_transaction_fee_rate` AS `paypal_transaction_fee_rate`,
       `t`.`paypal_transaction_fee`      AS `paypal_transaction_fee`,
       `t`.`bt_actual_price`             AS `bt_actual_price`,
       `t`.`bt_transaction_fee`          AS `bt_transaction_fee`,
       `t`.`stripe_actual_price`         AS `stripe_actual_price`,
       `t`.`stripe_transaction_fee_rate` AS `stripe_transaction_fee_rate`,
       `t`.`stripe_transaction_fee`      AS `stripe_transaction_fee`,
       `t`.`bt_transaction_fee_rate`     AS `bt_transaction_fee_rate`,
       `t`.`pl_actual_price`             AS `pl_actual_price`,
       `t`.`pl_transaction_fee`          AS `pl_transaction_fee`,
       `t`.`pl_transaction_fee_rate`     AS `pl_transaction_fee_rate`,
       `t`.`adyen_actual_price`          AS `adyen_actual_price`,
       `t`.`adyen_transaction_fee_rate`  AS `adyen_transaction_fee_rate`,
       `t`.`adyen_transaction_fee`       AS `adyen_transaction_fee`,
       `t`.`union_actual_price`          AS `union_actual_price`,
       `t`.`union_transaction_fee_rate`  AS `union_transaction_fee_rate`,
       `t`.`union_transaction_fee`       AS `union_transaction_fee`,
       `t`.`refund_amount`               AS `refund_amount`,
       `t`.`remark`                      AS `remark`,
       `t`.`created_at`                  AS `created_at`,
       `t`.`updated_at`                  AS `updated_at`
from `ordering`.`trade` `t`;

-- comment on column view_trade_v2.order_id not supported: easi订单ID, 其他渠道订单id为空

-- comment on column view_trade_v2.shop_id not supported: 店铺ID

-- comment on column view_trade_v2.pay_type not supported: 在线支付 1; 线下支付 2

-- comment on column view_trade_v2.trade_type not supported: 交易类型(订单支付 1; 众筹活动 2；)

-- comment on column view_trade_v2.status not supported: 交易状态(待支付 1; 支付成功 2;  退款中 3; 退款完成 4;  交易完成 5; 交易关闭 6; 已取消 100)

-- comment on column view_trade_v2.name not supported: 交易名称

-- comment on column view_trade_v2.scene not supported: 交易场景(外卖 1; 堂食 2; 快餐 3)

-- comment on column view_trade_v2.user_id not supported: 支付人ID

-- comment on column view_trade_v2.paid_channel_id not supported: 已支付的渠道id

-- comment on column view_trade_v2.paid_channel_name not supported: 已支付渠道名称

-- comment on column view_trade_v2.actual_price not supported: 顾客实际支付金额

-- comment on column view_trade_v2.total_price not supported: 顾客应该支付金额

-- comment on column view_trade_v2.transaction_fee_rate not supported: 交易费用

-- comment on column view_trade_v2.transaction_fee not supported: 交易费用

-- comment on column view_trade_v2.is_valid not supported: 该条记录是否有效, 有效 1; 无效 0

-- comment on column view_trade_v2.paypal_actual_price not supported: paypal实际支付金额

-- comment on column view_trade_v2.paypal_transaction_fee_rate not supported: paypal交易费率

-- comment on column view_trade_v2.paypal_transaction_fee not supported: paypal交易金额

-- comment on column view_trade_v2.refund_amount not supported: 已退款金额

-- comment on column view_trade_v2.remark not supported: 备注信息

