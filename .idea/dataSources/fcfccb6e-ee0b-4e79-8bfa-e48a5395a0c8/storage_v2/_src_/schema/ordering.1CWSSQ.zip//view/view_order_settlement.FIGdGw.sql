create view view_order_settlement as
select `o`.`id`          AS `order_id`,
       `o`.`courier_id`  AS `courier_id`,
       `o`.`shop_id`     AS `shop_id`,
       `o`.`create_time` AS `order_create_time`,
       `s`.`id`          AS `settlement_id`,
       `s`.`status`      AS `settlement_status`
from (((`ordering`.`order` `o` left join `ordering`.`order_discount_balance` `odb` on ((`odb`.`order_id` = `o`.`id`))) left join `ordering`.`settlement_order_discount_balance` `sodb` on ((`sodb`.`odb_id` = `odb`.`id`)))
         left join `ordering`.`settlement` `s` on ((`sodb`.`settlement_id` = `s`.`id`)));

-- comment on column view_order_settlement.settlement_status not supported: 结算状态, 0:已撤销; 1:待转账; 2:转账中; 3:已转账

