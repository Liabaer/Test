create view view_country_v2 as
select `c`.`id` AS `id`, `c`.`name` AS `name`, `c`.`name_en` AS `name_en`, `c`.`abbr` AS `abbr`, `c`.`code` AS `code`
from `ordering`.`country` `c`;

-- comment on column view_country_v2.name not supported: 国家中文名称

-- comment on column view_country_v2.name_en not supported: 国家英文名称

-- comment on column view_country_v2.code not supported: 国家码

