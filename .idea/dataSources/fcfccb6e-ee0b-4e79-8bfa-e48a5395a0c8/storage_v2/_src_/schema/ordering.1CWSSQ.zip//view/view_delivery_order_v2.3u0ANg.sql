create view view_delivery_order_v2 as
select `do`.`id`            AS `id`,
       `do`.`order_id`      AS `order_id`,
       `do`.`shop_id`       AS `shop_id`,
       `do`.`order_sn`      AS `order_sn`,
       `do`.`order_sn_code` AS `order_sn_code`,
       `do`.`courier_id`    AS `courier_id`,
       `do`.`user_id`       AS `user_id`,
       `do`.`phone_number`  AS `phone_number`,
       `do`.`created_time`  AS `created_time`,
       `do`.`assign_type`   AS `assign_type`
from `ordering`.`delivery_order` `do`;

-- comment on column view_delivery_order_v2.id not supported: id

-- comment on column view_delivery_order_v2.order_id not supported: 订单ID

-- comment on column view_delivery_order_v2.shop_id not supported: 店铺ID

-- comment on column view_delivery_order_v2.order_sn not supported: 取餐号

-- comment on column view_delivery_order_v2.order_sn_code not supported: 编码取餐号

-- comment on column view_delivery_order_v2.courier_id not supported: 配送员ID

-- comment on column view_delivery_order_v2.user_id not supported: 用户ID

-- comment on column view_delivery_order_v2.phone_number not supported: 订单电话号码

-- comment on column view_delivery_order_v2.created_time not supported: 创建时间

-- comment on column view_delivery_order_v2.assign_type not supported: 订单分配类型

