create view view_user_order_count as
select `ordering`.`user_order_count`.`id`                           AS `id`,
       `ordering`.`user_order_count`.`user_id`                      AS `user_id`,
       `ordering`.`user_order_count`.`first_order_id`               AS `first_order_id`,
       `ordering`.`user_order_count`.`first_order_time`             AS `first_order_time`,
       `ordering`.`user_order_count`.`first_order_shop_id`          AS `first_order_shop_id`,
       `ordering`.`user_order_count`.`first_order_city_id`          AS `first_order_city_id`,
       `ordering`.`user_order_count`.`order_count`                  AS `order_count`,
       `ordering`.`user_order_count`.`last_order_id`                AS `last_order_id`,
       `ordering`.`user_order_count`.`last_order_time`              AS `last_order_time`,
       `ordering`.`user_order_count`.`last_order_shop_id`           AS `last_order_shop_id`,
       `ordering`.`user_order_count`.`last_order_city_id`           AS `last_order_city_id`,
       `ordering`.`user_order_count`.`complete_order_count`         AS `complete_order_count`,
       `ordering`.`user_order_count`.`first_complete_order_id`      AS `first_complete_order_id`,
       `ordering`.`user_order_count`.`first_complete_order_time`    AS `first_complete_order_time`,
       `ordering`.`user_order_count`.`first_complete_order_shop_id` AS `first_complete_order_shop_id`,
       `ordering`.`user_order_count`.`first_complete_order_city_id` AS `first_complete_order_city_id`,
       `ordering`.`user_order_count`.`last_complete_order_id`       AS `last_complete_order_id`,
       `ordering`.`user_order_count`.`last_complete_order_time`     AS `last_complete_order_time`,
       `ordering`.`user_order_count`.`last_complete_order_shop_id`  AS `last_complete_order_shop_id`,
       `ordering`.`user_order_count`.`last_complete_order_city_id`  AS `last_complete_order_city_id`
from `ordering`.`user_order_count`;

-- comment on column view_user_order_count.user_id not supported: 顾客ID

-- comment on column view_user_order_count.first_order_id not supported: 第一次下单的订单ID

-- comment on column view_user_order_count.first_order_time not supported: 第一次下单时间

-- comment on column view_user_order_count.first_order_shop_id not supported: 第一次下单商家ID

-- comment on column view_user_order_count.first_order_city_id not supported: 第一次下单城市ID

-- comment on column view_user_order_count.order_count not supported: 下单次数，不看订单状态，下单就算次数

-- comment on column view_user_order_count.last_order_id not supported: 最近一次下单的订单ID

-- comment on column view_user_order_count.last_order_time not supported: 最近一次下单时间

-- comment on column view_user_order_count.last_order_shop_id not supported: 最近一次下单商家ID

-- comment on column view_user_order_count.last_order_city_id not supported: 最近一次下单城市ID

-- comment on column view_user_order_count.complete_order_count not supported: 完成订单次数，只看完成状态的订单

-- comment on column view_user_order_count.first_complete_order_id not supported: 第一次完成订单ID

-- comment on column view_user_order_count.first_complete_order_time not supported: 第一次完成订单时间

-- comment on column view_user_order_count.first_complete_order_shop_id not supported: 第一次完成订单商家ID

-- comment on column view_user_order_count.first_complete_order_city_id not supported: 第一次完成订单城市ID

-- comment on column view_user_order_count.last_complete_order_id not supported: 最近一次完成订单的订单ID

-- comment on column view_user_order_count.last_complete_order_time not supported: 最近一次完成订单时间

-- comment on column view_user_order_count.last_complete_order_shop_id not supported: 最近一次完成订单商家ID

-- comment on column view_user_order_count.last_complete_order_city_id not supported: 最近一次完成订单城市ID

