create view view_category_v2 as
select `ic`.`id`          AS `id`,
       `ic`.`name`        AS `name`,
       `ic`.`name_en`     AS `name_en`,
       `ic`.`image`       AS `image`,
       `ic`.`seq`         AS `seq`,
       `ic`.`create_time` AS `create_time`,
       `ic`.`update_time` AS `update_time`,
       `ic`.`shop_id`     AS `shop_id`
from `ordering`.`item_category` `ic`;

