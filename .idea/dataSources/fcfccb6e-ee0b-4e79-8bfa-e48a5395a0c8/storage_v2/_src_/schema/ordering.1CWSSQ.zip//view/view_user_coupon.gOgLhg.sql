create view view_user_coupon as
select `uc`.`id`                AS `id`,
       `uc`.`city_id`           AS `city_id`,
       `uc`.`status`            AS `status`,
       `uc`.`channel`           AS `channel`,
       `uc`.`create_time`       AS `create_time`,
       `uc`.`update_time`       AS `update_time`,
       `uc`.`user_id`           AS `user_id`,
       `uc`.`shop_id`           AS `shop_id`,
       `uc`.`coupon_id`         AS `coupon_id`,
       `uc`.`order_id`          AS `order_id`,
       `uc`.`from_order_id`     AS `from_order_id`,
       `uc`.`coupon_act_id`     AS `coupon_act_id`,
       `uc`.`promo_code_act_id` AS `promo_code_act_id`,
       `uc`.`start_time`        AS `start_time`,
       `uc`.`expire_time`       AS `expire_time`,
       `uc`.`payment_type`      AS `payment_type`
from `ordering`.`user_coupon` `uc`;

-- comment on column view_user_coupon.city_id not supported: 城市ID

-- comment on column view_user_coupon.channel not supported: 发放渠道

-- comment on column view_user_coupon.shop_id not supported: 所属商家ID

-- comment on column view_user_coupon.coupon_act_id not supported: 活动id

-- comment on column view_user_coupon.start_time not supported: 使用开始时间

-- comment on column view_user_coupon.expire_time not supported: 失效时间

-- comment on column view_user_coupon.payment_type not supported: 优惠券支付方式

