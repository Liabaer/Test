create view view_user as
select `u`.`id` AS `id`, `u`.`city_id` AS `city_id`, `u`.`email` AS `email`, `u`.`create_time` AS `create_time`
from `ordering`.`user` `u`;

-- comment on column view_user.email not supported: 用户email

