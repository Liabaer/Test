create view view_order_pool_notification_v2 as
select `opn`.`id`            AS `id`,
       `opn`.`status`        AS `status`,
       `opn`.`create_time`   AS `create_time`,
       `opn`.`update_time`   AS `update_time`,
       `opn`.`order_pool_id` AS `order_pool_id`,
       `opn`.`courier_id`    AS `courier_id`,
       `opn`.`send_time`     AS `send_time`,
       `opn`.`receive_time`  AS `receive_time`,
       `opn`.`order_id`      AS `order_id`
from `ordering`.`order_pool_notification` `opn`;

-- comment on column view_order_pool_notification_v2.order_id not supported: 订单ID

