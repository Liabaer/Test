create view view_vrp_order_pool_group as
select `ordering`.`vrp_order_pool_group`.`id`                  AS `id`,
       `ordering`.`vrp_order_pool_group`.`param`               AS `param`,
       `ordering`.`vrp_order_pool_group`.`shop_tag_id_list`    AS `shop_tag_id_list`,
       `ordering`.`vrp_order_pool_group`.`shop_area_id_list`   AS `shop_area_id_list`,
       `ordering`.`vrp_order_pool_group`.`courier_tag_id_list` AS `courier_tag_id_list`,
       `ordering`.`vrp_order_pool_group`.`biz_id`              AS `biz_id`,
       `ordering`.`vrp_order_pool_group`.`status`              AS `status`,
       `ordering`.`vrp_order_pool_group`.`city_id`             AS `city_id`,
       `ordering`.`vrp_order_pool_group`.`system_param`        AS `system_param`,
       `ordering`.`vrp_order_pool_group`.`name`                AS `name`
from `ordering`.`vrp_order_pool_group`;

-- comment on column view_vrp_order_pool_group.param not supported: vrp各组参数

-- comment on column view_vrp_order_pool_group.shop_tag_id_list not supported: 商家标签id列表

-- comment on column view_vrp_order_pool_group.shop_area_id_list not supported: 商家区域id

-- comment on column view_vrp_order_pool_group.courier_tag_id_list not supported: 配送标签id

-- comment on column view_vrp_order_pool_group.biz_id not supported: biz_id

-- comment on column view_vrp_order_pool_group.status not supported: 0关闭 1开启

