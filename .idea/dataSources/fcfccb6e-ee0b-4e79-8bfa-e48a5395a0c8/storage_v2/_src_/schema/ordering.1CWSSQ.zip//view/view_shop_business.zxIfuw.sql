create view view_shop_business as
select `sb`.`id`       AS `id`,
       `sb`.`shop_id`  AS `shop_id`,
       `sb`.`opening`  AS `opening`,
       `sb`.`business` AS `business`,
       `sb`.`status`   AS `status`
from `ordering`.`shop_business` `sb`
where (`sb`.`platform` = 0);

-- comment on column view_shop_business.shop_id not supported: 商家id

-- comment on column view_shop_business.opening not supported: 商家自定义营业状态

-- comment on column view_shop_business.business not supported: 商家营业状态，同shop表的business字段

-- comment on column view_shop_business.status not supported: 商家上架状态，同shop表的status字段

