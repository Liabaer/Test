create view view_item_v2 as
select `i`.`id`                    AS `id`,
       `i`.`name`                  AS `name`,
       `i`.`name_en`               AS `name_en`,
       `i`.`price`                 AS `price`,
       `i`.`stock`                 AS `stock`,
       `i`.`status`                AS `status`,
       `i`.`seq`                   AS `seq`,
       `i`.`image`                 AS `image`,
       `i`.`good`                  AS `good`,
       `i`.`create_time`           AS `create_time`,
       `i`.`update_time`           AS `update_time`,
       `i`.`shop_id`               AS `shop_id`,
       `i`.`code`                  AS `code`,
       `i`.`group_buy`             AS `group_buy`,
       `i`.`group_price`           AS `group_price`,
       `i`.`tobacco_alcohol`       AS `tobacco_alcohol`,
       `i`.`unit`                  AS `unit`,
       `i`.`desc`                  AS `desc`,
       `i`.`desc_en`               AS `desc_en`,
       `i`.`category_id`           AS `category_id`,
       `i`.`is_registered_for_vat` AS `is_registered_for_vat`,
       `i`.`is_vat_included`       AS `is_vat_included`,
       `i`.`vat_rate`              AS `vat_rate`,
       `i`.`is_zp`                 AS `is_zp`,
       `i`.`standard_cate_id`      AS `standard_cate_id`,
       `i`.`adjust_price`          AS `adjust_price`,
       `i`.`is_sku`                AS `is_sku`
from `ordering`.`item` `i`;

-- comment on column view_item_v2.code not supported: 商品编码

-- comment on column view_item_v2.tobacco_alcohol not supported: 烟酒类商品

-- comment on column view_item_v2.is_registered_for_vat not supported: 商品价格是否注册增值税，0未注册，1已注册

-- comment on column view_item_v2.is_vat_included not supported: 商品价格是否包含增值税，0未包含，1包含

-- comment on column view_item_v2.vat_rate not supported: 商品增值税率

