create view view_settlement_adjustment_schedule_v2 as
select `sas`.`id`                       AS `id`,
       `sas`.`city_id`                  AS `city_id`,
       `sas`.`settlement_adjustment_id` AS `settlement_adjustment_id`,
       `sas`.`amount`                   AS `amount`,
       `sas`.`schedule_time`            AS `schedule_time`,
       `sas`.`status`                   AS `status`,
       `sas`.`create_time`              AS `create_time`,
       `sas`.`update_time`              AS `update_time`
from `ordering`.`settlement_adjustment_schedule` `sas`;

-- comment on column view_settlement_adjustment_schedule_v2.city_id not supported: 城市ID

-- comment on column view_settlement_adjustment_schedule_v2.settlement_adjustment_id not supported: 调账id

-- comment on column view_settlement_adjustment_schedule_v2.amount not supported: 调账金额

-- comment on column view_settlement_adjustment_schedule_v2.schedule_time not supported: 计划时间

-- comment on column view_settlement_adjustment_schedule_v2.status not supported: 调账计划状态, pending计划中, active待结算, finished成功, canceled已取消

