create view view_item as
select `i`.`id`              AS `id`,
       `i`.`name`            AS `name`,
       `i`.`name_en`         AS `name_en`,
       `i`.`price`           AS `price`,
       `i`.`seq`             AS `seq`,
       `i`.`stock`           AS `stock`,
       `i`.`status`          AS `status`,
       `i`.`image`           AS `image`,
       `i`.`shop_id`         AS `shop_id`,
       `i`.`code`            AS `code`,
       `i`.`desc`            AS `desc`,
       `i`.`desc_en`         AS `desc_en`,
       `i`.`category_id`     AS `category_id`,
       `i`.`tobacco_alcohol` AS `tobacco_alcohol`,
       `i`.`group_buy`       AS `group_buy`,
       `i`.`group_price`     AS `group_price`,
       `i`.`create_time`     AS `create_time`
from `ordering`.`item` `i`;

-- comment on column view_item.code not supported: 商品编码

-- comment on column view_item.tobacco_alcohol not supported: 烟酒类商品

