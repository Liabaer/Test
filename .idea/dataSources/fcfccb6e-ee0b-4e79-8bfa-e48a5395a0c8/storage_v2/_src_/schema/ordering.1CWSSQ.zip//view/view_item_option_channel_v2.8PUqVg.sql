create view view_item_option_channel_v2 as
select `ioc`.`id`                   AS `id`,
       `ioc`.`shop_id`              AS `shop_id`,
       `ioc`.`channel`              AS `channel`,
       `ioc`.`item_id`              AS `item_id`,
       `ioc`.`item_option_group_id` AS `item_option_group_id`,
       `ioc`.`item_option_id`       AS `item_option_id`,
       `ioc`.`price`                AS `price`,
       `ioc`.`adjust_price`         AS `adjust_price`,
       `ioc`.`status`               AS `status`,
       `ioc`.`create_time`          AS `create_time`
from `ordering`.`item_option_channel` `ioc`;

-- comment on column view_item_option_channel_v2.channel not supported: takeout(外卖),dinner(堂食)

-- comment on column view_item_option_channel_v2.adjust_price not supported: 调整金额，正数为涨价，负数为降价

