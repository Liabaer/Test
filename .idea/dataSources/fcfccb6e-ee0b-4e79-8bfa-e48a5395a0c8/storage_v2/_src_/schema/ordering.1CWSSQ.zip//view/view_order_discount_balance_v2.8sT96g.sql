create view view_order_discount_balance_v2 as
select `odb`.`id`                          AS `id`,
       `odb`.`order_id`                    AS `order_id`,
       `odb`.`pay_type`                    AS `pay_type`,
       `odb`.`city_id`                     AS `city_id`,
       `odb`.`shop_id`                     AS `shop_id`,
       `odb`.`courier_id`                  AS `courier_id`,
       `odb`.`create_time`                 AS `create_time`,
       `odb`.`update_time`                 AS `update_time`,
       `odb`.`status`                      AS `status`,
       `odb`.`order_status`                AS `order_status`,
       `odb`.`trade_status`                AS `trade_status`,
       `odb`.`delivery_type`               AS `delivery_type`,
       `odb`.`order_time`                  AS `order_time`,
       `odb`.`order_fee`                   AS `order_fee`,
       `odb`.`delivery_fee`                AS `delivery_fee`,
       `odb`.`commission_fee`              AS `commission_fee`,
       `odb`.`coupon_fee`                  AS `coupon_fee`,
       `odb`.`merchant_coupon_fee`         AS `merchant_coupon_fee`,
       `odb`.`merchant_coupon_subsidy_fee` AS `merchant_coupon_subsidy_fee`,
       `odb`.`delivery_only_fee`           AS `delivery_only_fee`,
       `odb`.`manage_fee`                  AS `manage_fee`,
       `odb`.`clear_type`                  AS `clear_type`,
       `odb`.`clear_image`                 AS `clear_image`,
       `odb`.`settlement_id`               AS `settlement_id`,
       `odb`.`delivery_fee_discount`       AS `delivery_fee_discount`,
       `odb`.`courier_delivery_fee`        AS `courier_delivery_fee`,
       `odb`.`merchant_delivery_fee`       AS `merchant_delivery_fee`,
       `odb`.`order_fee_adjust`            AS `order_fee_adjust`,
       `odb`.`offline_discount`            AS `offline_discount`,
       `odb`.`refund_fee`                  AS `refund_fee`,
       `odb`.`credit_note`                 AS `credit_note`,
       `odb`.`shop_order_fee_discount`     AS `shop_order_fee_discount`,
       `odb`.`take_meal_fee`               AS `take_meal_fee`,
       `odb`.`courier_is_full_time`        AS `courier_is_full_time`,
       `odb`.`is_platform_settlement`      AS `is_platform_settlement`,
       `odb`.`vat_fee`                     AS `vat_fee`,
       `odb`.`is_vat_included`             AS `is_vat_included`,
       `odb`.`is_station_order`            AS `is_station_order`
from `ordering`.`order_discount_balance` `odb`;

-- comment on column view_order_discount_balance_v2.pay_type not supported: 1=在线支付，2=货到付款

-- comment on column view_order_discount_balance_v2.city_id not supported: 城市ID

-- comment on column view_order_discount_balance_v2.shop_id not supported: 商家id

-- comment on column view_order_discount_balance_v2.merchant_coupon_fee not supported: 商家优惠券抵扣金额

-- comment on column view_order_discount_balance_v2.merchant_coupon_subsidy_fee not supported: 商家优惠券平台补贴金额

-- comment on column view_order_discount_balance_v2.courier_delivery_fee not supported: 配送员实际配送费收入，按配送员配送费计算规则得出

-- comment on column view_order_discount_balance_v2.merchant_delivery_fee not supported: 商家配送费

-- comment on column view_order_discount_balance_v2.order_fee_adjust not supported: 订单费用调整

-- comment on column view_order_discount_balance_v2.offline_discount not supported: 线下活动优惠金额，比如顾客分享朋友圈推广文字，优惠2刀

-- comment on column view_order_discount_balance_v2.refund_fee not supported: 在线支付订单部分退款金额

-- comment on column view_order_discount_balance_v2.credit_note not supported: 部分退款金额

-- comment on column view_order_discount_balance_v2.shop_order_fee_discount not supported: 商家减免金额

-- comment on column view_order_discount_balance_v2.take_meal_fee not supported: 取餐补贴

-- comment on column view_order_discount_balance_v2.courier_is_full_time not supported: 配送员是否是全职

-- comment on column view_order_discount_balance_v2.is_platform_settlement not supported: 是否是在线支付平台结算订单, 0否, 1是

-- comment on column view_order_discount_balance_v2.vat_fee not supported: 订单增值税

-- comment on column view_order_discount_balance_v2.is_vat_included not supported: 餐费是否包含增值税

-- comment on column view_order_discount_balance_v2.is_station_order not supported: 是否站长订单

