create view view_courier_tag_connection_v2 as
select `ordering`.`courier_tag_connection`.`courier_id` AS `courier_id`,
       `ordering`.`courier_tag_connection`.`tag_id`     AS `tag_id`,
       `ordering`.`courier_tag_connection`.`type`       AS `type`,
       `ordering`.`courier_tag_connection`.`city_id`    AS `city_id`
from `ordering`.`courier_tag_connection`;

-- comment on column view_courier_tag_connection_v2.courier_id not supported: 配送员id

-- comment on column view_courier_tag_connection_v2.tag_id not supported: 配送员标签id

-- comment on column view_courier_tag_connection_v2.type not supported: 1代表excel文件导入的能够直接查询出来的配送员id,2代表时规则类型,配送员是按照规则筛选出来的

-- comment on column view_courier_tag_connection_v2.city_id not supported: 城市id

