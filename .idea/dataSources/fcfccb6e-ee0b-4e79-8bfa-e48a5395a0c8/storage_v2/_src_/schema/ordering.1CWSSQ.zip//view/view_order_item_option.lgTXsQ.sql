create view view_order_item_option as
select `oio`.`id`                         AS `id`,
       `oio`.`order_item_option_group_id` AS `order_item_option_group_id`,
       `oio`.`name`                       AS `name`,
       `oio`.`name_en`                    AS `name_en`,
       `oio`.`price`                      AS `price`,
       `oio`.`count`                      AS `count`
from `ordering`.`order_item_option` `oio`;

