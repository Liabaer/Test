create view view_shop_zone_v2 as
select `sz`.`id` AS `id`, `sz`.`name` AS `name`, `sz`.`city_id` AS `city_id`
from `ordering`.`shop_zone` `sz`;

