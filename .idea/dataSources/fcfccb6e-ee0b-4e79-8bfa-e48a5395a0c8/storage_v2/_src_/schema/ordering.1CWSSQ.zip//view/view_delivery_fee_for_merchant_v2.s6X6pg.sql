create view view_delivery_fee_for_merchant_v2 as
select `ordering`.`delivery_fee_for_merchant`.`id`                  AS `id`,
       `ordering`.`delivery_fee_for_merchant`.`city_id`             AS `city_id`,
       `ordering`.`delivery_fee_for_merchant`.`plan_id`             AS `plan_id`,
       `ordering`.`delivery_fee_for_merchant`.`area_id`             AS `area_id`,
       `ordering`.`delivery_fee_for_merchant`.`order_delivery_type` AS `order_delivery_type`,
       `ordering`.`delivery_fee_for_merchant`.`status`              AS `status`,
       `ordering`.`delivery_fee_for_merchant`.`is_deleted`          AS `is_deleted`,
       `ordering`.`delivery_fee_for_merchant`.`create_time`         AS `create_time`,
       `ordering`.`delivery_fee_for_merchant`.`update_time`         AS `update_time`
from `ordering`.`delivery_fee_for_merchant`;

-- comment on column view_delivery_fee_for_merchant_v2.plan_id not supported: 配送费方案ID

-- comment on column view_delivery_fee_for_merchant_v2.area_id not supported: 区域ID

-- comment on column view_delivery_fee_for_merchant_v2.order_delivery_type not supported: 订单类型（1/2/3)普通订单、代购订单、私人订单

-- comment on column view_delivery_fee_for_merchant_v2.status not supported: 开关状态 0关闭，1开启

-- comment on column view_delivery_fee_for_merchant_v2.is_deleted not supported: 删除状态 0未删除 1删除

