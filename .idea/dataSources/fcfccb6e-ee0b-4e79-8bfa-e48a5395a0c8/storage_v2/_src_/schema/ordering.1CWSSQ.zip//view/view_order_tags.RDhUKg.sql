create view view_order_tags as
select `ordering`.`order_tags`.`id`          AS `id`,
       `ordering`.`order_tags`.`order_id`    AS `order_id`,
       `ordering`.`order_tags`.`tag_id`      AS `tag_id`,
       `ordering`.`order_tags`.`create_time` AS `create_time`
from `ordering`.`order_tags`;

