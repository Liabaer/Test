create view view_order_v2 as
select `o`.`id`                                   AS `id`,
       `o`.`sn`                                   AS `sn`,
       `o`.`unit_no`                              AS `unit_no`,
       `o`.`street`                               AS `street`,
       `o`.`delivery_time`                        AS `delivery_time`,
       `o`.`delivery_fee`                         AS `delivery_fee`,
       `o`.`delivery_fee_rate`                    AS `delivery_fee_rate`,
       `o`.`remark`                               AS `remark`,
       `o`.`create_time`                          AS `create_time`,
       `o`.`update_time`                          AS `update_time`,
       `o`.`status`                               AS `status`,
       `o`.`distributing_status`                  AS `distributing_status`,
       `o`.`user_id`                              AS `user_id`,
       `o`.`suburb_id`                            AS `suburb_id`,
       `o`.`post_code`                            AS `post_code`,
       `o`.`courier_id`                           AS `courier_id`,
       `o`.`confirm_time`                         AS `confirm_time`,
       `o`.`courier_pickup_time_wait`             AS `courier_pickup_time_wait`,
       `o`.`courier_accept_time`                  AS `courier_accept_time`,
       `o`.`deliverying_time`                     AS `deliverying_time`,
       `o`.`complete_time`                        AS `complete_time`,
       `o`.`distributing_time`                    AS `distributing_time`,
       `o`.`courier_arrive_shop_time`             AS `courier_arrive_shop_time`,
       `o`.`delivery_type`                        AS `delivery_type`,
       `o`.`pay_type`                             AS `pay_type`,
       `o`.`shop_id`                              AS `shop_id`,
       `o`.`shop_discount_type`                   AS `shop_discount_type`,
       `o`.`shop_discount`                        AS `shop_discount`,
       `o`.`src_location`                         AS `src_location`,
       `o`.`src_location_text`                    AS `src_location_text`,
       `o`.`location`                             AS `location`,
       `o`.`location_text`                        AS `location_text`,
       `o`.`location_area`                        AS `location_area`,
       `o`.`distance`                             AS `distance`,
       `o`.`delivery_start_fee`                   AS `delivery_start_fee`,
       `o`.`delivery_start_km`                    AS `delivery_start_km`,
       `o`.`delivery_fee_per_km`                  AS `delivery_fee_per_km`,
       `o`.`limit_time`                           AS `limit_time`,
       `o`.`city_id`                              AS `city_id`,
       `o`.`is_ready`                             AS `is_ready`,
       `o`.`goods_ready_time`                     AS `goods_ready_time`,
       `o`.`need_contact`                         AS `need_contact`,
       `o`.`shop_delivery_fee_discount_type`      AS `shop_delivery_fee_discount_type`,
       `o`.`shop_delivery_fee_discount`           AS `shop_delivery_fee_discount`,
       `o`.`shop_delivery_fee_discount_condition` AS `shop_delivery_fee_discount_condition`,
       `o`.`delivery_fee_discount`                AS `delivery_fee_discount`,
       `o`.`shop_invoice_image`                   AS `shop_invoice_image`,
       `o`.`offline_discount_image`               AS `offline_discount_image`,
       `o`.`shop_order_fee_discount`              AS `shop_order_fee_discount`,
       `o`.`courier_delivery_fee`                 AS `courier_delivery_fee`,
       `o`.`merchant_delivery_fee`                AS `merchant_delivery_fee`,
       `o`.`customer_service_group`               AS `customer_service_group`,
       `o`.`order_fee_adjust`                     AS `order_fee_adjust`,
       `o`.`offline_discount`                     AS `offline_discount`,
       `o`.`wallet_fee`                           AS `wallet_fee`,
       `o`.`offline_discount_status`              AS `offline_discount_status`,
       `o`.`offline_discount_time`                AS `offline_discount_time`,
       `o`.`refund_fee`                           AS `refund_fee`,
       `o`.`credit_note`                          AS `credit_note`,
       `o`.`courier_is_full_time`                 AS `courier_is_full_time`,
       `o`.`is_platform_settlement`               AS `is_platform_settlement`,
       `o`.`vat_rate`                             AS `vat_rate`,
       `o`.`is_vat_included`                      AS `is_vat_included`,
       `o`.`delivery_method`                      AS `delivery_method`,
       `o`.`channel`                              AS `channel`
from `ordering`.`order` `o`
where (`o`.`platform` = 0);

-- comment on column view_order_v2.distributing_status not supported: 订单分配状态/子状态：普通单状态、任务单状态、孤儿单状态、急救单状态

-- comment on column view_order_v2.courier_pickup_time_wait not supported: 配送员取餐等待时间，比如未等待(no),小于5分钟(<5),小于10分钟(<10),大于10分钟(>10)

-- comment on column view_order_v2.courier_accept_time not supported: 配送员确认接单时间

-- comment on column view_order_v2.courier_arrive_shop_time not supported: 配送员到店时间

-- comment on column view_order_v2.pay_type not supported: 1=在线支付，2=货到付款

-- comment on column view_order_v2.goods_ready_time not supported: 商家出餐时间

-- comment on column view_order_v2.shop_invoice_image not supported: 商家小票文件

-- comment on column view_order_v2.offline_discount_image not supported: 线下优惠活动截图，比如分享朋友圈截图

-- comment on column view_order_v2.courier_delivery_fee not supported: 配送员实际配送费收入，按配送员配送费计算规则得出

-- comment on column view_order_v2.merchant_delivery_fee not supported: 商家配送费

-- comment on column view_order_v2.customer_service_group not supported: 客服分配, 0未设置, 1澳洲, 2国内

-- comment on column view_order_v2.order_fee_adjust not supported: 订单费用调整

-- comment on column view_order_v2.offline_discount not supported: 线下活动优惠金额，比如顾客分享朋友圈推广文字，优惠2刀

-- comment on column view_order_v2.offline_discount_status not supported: 线下优惠审核状态

-- comment on column view_order_v2.offline_discount_time not supported: 审核时间

-- comment on column view_order_v2.refund_fee not supported: 在线支付订单部分退款金额

-- comment on column view_order_v2.credit_note not supported: 部分退款金额

-- comment on column view_order_v2.courier_is_full_time not supported: 配送员是否是全职

-- comment on column view_order_v2.is_platform_settlement not supported: 是否是在线支付平台结算订单, 0否, 1是

-- comment on column view_order_v2.vat_rate not supported: 订单增值税率

-- comment on column view_order_v2.is_vat_included not supported: 餐费是否包含增值税

-- comment on column view_order_v2.delivery_method not supported: 配送方式 0-EASI配送 1-商家配送

-- comment on column view_order_v2.channel not supported: 订单来源

