create view view_algor_cainiao_progre_resp_v2 as
select `acpr`.`id`          AS `id`,
       `acpr`.`des`         AS `des`,
       `acpr`.`result_code` AS `result_code`,
       `acpr`.`transaction` AS `transaction`,
       `acpr`.`status`      AS `status`,
       `acpr`.`success`     AS `success`,
       `acpr`.`timestamp`   AS `timestamp`,
       `acpr`.`trace_id`    AS `trace_id`,
       `acpr`.`create_time` AS `create_time`
from `ordering`.`algor_cainiao_progre_resp` `acpr`;

-- comment on column view_algor_cainiao_progre_resp_v2.des not supported: 查询接口返回信息描述

-- comment on column view_algor_cainiao_progre_resp_v2.result_code not supported: 查询接口返回码

-- comment on column view_algor_cainiao_progre_resp_v2.transaction not supported: 查询批次ID

-- comment on column view_algor_cainiao_progre_resp_v2.status not supported: 算法求解状态

-- comment on column view_algor_cainiao_progre_resp_v2.success not supported: 接口请求状态

-- comment on column view_algor_cainiao_progre_resp_v2.timestamp not supported: 返回时间戳

-- comment on column view_algor_cainiao_progre_resp_v2.trace_id not supported: 跟踪ID

-- comment on column view_algor_cainiao_progre_resp_v2.create_time not supported: 创建时间

