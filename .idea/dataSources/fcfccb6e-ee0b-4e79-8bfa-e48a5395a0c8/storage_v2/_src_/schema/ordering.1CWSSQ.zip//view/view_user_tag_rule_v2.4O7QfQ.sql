create view view_user_tag_rule_v2 as
select `ordering`.`user_tag_rule`.`tag_id`  AS `tag_id`,
       `ordering`.`user_tag_rule`.`rule_id` AS `rule_id`,
       `ordering`.`user_tag_rule`.`city_id` AS `city_id`,
       `ordering`.`user_tag_rule`.`content` AS `content`
from `ordering`.`user_tag_rule`;

-- comment on column view_user_tag_rule_v2.tag_id not supported: 标签id

-- comment on column view_user_tag_rule_v2.rule_id not supported: 用户的140条规则

-- comment on column view_user_tag_rule_v2.content not supported: 规则的内容

