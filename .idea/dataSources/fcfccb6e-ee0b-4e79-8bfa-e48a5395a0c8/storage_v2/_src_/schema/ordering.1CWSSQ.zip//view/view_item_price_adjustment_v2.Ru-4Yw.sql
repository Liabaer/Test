create view view_item_price_adjustment_v2 as
select `ipa`.`id`           AS `id`,
       `ipa`.`item_id`      AS `item_id`,
       `ipa`.`platform`     AS `platform`,
       `ipa`.`adjust_price` AS `adjust_price`
from `ordering`.`item_price_adjustment` `ipa`;

-- comment on column view_item_price_adjustment_v2.item_id not supported: 商品id

-- comment on column view_item_price_adjustment_v2.platform not supported: 送餐平台

-- comment on column view_item_price_adjustment_v2.adjust_price not supported: 调整金额，正数为涨价，负数为降价

