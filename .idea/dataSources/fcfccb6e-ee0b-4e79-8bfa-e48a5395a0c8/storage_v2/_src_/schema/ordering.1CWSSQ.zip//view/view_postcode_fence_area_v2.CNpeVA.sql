create view view_postcode_fence_area_v2 as
select `pfa`.`id`          AS `id`,
       `pfa`.`name`        AS `name`,
       `pfa`.`type`        AS `type`,
       `pfa`.`remark`      AS `remark`,
       `pfa`.`postcode`    AS `postcode`,
       `pfa`.`fence`       AS `fence`,
       `pfa`.`city_id`     AS `city_id`,
       `pfa`.`is_del`      AS `is_del`,
       `pfa`.`create_time` AS `create_time`,
       `pfa`.`update_time` AS `update_time`,
       `pfa`.`level`       AS `level`,
       `pfa`.`parent_id`   AS `parent_id`
from `ordering`.`postcode_fence_area` `pfa`;

-- comment on column view_postcode_fence_area_v2.name not supported: 区域名称

-- comment on column view_postcode_fence_area_v2.type not supported: 区域类型

-- comment on column view_postcode_fence_area_v2.remark not supported: 区域备注

-- comment on column view_postcode_fence_area_v2.postcode not supported: 区域包含的邮编

-- comment on column view_postcode_fence_area_v2.fence not supported: 包含的基础单元和多级区域

-- comment on column view_postcode_fence_area_v2.city_id not supported: 城市id

-- comment on column view_postcode_fence_area_v2.is_del not supported: 是否删除

-- comment on column view_postcode_fence_area_v2.level not supported: 区域等级

-- comment on column view_postcode_fence_area_v2.parent_id not supported: 使用该区域的上一级区域

