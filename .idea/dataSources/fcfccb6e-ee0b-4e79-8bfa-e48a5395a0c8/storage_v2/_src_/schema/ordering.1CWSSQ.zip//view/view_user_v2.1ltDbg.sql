create view view_user_v2 as
select `u`.`id`                AS `id`,
       `u`.`city_id`           AS `city_id`,
       `u`.`device_token`      AS `device_token`,
       `u`.`login_device_type` AS `login_device_type`,
       `u`.`login_language`    AS `login_language`,
       `u`.`sex`               AS `sex`,
       `u`.`age`               AS `age`,
       `u`.`email`             AS `email`,
       `u`.`create_time`       AS `create_time`
from `ordering`.`user` `u`;

-- comment on column view_user_v2.login_language not supported: 登录语言

-- comment on column view_user_v2.email not supported: 用户email

