create view view_refund_audit_v2 as
select `ra`.`id`               AS `id`,
       `ra`.`application_id`   AS `application_id`,
       `ra`.`payment_number`   AS `payment_number`,
       `ra`.`order_id`         AS `order_id`,
       `ra`.`shop_id`          AS `shop_id`,
       `ra`.`audit_time`       AS `audit_time`,
       `ra`.`audit_status`     AS `audit_status`,
       `ra`.`refund_back_way`  AS `refund_back_way`,
       `ra`.`apply_refund_fee` AS `apply_refund_fee`,
       `ra`.`real_refund_fee`  AS `real_refund_fee`,
       `ra`.`apply_remark`     AS `apply_remark`,
       `ra`.`audit_remark`     AS `audit_remark`,
       `ra`.`is_valid`         AS `is_valid`,
       `ra`.`created_by`       AS `created_by`,
       `ra`.`updated_by`       AS `updated_by`,
       `ra`.`created_at`       AS `created_at`,
       `ra`.`updated_at`       AS `updated_at`
from `ordering`.`refund_audit` `ra`;

-- comment on column view_refund_audit_v2.application_id not supported: 退款申请ID

-- comment on column view_refund_audit_v2.payment_number not supported: 第三方支付返回支付单号

-- comment on column view_refund_audit_v2.audit_time not supported: 审核时间

-- comment on column view_refund_audit_v2.audit_status not supported: 审核状态(1:审核中, 2:已通过, 3:已取消, 4:已驳回)

-- comment on column view_refund_audit_v2.refund_back_way not supported: 退款途径(1: 线下退还, 2: 线上退还)

-- comment on column view_refund_audit_v2.apply_refund_fee not supported: 申请退款金额

-- comment on column view_refund_audit_v2.real_refund_fee not supported: 实际退款金额

-- comment on column view_refund_audit_v2.apply_remark not supported: 申请备注

-- comment on column view_refund_audit_v2.audit_remark not supported: 审核备注

-- comment on column view_refund_audit_v2.is_valid not supported: 记录是否有效

