create view view_payment_log_v2 as
select `pl`.`id`                 AS `id`,
       `pl`.`order_id`           AS `order_id`,
       `pl`.`trade_id`           AS `trade_id`,
       `pl`.`payment_id`         AS `payment_id`,
       `pl`.`shop_id`            AS `shop_id`,
       `pl`.`third_trade_number` AS `third_trade_number`,
       `pl`.`out_payment_number` AS `out_payment_number`,
       `pl`.`channel`            AS `channel`,
       `pl`.`status`             AS `status`,
       `pl`.`create_status`      AS `create_status`,
       `pl`.`execute_status`     AS `execute_status`,
       `pl`.`verify_status`      AS `verify_status`,
       `pl`.`pass_data`          AS `pass_data`,
       `pl`.`return_data`        AS `return_data`,
       `pl`.`remark`             AS `remark`,
       `pl`.`is_valid`           AS `is_valid`,
       `pl`.`created_at`         AS `created_at`,
       `pl`.`payment_number`     AS `payment_number`,
       `pl`.`trx_no`             AS `trx_no`,
       `pl`.`tp_trx_no`          AS `tp_trx_no`,
       `pl`.`is_callbacked`      AS `is_callbacked`,
       `pl`.`finished_at`        AS `finished_at`
from `ordering`.`payment_log` `pl`;

-- comment on column view_payment_log_v2.order_id not supported: 订单ID

-- comment on column view_payment_log_v2.trade_id not supported: 交易ID

-- comment on column view_payment_log_v2.payment_id not supported: 支付订单ID

-- comment on column view_payment_log_v2.shop_id not supported: 店铺ID

-- comment on column view_payment_log_v2.third_trade_number not supported: 第三方交易号

-- comment on column view_payment_log_v2.out_payment_number not supported: 不同支付渠道生成的订单号 

-- comment on column view_payment_log_v2.channel not supported: 渠道(weixin 1; alipay 2; paypal 3; bankcard 4;)

-- comment on column view_payment_log_v2.status not supported: 职位

-- comment on column view_payment_log_v2.create_status not supported: 支付创建状态(0:未创建 1:支付已创建)

-- comment on column view_payment_log_v2.execute_status not supported: 支付执行状态(0:未执行 1:执行成功 2:执行失败)

-- comment on column view_payment_log_v2.verify_status not supported: 支付校验状态(0:未校验 1:校验成功 3:校验失败)

-- comment on column view_payment_log_v2.pass_data not supported: 传出的数据

-- comment on column view_payment_log_v2.return_data not supported: 返回的数据

-- comment on column view_payment_log_v2.remark not supported: 描述

-- comment on column view_payment_log_v2.created_at not supported: 发起交易的时间

-- comment on column view_payment_log_v2.tp_trx_no not supported: 第三方机构返回的流水号

