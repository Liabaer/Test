create view view_shop_review_v2 as
select `r`.`id`                    AS `id`,
       `r`.`create_time`           AS `create_time`,
       `r`.`user_review`           AS `user_review`,
       `r`.`taste`                 AS `taste`,
       `r`.`service_attitude`      AS `service_attitude`,
       `r`.`delivery_speed`        AS `delivery_speed`,
       `r`.`delivery_man_attitude` AS `delivery_man_attitude`,
       `r`.`shop_response`         AS `shop_response`,
       `r`.`shop_response_time`    AS `shop_response_time`,
       `r`.`shop_attitude`         AS `shop_attitude`,
       `r`.`shop_review`           AS `shop_review`,
       `r`.`shop_fast_review_ids`  AS `shop_fast_review_ids`,
       `r`.`shop_fast_review`      AS `shop_fast_review`,
       `r`.`status`                AS `status`,
       `r`.`order_id`              AS `order_id`,
       `r`.`shop_id`               AS `shop_id`,
       `r`.`user_id`               AS `user_id`
from `ordering`.`review` `r`
where (`r`.`status` = 0);

-- comment on column view_shop_review_v2.shop_attitude not supported: 店铺对配送员的评分

-- comment on column view_shop_review_v2.shop_review not supported: 商家评论

-- comment on column view_shop_review_v2.shop_fast_review_ids not supported: 预定义评论id

-- comment on column view_shop_review_v2.shop_fast_review not supported: 预定义评论内容

