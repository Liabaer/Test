create view view_shop_area as
select `sa`.`id`                            AS `id`,
       `sa`.`name`                          AS `name`,
       `sa`.`city_id`                       AS `city_id`,
       `sa`.`seq`                           AS `seq`,
       `sa`.`contact_number`                AS `contact_number`,
       `sa`.`auto_confirm_order`            AS `auto_confirm_order`,
       `sa`.`order_count_limit`             AS `order_count_limit`,
       `sa`.`order_delivery_distance_limit` AS `order_delivery_distance_limit`,
       `sa`.`distance_limit`                AS `distance_limit`,
       `sa`.`show_order_tip`                AS `show_order_tip`,
       `sa`.`order_tip_content`             AS `order_tip_content`,
       `sa`.`order_tip_content_en`          AS `order_tip_content_en`,
       `sa`.`delivery_fee_rate`             AS `delivery_fee_rate`,
       `sa`.`limit_mode`                    AS `limit_mode`,
       `sa`.`limit_shop_count`              AS `limit_shop_count`,
       `sa`.`opening_hours`                 AS `opening_hours`,
       `sa`.`close_hours`                   AS `close_hours`
from `ordering`.`shop_area` `sa`;

-- comment on column view_shop_area.order_tip_content_en not supported: 英文提示内容

-- comment on column view_shop_area.opening_hours not supported: 开启营业时间

-- comment on column view_shop_area.close_hours not supported: 关闭营业时间

