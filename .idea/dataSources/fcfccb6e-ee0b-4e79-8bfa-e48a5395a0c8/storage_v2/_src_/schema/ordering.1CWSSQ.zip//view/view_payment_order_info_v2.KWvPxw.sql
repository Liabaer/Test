create view view_payment_order_info_v2 as
select `poi`.`id`                    AS `id`,
       `poi`.`mch_order_no`          AS `mch_order_no`,
       `poi`.`city_id`               AS `city_id`,
       `poi`.`trade_id`              AS `trade_id`,
       `poi`.`payment_id`            AS `payment_id`,
       `poi`.`pay_order_no`          AS `pay_order_no`,
       `poi`.`status`                AS `status`,
       `poi`.`trx_no`                AS `trx_no`,
       `poi`.`order_create_time`     AS `order_create_time`,
       `poi`.`pay_expire_time`       AS `pay_expire_time`,
       `poi`.`pay_expire_ts`         AS `pay_expire_ts`,
       `poi`.`paid_channel_id`       AS `paid_channel_id`,
       `poi`.`paid_channel_name`     AS `paid_channel_name`,
       `poi`.`paid_channel_type`     AS `paid_channel_type`,
       `poi`.`son_paid_channel_name` AS `son_paid_channel_name`,
       `poi`.`paid_local_time`       AS `paid_local_time`,
       `poi`.`paid_utc_time`         AS `paid_utc_time`,
       `poi`.`expired`               AS `expired`,
       `poi`.`expire_time`           AS `expire_time`,
       `poi`.`canceled_by`           AS `canceled_by`,
       `poi`.`canceled_time`         AS `canceled_time`
from `ordering`.`payment_order_info` `poi`;

-- comment on column view_payment_order_info_v2.city_id not supported: 城市 id

-- comment on column view_payment_order_info_v2.trade_id not supported: 交易 id

-- comment on column view_payment_order_info_v2.payment_id not supported: 支付 id

-- comment on column view_payment_order_info_v2.status not supported: 支付状态: 1未支付; 2已支付; 3支付结果确认中; 4支付超时; 5重复支付; 6退款中; 7已退款;

-- comment on column view_payment_order_info_v2.order_create_time not supported: 订单创建时间

-- comment on column view_payment_order_info_v2.pay_expire_time not supported: 订单支付本地过期时间

-- comment on column view_payment_order_info_v2.pay_expire_ts not supported: 订单支付过期的 timestamp 时间

-- comment on column view_payment_order_info_v2.paid_channel_id not supported: 支付方式 id

-- comment on column view_payment_order_info_v2.paid_channel_name not supported: 支付方式名称

-- comment on column view_payment_order_info_v2.paid_channel_type not supported: 支付方式类型

-- comment on column view_payment_order_info_v2.son_paid_channel_name not supported: 子支付名称

-- comment on column view_payment_order_info_v2.paid_local_time not supported: 支付成功本地时间

-- comment on column view_payment_order_info_v2.paid_utc_time not supported: 支付成功 utc 时间

-- comment on column view_payment_order_info_v2.expired not supported: 订单是否已经过期, 0: 未过期; 1:已过期

-- comment on column view_payment_order_info_v2.expire_time not supported: 订单本地过期时间

-- comment on column view_payment_order_info_v2.canceled_by not supported: 取消订单的顾客 id

-- comment on column view_payment_order_info_v2.canceled_time not supported: 订单被取消的时间, 本地时间

