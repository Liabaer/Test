create view view_item_channel_v2 as
select `ic`.`id`               AS `id`,
       `ic`.`shop_id`          AS `shop_id`,
       `ic`.`channel`          AS `channel`,
       `ic`.`item_id`          AS `item_id`,
       `ic`.`price`            AS `price`,
       `ic`.`group_buy`        AS `group_buy`,
       `ic`.`group_price`      AS `group_price`,
       `ic`.`is_current_price` AS `is_current_price`,
       `ic`.`adjust_price`     AS `adjust_price`,
       `ic`.`stock`            AS `stock`,
       `ic`.`status`           AS `status`,
       `ic`.`create_time`      AS `create_time`
from `ordering`.`item_channel` `ic`;

-- comment on column view_item_channel_v2.channel not supported: takeout(外卖),dinner(堂食)

-- comment on column view_item_channel_v2.adjust_price not supported: 调整金额，正数为涨价，负数为降价

