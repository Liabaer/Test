create view view_order_item_v2 as
select `oi`.`id`                    AS `id`,
       `oi`.`item_id`               AS `item_id`,
       `oi`.`code`                  AS `code`,
       `oi`.`name`                  AS `name`,
       `oi`.`name_en`               AS `name_en`,
       `oi`.`desc`                  AS `desc`,
       `oi`.`desc_en`               AS `desc_en`,
       `oi`.`price`                 AS `price`,
       `oi`.`count`                 AS `count`,
       `oi`.`order_id`              AS `order_id`,
       `oi`.`group_buy`             AS `group_buy`,
       `oi`.`adjust_price`          AS `adjust_price`,
       `oi`.`is_registered_for_vat` AS `is_registered_for_vat`,
       `oi`.`is_vat_included`       AS `is_vat_included`,
       `oi`.`vat_rate`              AS `vat_rate`
from `ordering`.`order_item` `oi`;

-- comment on column view_order_item_v2.code not supported: 商品编码

-- comment on column view_order_item_v2.is_registered_for_vat not supported: 订单商品价格是否注册增值税，0未注册，1已注册

-- comment on column view_order_item_v2.is_vat_included not supported: 订单商品价格是否包含增值税，0未包含，1包含

-- comment on column view_order_item_v2.vat_rate not supported: 订单商品增值税率

