create view view_shop_delivery_v2 as
select `ordering`.`shop_delivery`.`id`              AS `id`,
       `ordering`.`shop_delivery`.`shop_id`         AS `shop_id`,
       `ordering`.`shop_delivery`.`delivery_method` AS `delivery_method`,
       `ordering`.`shop_delivery`.`delivery_type`   AS `delivery_type`,
       `ordering`.`shop_delivery`.`created_at`      AS `created_at`
from `ordering`.`shop_delivery`;

-- comment on column view_shop_delivery_v2.shop_id not supported: 商家id

-- comment on column view_shop_delivery_v2.delivery_method not supported: 配送方式

-- comment on column view_shop_delivery_v2.delivery_type not supported: 配送类型

