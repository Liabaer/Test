create view view_shop_v2 as
select `s`.`id`                                    AS `id`,
       `s`.`name`                                  AS `name`,
       `s`.`name_en`                               AS `name_en`,
       `s`.`contact_number`                        AS `contact_number`,
       `s`.`addr`                                  AS `addr`,
       `s`.`addr_remark`                           AS `addr_remark`,
       `s`.`location`                              AS `location`,
       `s`.`location_post_code`                    AS `location_post_code`,
       `s`.`seq`                                   AS `seq`,
       `s`.`image`                                 AS `image`,
       `s`.`desc`                                  AS `desc`,
       `s`.`desc_en`                               AS `desc_en`,
       `s`.`create_time`                           AS `create_time`,
       `s`.`update_time`                           AS `update_time`,
       `s`.`delivery_type`                         AS `delivery_type`,
       `s`.`allow_pickup`                          AS `allow_pickup`,
       `s`.`type`                                  AS `type`,
       `s`.`shop_area_id`                          AS `shop_area_id`,
       `s`.`shop_style_id`                         AS `shop_style_id`,
       `s`.`real_contact_number`                   AS `real_contact_number`,
       `s`.`mobile_phone_number`                   AS `mobile_phone_number`,
       `s`.`order_pool_delay`                      AS `order_pool_delay`,
       `s`.`delivery_location_post_code_whitelist` AS `delivery_location_post_code_whitelist`,
       `s`.`city_id`                               AS `city_id`,
       `s`.`zone_id`                               AS `zone_id`,
       `s`.`abn`                                   AS `abn`,
       `s`.`is_registered_for_gst`                 AS `is_registered_for_gst`,
       `s`.`vat_rate`                              AS `vat_rate`,
       `s`.`leader_name`                           AS `leader_name`,
       `s`.`sign_person_name`                      AS `sign_person_name`,
       `s`.`sign_person_phone_number`              AS `sign_person_phone_number`,
       `s`.`sim`                                   AS `sim`,
       `s`.`bank_code`                             AS `bank_code`,
       `s`.`bsb`                                   AS `bsb`,
       `s`.`acc`                                   AS `acc`,
       `s`.`acc_name`                              AS `acc_name`,
       `s`.`platform_settlement_frequency`         AS `platform_settlement_frequency`,
       `s`.`pt`                                    AS `pt`,
       `s`.`hygienic_license_image`                AS `hygienic_license_image`,
       `s`.`hy_li_validity`                        AS `hy_li_validity`,
       `s`.`smoke_sales_license_image`             AS `smoke_sales_license_image`,
       `s`.`sm_li_validity`                        AS `sm_li_validity`,
       `s`.`liqueur_sales_license_image`           AS `liqueur_sales_license_image`,
       `s`.`li_validity`                           AS `li_validity`,
       `s`.`branch_name`                           AS `branch_name`,
       `s`.`basic_unit`                            AS `basic_unit`
from `ordering`.`shop` `s`;

-- comment on column view_shop_v2.addr_remark not supported: 地址备注

-- comment on column view_shop_v2.abn not supported: 商家ABN

-- comment on column view_shop_v2.is_registered_for_gst not supported: 商家是否注册GST, 0未注册 1已注册

-- comment on column view_shop_v2.vat_rate not supported: 商家增值税率

-- comment on column view_shop_v2.leader_name not supported: 商家负责人名称

-- comment on column view_shop_v2.sign_person_name not supported: ﻿平台销售签约人名称

-- comment on column view_shop_v2.sign_person_phone_number not supported: ﻿平台销售签约人电话

-- comment on column view_shop_v2.sim not supported: sim卡号

-- comment on column view_shop_v2.bank_code not supported: 商家银行码

-- comment on column view_shop_v2.bsb not supported: BSB

-- comment on column view_shop_v2.acc not supported: ACC

-- comment on column view_shop_v2.acc_name not supported: AccountName

-- comment on column view_shop_v2.platform_settlement_frequency not supported: 结算频次

-- comment on column view_shop_v2.pt not supported: 商家经纬度地理位置

-- comment on column view_shop_v2.hygienic_license_image not supported: 商家卫生许可证

-- comment on column view_shop_v2.smoke_sales_license_image not supported: 烟类销售许可证

-- comment on column view_shop_v2.liqueur_sales_license_image not supported: 酒类销售许可证

-- comment on column view_shop_v2.branch_name not supported: 商家分店名字

-- comment on column view_shop_v2.basic_unit not supported: 基础单元

