create view view_coupon as
select `c`.`id`            AS `id`,
       `c`.`name`          AS `name`,
       `c`.`name_en`       AS `name_en`,
       `c`.`type`          AS `type`,
       `c`.`discount`      AS `discount`,
       `c`.`threshold_fee` AS `threshold_fee`,
       `c`.`valid_days`    AS `valid_days`,
       `c`.`status`        AS `status`,
       `c`.`city_id`       AS `city_id`,
       `c`.`payment_type`  AS `payment_type`,
       `c`.`distance`      AS `distance`,
       `c`.`created_by`    AS `created_by`,
       `c`.`create_time`   AS `create_time`
from `ordering`.`coupon` `c`;

-- comment on column view_coupon.threshold_fee not supported: 门槛金额

-- comment on column view_coupon.payment_type not supported: 优惠券支付方式

-- comment on column view_coupon.distance not supported: 优惠券距离限制

-- comment on column view_coupon.created_by not supported: 创建者类型, 0:管理员, 1:系统

