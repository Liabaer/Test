create view view_shop_settlement_opening_balance_v2 as
select `ordering`.`shop_settlement_opening_balance`.`id`                      AS `id`,
       `ordering`.`shop_settlement_opening_balance`.`city_id`                 AS `city_id`,
       `ordering`.`shop_settlement_opening_balance`.`shop_id`                 AS `shop_id`,
       `ordering`.`shop_settlement_opening_balance`.`transfer_id`             AS `transfer_id`,
       `ordering`.`shop_settlement_opening_balance`.`transfer_item_id`        AS `transfer_item_id`,
       `ordering`.`shop_settlement_opening_balance`.`opening_balance_id`      AS `opening_balance_id`,
       `ordering`.`shop_settlement_opening_balance`.`opening_balance_item_id` AS `opening_balance_item_id`,
       `ordering`.`shop_settlement_opening_balance`.`amount`                  AS `amount`,
       `ordering`.`shop_settlement_opening_balance`.`status`                  AS `status`,
       `ordering`.`shop_settlement_opening_balance`.`create_time`             AS `create_time`,
       `ordering`.`shop_settlement_opening_balance`.`update_time`             AS `update_time`
from `ordering`.`shop_settlement_opening_balance`;

-- comment on column view_shop_settlement_opening_balance_v2.city_id not supported: 城市ID

-- comment on column view_shop_settlement_opening_balance_v2.shop_id not supported: 商家ID

-- comment on column view_shop_settlement_opening_balance_v2.transfer_id not supported: 转账批次ID

-- comment on column view_shop_settlement_opening_balance_v2.transfer_item_id not supported: 转Item ID

-- comment on column view_shop_settlement_opening_balance_v2.opening_balance_id not supported: 关联的Transfer批次ID

-- comment on column view_shop_settlement_opening_balance_v2.opening_balance_item_id not supported: 关联的Transfer Item ID

-- comment on column view_shop_settlement_opening_balance_v2.amount not supported: 结算金额

-- comment on column view_shop_settlement_opening_balance_v2.status not supported: 状态, pending=未转账, done=已转账, canceled=已撤销

