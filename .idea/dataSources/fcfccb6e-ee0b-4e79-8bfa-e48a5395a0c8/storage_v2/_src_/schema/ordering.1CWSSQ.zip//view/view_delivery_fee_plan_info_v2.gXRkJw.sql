create view view_delivery_fee_plan_info_v2 as
select `ordering`.`delivery_fee_plan_info`.`id`             AS `id`,
       `ordering`.`delivery_fee_plan_info`.`city_id`        AS `city_id`,
       `ordering`.`delivery_fee_plan_info`.`name`           AS `name`,
       `ordering`.`delivery_fee_plan_info`.`start_step_fee` AS `start_step_fee`,
       `ordering`.`delivery_fee_plan_info`.`free_distance`  AS `free_distance`,
       `ordering`.`delivery_fee_plan_info`.`distance_unit`  AS `distance_unit`,
       `ordering`.`delivery_fee_plan_info`.`is_deleted`     AS `is_deleted`,
       `ordering`.`delivery_fee_plan_info`.`create_time`    AS `create_time`,
       `ordering`.`delivery_fee_plan_info`.`update_time`    AS `update_time`
from `ordering`.`delivery_fee_plan_info`;

-- comment on column view_delivery_fee_plan_info_v2.name not supported: 名称

-- comment on column view_delivery_fee_plan_info_v2.start_step_fee not supported: 起步价

-- comment on column view_delivery_fee_plan_info_v2.free_distance not supported: 免费配送距离

-- comment on column view_delivery_fee_plan_info_v2.distance_unit not supported: 计算费用的最小距离单位

-- comment on column view_delivery_fee_plan_info_v2.is_deleted not supported: 删除状态 0未删除 1删除

