create view view_log_v2 as
select `l`.`id`          AS `id`,
       `l`.`type`        AS `type`,
       `l`.`oper_id`     AS `oper_id`,
       `l`.`relate_id`   AS `relate_id`,
       `l`.`create_time` AS `create_time`,
       `l`.`desc`        AS `desc`
from `ordering`.`log` `l`;

