create view view_order_item_option_group as
select `oiog`.`id`            AS `id`,
       `oiog`.`order_item_id` AS `order_item_id`,
       `oiog`.`name`          AS `name`,
       `oiog`.`name_en`       AS `name_en`,
       `oiog`.`mode`          AS `mode`,
       `oiog`.`limit`         AS `limit`,
       `oiog`.`min`           AS `min`
from `ordering`.`order_item_option_group` `oiog`;

-- comment on column view_order_item_option_group.min not supported: 最少添加数量, 0:不限制, n:最少添加n个

