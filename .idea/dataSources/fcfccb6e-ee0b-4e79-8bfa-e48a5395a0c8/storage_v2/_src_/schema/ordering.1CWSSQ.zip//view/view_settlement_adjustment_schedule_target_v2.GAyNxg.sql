create view view_settlement_adjustment_schedule_target_v2 as
select `sast`.`id`                       AS `id`,
       `sast`.`city_id`                  AS `city_id`,
       `sast`.`settlement_adjustment_id` AS `settlement_adjustment_id`,
       `sast`.`schedule_id`              AS `schedule_id`,
       `sast`.`schedule_amount`          AS `schedule_amount`,
       `sast`.`schedule_time`            AS `schedule_time`,
       `sast`.`target_type`              AS `target_type`,
       `sast`.`target_id`                AS `target_id`,
       `sast`.`target_name`              AS `target_name`,
       `sast`.`settlement_id`            AS `settlement_id`,
       `sast`.`shop_settlement_id`       AS `shop_settlement_id`,
       `sast`.`status`                   AS `status`
from `ordering`.`settlement_adjustment_schedule_target` `sast`;

-- comment on column view_settlement_adjustment_schedule_target_v2.city_id not supported: 城市ID

-- comment on column view_settlement_adjustment_schedule_target_v2.settlement_adjustment_id not supported: 调账id

-- comment on column view_settlement_adjustment_schedule_target_v2.schedule_id not supported: 调账计划id

-- comment on column view_settlement_adjustment_schedule_target_v2.schedule_amount not supported: 计划调账金额

-- comment on column view_settlement_adjustment_schedule_target_v2.schedule_time not supported: 计划时间

-- comment on column view_settlement_adjustment_schedule_target_v2.target_type not supported: 调账计划对象, courier配送员, shop商家

-- comment on column view_settlement_adjustment_schedule_target_v2.target_id not supported: 调账对象id

-- comment on column view_settlement_adjustment_schedule_target_v2.target_name not supported: 调账对象名称

-- comment on column view_settlement_adjustment_schedule_target_v2.settlement_id not supported: 配送员结算id

-- comment on column view_settlement_adjustment_schedule_target_v2.shop_settlement_id not supported: 商家结算id

-- comment on column view_settlement_adjustment_schedule_target_v2.status not supported: 调账计划对象状态, active待结算, settled已结算, canceled已取消

