create view view_refund_application_v2 as
select `ra`.`id`                AS `id`,
       `ra`.`order_id`          AS `order_id`,
       `ra`.`payment_number`    AS `payment_number`,
       `ra`.`shop_id`           AS `shop_id`,
       `ra`.`city_id`           AS `city_id`,
       `ra`.`scene`             AS `scene`,
       `ra`.`refund_type`       AS `refund_type`,
       `ra`.`refund_back_way`   AS `refund_back_way`,
       `ra`.`reason_id`         AS `reason_id`,
       `ra`.`applicant_id`      AS `applicant_id`,
       `ra`.`apply_time`        AS `apply_time`,
       `ra`.`audit_time`        AS `audit_time`,
       `ra`.`audit_status`      AS `audit_status`,
       `ra`.`apply_refund_fee`  AS `apply_refund_fee`,
       `ra`.`real_refund_fee`   AS `real_refund_fee`,
       `ra`.`is_valid`          AS `is_valid`,
       `ra`.`remark`            AS `remark`,
       `ra`.`created_by`        AS `created_by`,
       `ra`.`created_user_name` AS `created_user_name`,
       `ra`.`updated_by`        AS `updated_by`,
       `ra`.`created_at`        AS `created_at`,
       `ra`.`updated_at`        AS `updated_at`
from `ordering`.`refund_application` `ra`;

-- comment on column view_refund_application_v2.order_id not supported: 订单ID

-- comment on column view_refund_application_v2.payment_number not supported: 第三方支付返回支付单号

-- comment on column view_refund_application_v2.shop_id not supported: 店铺ID

-- comment on column view_refund_application_v2.city_id not supported: 城市ID

-- comment on column view_refund_application_v2.scene not supported: 交易场景(外卖 1; 堂食 2; 快餐 3)

-- comment on column view_refund_application_v2.refund_type not supported: 退款类型(1: 全额退款  2: 部分退款)

-- comment on column view_refund_application_v2.refund_back_way not supported: 退款途径(1.线上退款-原路退回, 2.线下退款-转账, 3.线下退款-优惠券)

-- comment on column view_refund_application_v2.reason_id not supported: 退款原因

-- comment on column view_refund_application_v2.applicant_id not supported: 申请人ID, 系统主动退款为0

-- comment on column view_refund_application_v2.apply_time not supported: 申请时间

-- comment on column view_refund_application_v2.audit_time not supported: 最近一次审核时间

-- comment on column view_refund_application_v2.audit_status not supported: 审核状态(1:审核中, 2:已通过, 3:已取消, 4:已驳回)

-- comment on column view_refund_application_v2.apply_refund_fee not supported: 申请退款金额

-- comment on column view_refund_application_v2.real_refund_fee not supported: 实际退款金额

-- comment on column view_refund_application_v2.is_valid not supported: 记录是否有效

-- comment on column view_refund_application_v2.created_by not supported: 创建记录用户ID，如为系统创建为0

-- comment on column view_refund_application_v2.created_user_name not supported: 创建人姓名

-- comment on column view_refund_application_v2.updated_by not supported: 更新记录用户ID

