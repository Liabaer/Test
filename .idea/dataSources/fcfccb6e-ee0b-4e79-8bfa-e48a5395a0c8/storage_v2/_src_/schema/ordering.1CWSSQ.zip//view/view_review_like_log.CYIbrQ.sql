create view view_review_like_log as
select `ordering`.`review_like_log`.`id`          AS `id`,
       `ordering`.`review_like_log`.`review_id`   AS `review_id`,
       `ordering`.`review_like_log`.`user_id`     AS `user_id`,
       `ordering`.`review_like_log`.`create_time` AS `create_time`,
       `ordering`.`review_like_log`.`status`      AS `status`
from `ordering`.`review_like_log`;

-- comment on column view_review_like_log.review_id not supported: 评论

-- comment on column view_review_like_log.user_id not supported: 商家标签id列表

-- comment on column view_review_like_log.create_time not supported: 结束调度时间

-- comment on column view_review_like_log.status not supported: 0点赞 1取消点赞

