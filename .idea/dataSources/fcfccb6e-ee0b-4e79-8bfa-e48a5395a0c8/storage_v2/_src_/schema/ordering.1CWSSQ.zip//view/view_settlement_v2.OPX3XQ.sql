create view view_settlement_v2 as
select `s`.`id`               AS `id`,
       `s`.`city_id`          AS `city_id`,
       `s`.`direction`        AS `direction`,
       `s`.`type`             AS `type`,
       `s`.`courier_id`       AS `courier_id`,
       `s`.`fee`              AS `fee`,
       `s`.`image`            AS `image`,
       `s`.`status`           AS `status`,
       `s`.`wallet_amount`    AS `wallet_amount`,
       `s`.`wallet_detail_id` AS `wallet_detail_id`,
       `s`.`settlement_code`  AS `settlement_code`,
       `s`.`desc`             AS `desc`,
       `s`.`transfer_id`      AS `transfer_id`,
       `s`.`created_by`       AS `created_by`,
       `s`.`creator_name`     AS `creator_name`,
       `s`.`created_at`       AS `created_at`,
       `s`.`updated_by`       AS `updated_by`,
       `s`.`updater_name`     AS `updater_name`,
       `s`.`updated_at`       AS `updated_at`
from `ordering`.`settlement` `s`;

-- comment on column view_settlement_v2.city_id not supported: 城市id

-- comment on column view_settlement_v2.direction not supported: 结算方向, 0:送餐平台到HR; 1:HR到配送员; 2:配送员到HR; 3:HR到送餐平台

-- comment on column view_settlement_v2.type not supported: 结算类型, 0:现金; 1:转账, 2:系统(线上支付结算)

-- comment on column view_settlement_v2.courier_id not supported: 配送员ID

-- comment on column view_settlement_v2.fee not supported: 结算金额

-- comment on column view_settlement_v2.image not supported: 结算图片凭据

-- comment on column view_settlement_v2.status not supported: 结算状态, 0:已撤销; 1:待转账; 2:转账中; 3:已转账

-- comment on column view_settlement_v2.wallet_amount not supported: 钱包抵扣金额, 默认为0.00

-- comment on column view_settlement_v2.wallet_detail_id not supported: 钱包明细ID, 默认为0

-- comment on column view_settlement_v2.settlement_code not supported: 配送员结算码

-- comment on column view_settlement_v2.transfer_id not supported: 转账ID, 默认为0

-- comment on column view_settlement_v2.created_by not supported: 结算人ID

-- comment on column view_settlement_v2.creator_name not supported: 结算人名称

-- comment on column view_settlement_v2.updated_by not supported: 更新人ID

-- comment on column view_settlement_v2.updater_name not supported: 更新人名称

