create view view_courier_evaluation_sms_log as
select `ordering`.`courier_evaluation_sms_log`.`id`               AS `id`,
       `ordering`.`courier_evaluation_sms_log`.`city_id`          AS `city_id`,
       `ordering`.`courier_evaluation_sms_log`.`courier_id`       AS `courier_id`,
       `ordering`.`courier_evaluation_sms_log`.`courier_name`     AS `courier_name`,
       `ordering`.`courier_evaluation_sms_log`.`related_order_id` AS `related_order_id`,
       `ordering`.`courier_evaluation_sms_log`.`type`             AS `type`,
       `ordering`.`courier_evaluation_sms_log`.`remark`           AS `remark`,
       `ordering`.`courier_evaluation_sms_log`.`status`           AS `status`,
       `ordering`.`courier_evaluation_sms_log`.`created_at`       AS `created_at`
from `ordering`.`courier_evaluation_sms_log`;

-- comment on column view_courier_evaluation_sms_log.courier_name not supported: 配送员名称

-- comment on column view_courier_evaluation_sms_log.type not supported: 日志操作类型，start_delivery开始配送，complete_delivery完成配送

-- comment on column view_courier_evaluation_sms_log.status not supported: 日志状态，active激活状态，archived已归档

