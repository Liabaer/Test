create view view_exclusive_event_user_relation_v2 as
select `ordering`.`exclusive_event_user_relation`.`id`          AS `id`,
       `ordering`.`exclusive_event_user_relation`.`event_id`    AS `event_id`,
       `ordering`.`exclusive_event_user_relation`.`user_id`     AS `user_id`,
       `ordering`.`exclusive_event_user_relation`.`create_date` AS `create_date`,
       `ordering`.`exclusive_event_user_relation`.`create_time` AS `create_time`
from `ordering`.`exclusive_event_user_relation`;

