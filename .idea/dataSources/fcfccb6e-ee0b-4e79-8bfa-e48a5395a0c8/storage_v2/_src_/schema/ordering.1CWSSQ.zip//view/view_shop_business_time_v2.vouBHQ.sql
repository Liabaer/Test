create view view_shop_business_time_v2 as
select `sbt`.`id`         AS `id`,
       `sbt`.`open_time`  AS `open_time`,
       `sbt`.`close_time` AS `close_time`,
       `sbt`.`week_day`   AS `week_day`,
       `sbt`.`shop_id`    AS `shop_id`
from `ordering`.`shop_business_time` `sbt`;

