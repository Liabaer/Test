create view view_shop_settlement_v2 as
select `ss`.`id`           AS `id`,
       `ss`.`city_id`      AS `city_id`,
       `ss`.`shop_id`      AS `shop_id`,
       `ss`.`fee`          AS `fee`,
       `ss`.`start_date`   AS `start_date`,
       `ss`.`end_date`     AS `end_date`,
       `ss`.`desc`         AS `desc`,
       `ss`.`status`       AS `status`,
       `ss`.`transfer_id`  AS `transfer_id`,
       `ss`.`created_by`   AS `created_by`,
       `ss`.`creator_name` AS `creator_name`,
       `ss`.`created_at`   AS `created_at`,
       `ss`.`updated_by`   AS `updated_by`,
       `ss`.`updater_name` AS `updater_name`,
       `ss`.`updated_at`   AS `updated_at`
from `ordering`.`shop_settlement` `ss`;

-- comment on column view_shop_settlement_v2.city_id not supported: 城市id

-- comment on column view_shop_settlement_v2.shop_id not supported: 商家id

-- comment on column view_shop_settlement_v2.fee not supported: 结算金额

-- comment on column view_shop_settlement_v2.start_date not supported: 结算开始日期

-- comment on column view_shop_settlement_v2.end_date not supported: 结算结束日期

-- comment on column view_shop_settlement_v2.status not supported: 结算状态, 0:已撤销; 1:待转账; 2:转账中; 3:已转账

-- comment on column view_shop_settlement_v2.transfer_id not supported: 转账id, 默认为0

-- comment on column view_shop_settlement_v2.created_by not supported: 结算人id

-- comment on column view_shop_settlement_v2.creator_name not supported: 结算人名称

-- comment on column view_shop_settlement_v2.updated_by not supported: 更新人id

-- comment on column view_shop_settlement_v2.updater_name not supported: 更新人名称

