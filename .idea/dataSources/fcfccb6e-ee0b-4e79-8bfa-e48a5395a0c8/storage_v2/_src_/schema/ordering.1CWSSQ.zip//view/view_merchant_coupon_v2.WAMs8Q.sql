create view view_merchant_coupon_v2 as
select `mc`.`id`              AS `id`,
       `mc`.`code`            AS `code`,
       `mc`.`city_id`         AS `city_id`,
       `mc`.`shop_id`         AS `shop_id`,
       `mc`.`discount`        AS `discount`,
       `mc`.`threshold_fee`   AS `threshold_fee`,
       `mc`.`count`           AS `count`,
       `mc`.`condition`       AS `condition`,
       `mc`.`valid_unit`      AS `valid_unit`,
       `mc`.`valid_val`       AS `valid_val`,
       `mc`.`send_start_time` AS `send_start_time`,
       `mc`.`send_end_time`   AS `send_end_time`,
       `mc`.`is_subsidy`      AS `is_subsidy`,
       `mc`.`subsidy_fee`     AS `subsidy_fee`,
       `mc`.`is_public`       AS `is_public`,
       `mc`.`status`          AS `status`,
       `mc`.`is_del`          AS `is_del`,
       `mc`.`create_time`     AS `create_time`
from `ordering`.`merchant_coupon` `mc`;

-- comment on column view_merchant_coupon_v2.discount not supported: 优惠券金额

-- comment on column view_merchant_coupon_v2.threshold_fee not supported: 门槛金额

-- comment on column view_merchant_coupon_v2.count not supported: 优惠券数量

-- comment on column view_merchant_coupon_v2.`condition` not supported: 使用条件

-- comment on column view_merchant_coupon_v2.is_subsidy not supported: 是否启用平台补贴

-- comment on column view_merchant_coupon_v2.subsidy_fee not supported: 平台补贴金额

