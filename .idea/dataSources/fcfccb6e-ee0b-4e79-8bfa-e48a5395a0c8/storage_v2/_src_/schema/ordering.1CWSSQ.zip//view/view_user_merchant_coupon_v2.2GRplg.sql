create view view_user_merchant_coupon_v2 as
select `umc`.`id`                 AS `id`,
       `umc`.`city_id`            AS `city_id`,
       `umc`.`shop_id`            AS `shop_id`,
       `umc`.`shop_name`          AS `shop_name`,
       `umc`.`shop_name_en`       AS `shop_name_en`,
       `umc`.`merchant_coupon_id` AS `merchant_coupon_id`,
       `umc`.`user_id`            AS `user_id`,
       `umc`.`order_id`           AS `order_id`,
       `umc`.`discount`           AS `discount`,
       `umc`.`threshold_fee`      AS `threshold_fee`,
       `umc`.`subsidy_fee`        AS `subsidy_fee`,
       `umc`.`condition`          AS `condition`,
       `umc`.`is_subsidy`         AS `is_subsidy`,
       `umc`.`valid_unit`         AS `valid_unit`,
       `umc`.`valid_val`          AS `valid_val`,
       `umc`.`expire_time`        AS `expire_time`,
       `umc`.`status`             AS `status`,
       `umc`.`chan`               AS `chan`,
       `umc`.`chan_id`            AS `chan_id`,
       `umc`.`create_time`        AS `create_time`,
       `umc`.`update_time`        AS `update_time`
from `ordering`.`user_merchant_coupon` `umc`;

-- comment on column view_user_merchant_coupon_v2.discount not supported: 优惠券金额

-- comment on column view_user_merchant_coupon_v2.threshold_fee not supported: 门槛金额

-- comment on column view_user_merchant_coupon_v2.subsidy_fee not supported: 平台补贴金额

-- comment on column view_user_merchant_coupon_v2.`condition` not supported: 使用条件

-- comment on column view_user_merchant_coupon_v2.is_subsidy not supported: 是否启用平台补贴

-- comment on column view_user_merchant_coupon_v2.expire_time not supported: 过期时间

-- comment on column view_user_merchant_coupon_v2.chan not supported: 来源渠道

-- comment on column view_user_merchant_coupon_v2.chan_id not supported: 来源渠道ID

