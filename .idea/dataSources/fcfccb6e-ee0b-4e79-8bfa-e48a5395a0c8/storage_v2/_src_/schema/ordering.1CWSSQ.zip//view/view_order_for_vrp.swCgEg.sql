create view view_order_for_vrp as
select `ordering`.`order`.`id`                   AS `id`,
       `ordering`.`order`.`distance`             AS `distance`,
       `ordering`.`order`.`courier_id`           AS `courier_id`,
       `ordering`.`order`.`courier_delivery_fee` AS `courier_delivery_fee`,
       `ordering`.`order`.`location`             AS `location`,
       `ordering`.`order`.`shop_id`              AS `shop_id`
from `ordering`.`order`;

-- comment on column view_order_for_vrp.courier_delivery_fee not supported: 配送员实际配送费收入，按配送员配送费计算规则得出

