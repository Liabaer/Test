create view view_front_back_tags_connection_v2 as
select `fbtc`.`front_tag_id` AS `front_tag_id`, `fbtc`.`back_tag_id` AS `back_tag_id`, `fbtc`.`city_id` AS `city_id`
from `ordering`.`front_back_tags_connection` `fbtc`;

