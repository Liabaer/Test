create view view_tags_shop_v2 as
select `ts`.`tag_id` AS `tag_id`, `ts`.`shop_id` AS `shop_id`, `ts`.`city_id` AS `city_id`
from `ordering`.`shop_tag_connection` `ts`;

-- comment on column view_tags_shop_v2.tag_id not supported: 标签id

-- comment on column view_tags_shop_v2.shop_id not supported: shop的id

-- comment on column view_tags_shop_v2.city_id not supported: 城市id

