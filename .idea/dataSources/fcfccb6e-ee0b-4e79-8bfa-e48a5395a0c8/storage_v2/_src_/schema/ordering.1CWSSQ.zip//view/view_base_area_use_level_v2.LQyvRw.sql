create view view_base_area_use_level_v2 as
select `baul`.`id`            AS `id`,
       `baul`.`level`         AS `level`,
       `baul`.`base_area_id`  AS `base_area_id`,
       `baul`.`fence_area_id` AS `fence_area_id`,
       `baul`.`create_time`   AS `create_time`,
       `baul`.`update_time`   AS `update_time`,
       `baul`.`type`          AS `type`
from `ordering`.`base_area_use_level` `baul`;

-- comment on column view_base_area_use_level_v2.level not supported: 使用基础单元的组合单元等级

-- comment on column view_base_area_use_level_v2.base_area_id not supported: 基础单元id

-- comment on column view_base_area_use_level_v2.fence_area_id not supported: 组合单元区域id

-- comment on column view_base_area_use_level_v2.create_time not supported: 创建时间

-- comment on column view_base_area_use_level_v2.update_time not supported: 更新时间

-- comment on column view_base_area_use_level_v2.type not supported: 使用基础单元的组合单元的类型

