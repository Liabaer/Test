create view view_user_tag_connection_v2 as
select `ordering`.`user_tag_connection`.`user_id` AS `user_id`,
       `ordering`.`user_tag_connection`.`tag_id`  AS `tag_id`,
       `ordering`.`user_tag_connection`.`type`    AS `type`,
       `ordering`.`user_tag_connection`.`city_id` AS `city_id`
from `ordering`.`user_tag_connection`;

-- comment on column view_user_tag_connection_v2.user_id not supported: 用户id

-- comment on column view_user_tag_connection_v2.tag_id not supported: 用户标签id

-- comment on column view_user_tag_connection_v2.type not supported: 1代表excel文件导入的能够直接查询出来的用户id,2代表时规则类型,用户是按照规则筛选出来的

-- comment on column view_user_tag_connection_v2.city_id not supported: 城市id

