create view view_shop_credit_note as
select `scn`.`id`             AS `id`,
       `scn`.`city_id`        AS `city_id`,
       `scn`.`type`           AS `type`,
       `scn`.`shop_id`        AS `shop_id`,
       `scn`.`shop_name`      AS `shop_name`,
       `scn`.`order_id`       AS `order_id`,
       `scn`.`amount`         AS `amount`,
       `scn`.`refund_reason`  AS `reason`,
       `scn`.`coupon_scope`   AS `coupon_scope`,
       `scn`.`coupon_id`      AS `coupon_id`,
       `scn`.`user_coupon_id` AS `user_coupon_id`,
       `scn`.`remark`         AS `remark`,
       `scn`.`created_at`     AS `create_time`
from `ordering`.`shop_credit_note` `scn`
where (`scn`.`status` = 2);

-- comment on column view_shop_credit_note.city_id not supported: 城市id

-- comment on column view_shop_credit_note.type not supported: 类型, 0部分退款, 1补差价

-- comment on column view_shop_credit_note.shop_id not supported: 商家id

-- comment on column view_shop_credit_note.shop_name not supported: 商家名称

-- comment on column view_shop_credit_note.order_id not supported: 订单id

-- comment on column view_shop_credit_note.amount not supported: 金额

-- comment on column view_shop_credit_note.reason not supported: 退款原因

-- comment on column view_shop_credit_note.coupon_scope not supported: 发放优惠券范围，0全部商家，1订单商家

-- comment on column view_shop_credit_note.coupon_id not supported: 优惠券id

-- comment on column view_shop_credit_note.user_coupon_id not supported: 用户优惠券id

-- comment on column view_shop_credit_note.remark not supported: 备注信息

-- comment on column view_shop_credit_note.create_time not supported: 创建时间

