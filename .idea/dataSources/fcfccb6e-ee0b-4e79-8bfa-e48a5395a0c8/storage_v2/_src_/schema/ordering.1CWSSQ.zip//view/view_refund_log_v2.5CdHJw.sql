create view view_refund_log_v2 as
select `rl`.`id`                  AS `id`,
       `rl`.`shop_id`             AS `shop_id`,
       `rl`.`trade_id`            AS `trade_id`,
       `rl`.`order_id`            AS `order_id`,
       `rl`.`channel`             AS `channel`,
       `rl`.`refund_number`       AS `refund_number`,
       `rl`.`third_refund_number` AS `third_refund_number`,
       `rl`.`pass_data`           AS `pass_data`,
       `rl`.`return_data`         AS `return_data`,
       `rl`.`remark`              AS `remark`,
       `rl`.`is_invoke_success`   AS `is_invoke_success`,
       `rl`.`is_direct_operation` AS `is_direct_operation`,
       `rl`.`created_at`          AS `created_at`,
       `rl`.`updated_at`          AS `updated_at`
from `ordering`.`refund_log` `rl`;

-- comment on column view_refund_log_v2.shop_id not supported: 店铺ID

-- comment on column view_refund_log_v2.trade_id not supported: 交易ID

-- comment on column view_refund_log_v2.order_id not supported: easi订单ID, 其他渠道订单id为空

-- comment on column view_refund_log_v2.channel not supported: 渠道(1:weixin; 2:alipay; 3:paypal; 4:bankcard)

-- comment on column view_refund_log_v2.refund_number not supported: 退款单号

-- comment on column view_refund_log_v2.third_refund_number not supported: 第三方退款单号

-- comment on column view_refund_log_v2.pass_data not supported: 传出的数据

-- comment on column view_refund_log_v2.return_data not supported: 返回的数据

-- comment on column view_refund_log_v2.remark not supported: 描述

-- comment on column view_refund_log_v2.is_invoke_success not supported: 是否调用成功

-- comment on column view_refund_log_v2.is_direct_operation not supported: 是否通过后台直接退款

-- comment on column view_refund_log_v2.created_at not supported: 发起调用的时间

-- comment on column view_refund_log_v2.updated_at not supported: 调用完成的时间

