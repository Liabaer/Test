create view view_order_item as
select `oi`.`id`           AS `id`,
       `oi`.`order_id`     AS `order_id`,
       `oi`.`item_id`      AS `item_id`,
       `oi`.`code`         AS `code`,
       `oi`.`name`         AS `name`,
       `oi`.`name_en`      AS `name_en`,
       `oi`.`price`        AS `price`,
       `oi`.`count`        AS `count`,
       `oi`.`group_buy`    AS `group_buy`,
       `oi`.`adjust_price` AS `adjust_price`
from `ordering`.`order_item` `oi`;

-- comment on column view_order_item.code not supported: 商品编码

