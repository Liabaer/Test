create view view_order_feedback as
select `of`.`id`          AS `id`,
       `of`.`city_id`     AS `city_id`,
       `of`.`order_id`    AS `order_id`,
       `of`.`user_id`     AS `user_id`,
       `of`.`type`        AS `type`,
       `of`.`feedback`    AS `feedback`,
       `of`.`create_time` AS `create_time`,
       `of`.`update_time` AS `update_time`
from `ordering`.`order_feedback` `of`;

-- comment on column view_order_feedback.city_id not supported: 城市id

-- comment on column view_order_feedback.order_id not supported: 订单ID

-- comment on column view_order_feedback.user_id not supported: 用户ID

-- comment on column view_order_feedback.type not supported: 反馈类型 10: 顾客是否收到餐

-- comment on column view_order_feedback.feedback not supported:  反馈结果

-- comment on column view_order_feedback.create_time not supported: 创建时间

-- comment on column view_order_feedback.update_time not supported: 更新时间

