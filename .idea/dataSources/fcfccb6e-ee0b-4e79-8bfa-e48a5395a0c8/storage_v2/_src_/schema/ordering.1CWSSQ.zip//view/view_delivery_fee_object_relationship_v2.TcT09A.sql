create view view_delivery_fee_object_relationship_v2 as
select `ordering`.`delivery_fee_object_relationship`.`id`          AS `id`,
       `ordering`.`delivery_fee_object_relationship`.`city_id`     AS `city_id`,
       `ordering`.`delivery_fee_object_relationship`.`filter_type` AS `filter_type`,
       `ordering`.`delivery_fee_object_relationship`.`object_type` AS `object_type`,
       `ordering`.`delivery_fee_object_relationship`.`object_id`   AS `object_id`,
       `ordering`.`delivery_fee_object_relationship`.`plan_id`     AS `plan_id`,
       `ordering`.`delivery_fee_object_relationship`.`status`      AS `status`,
       `ordering`.`delivery_fee_object_relationship`.`create_time` AS `create_time`,
       `ordering`.`delivery_fee_object_relationship`.`update_time` AS `update_time`
from `ordering`.`delivery_fee_object_relationship`;

-- comment on column view_delivery_fee_object_relationship_v2.filter_type not supported: 对应的过滤类型---1（客人）2（配送员）3（商家）

-- comment on column view_delivery_fee_object_relationship_v2.object_type not supported: object_id 类型---2（配送员）3（商家）

-- comment on column view_delivery_fee_object_relationship_v2.object_id not supported: 配送员/商家ID

-- comment on column view_delivery_fee_object_relationship_v2.plan_id not supported: 对应的具体方案ID（delivery_fee_plan_info表）

-- comment on column view_delivery_fee_object_relationship_v2.status not supported: 开关状态 0关闭 1开启

