create view view_order_pool_v2 as
select `op`.`id`             AS `id`,
       `op`.`type`           AS `type`,
       `op`.`status`         AS `status`,
       `op`.`create_time`    AS `create_time`,
       `op`.`order_id`       AS `order_id`,
       `op`.`is_self_system` AS `is_self_system`,
       `op`.`assign_num`     AS `assign_num`,
       `op`.`assign_type`    AS `assign_type`,
       `op`.`update_time`    AS `update_time`,
       `op`.`city_id`        AS `city_id`,
       `op`.`shop_area_id`   AS `shop_area_id`,
       `op`.`shop_post_code` AS `shop_post_code`,
       `op`.`shop_location`  AS `shop_location`,
       `op`.`order_distance` AS `order_distance`
from `ordering`.`order_pool` `op`;

-- comment on column view_order_pool_v2.type not supported: 订单分配情况的类型（1=普通单、2=任务单、3=孤儿单、4=急救单）

-- comment on column view_order_pool_v2.order_id not supported: 分配的订单ID

-- comment on column view_order_pool_v2.is_self_system not supported: 是否是自己系统分配的订单

-- comment on column view_order_pool_v2.assign_num not supported: 订单分配次数

-- comment on column view_order_pool_v2.assign_type not supported: 订单分配类型

-- comment on column view_order_pool_v2.update_time not supported: 订单池任务更新时间

-- comment on column view_order_pool_v2.city_id not supported: 订单城市ID

-- comment on column view_order_pool_v2.shop_area_id not supported: 订单区域ID

-- comment on column view_order_pool_v2.shop_post_code not supported: 订单商户邮编ID

-- comment on column view_order_pool_v2.shop_location not supported: 商铺地址经纬度

-- comment on column view_order_pool_v2.order_distance not supported: 订单距离

