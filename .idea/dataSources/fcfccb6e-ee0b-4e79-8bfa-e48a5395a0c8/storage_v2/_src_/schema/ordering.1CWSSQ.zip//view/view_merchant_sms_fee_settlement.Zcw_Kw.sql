create view view_merchant_sms_fee_settlement as
select `ordering`.`merchant_sms_send_log`.`city_id`                              AS `city_id`,
       `ordering`.`merchant_sms_send_log`.`shop_id`                              AS `shop_id`,
       sum(`ordering`.`merchant_sms_send_log`.`fee`)                             AS `fee_total`,
       date_format(`ordering`.`merchant_sms_send_log`.`create_time`, '%Y.%m.%d') AS `day`
from `ordering`.`merchant_sms_send_log`
group by `ordering`.`merchant_sms_send_log`.`shop_id`, `day`;

