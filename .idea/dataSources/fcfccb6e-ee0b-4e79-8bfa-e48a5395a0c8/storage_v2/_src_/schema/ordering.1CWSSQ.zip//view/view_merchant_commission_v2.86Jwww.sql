create view view_merchant_commission_v2 as
select `ordering`.`merchant_commission`.`id`              AS `id`,
       `ordering`.`merchant_commission`.`shop_id`         AS `shop_id`,
       `ordering`.`merchant_commission`.`delivery_type`   AS `delivery_type`,
       `ordering`.`merchant_commission`.`pickup_type`     AS `pickup_type`,
       `ordering`.`merchant_commission`.`commission_rate` AS `commission_rate`,
       `ordering`.`merchant_commission`.`commission_fix`  AS `commission_fix`,
       `ordering`.`merchant_commission`.`commission_min`  AS `commission_min`,
       `ordering`.`merchant_commission`.`admin_id`        AS `admin_id`,
       `ordering`.`merchant_commission`.`city_id`         AS `city_id`,
       `ordering`.`merchant_commission`.`create_time`     AS `create_time`
from `ordering`.`merchant_commission`;

-- comment on column view_merchant_commission_v2.shop_id not supported: 商家id

-- comment on column view_merchant_commission_v2.delivery_type not supported: 配送方式

-- comment on column view_merchant_commission_v2.pickup_type not supported: 自取方式 0-带走 1-堂食

-- comment on column view_merchant_commission_v2.commission_rate not supported: 佣金比例

-- comment on column view_merchant_commission_v2.commission_fix not supported: 固定佣金

-- comment on column view_merchant_commission_v2.commission_min not supported: 最低佣金

-- comment on column view_merchant_commission_v2.admin_id not supported: 操作人

-- comment on column view_merchant_commission_v2.city_id not supported: 城市id

