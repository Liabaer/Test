create view view_settlement_order as
select `odb`.`order_id` AS `order_id`, `odb`.`courier_id` AS `courier_id`, `s`.`status` AS `status`
from ((`ordering`.`settlement_order_discount_balance` `sodb` left join `ordering`.`settlement` `s` on ((`sodb`.`settlement_id` = `s`.`id`)))
         left join `ordering`.`order_discount_balance` `odb` on ((`sodb`.`odb_id` = `odb`.`id`)));

-- comment on column view_settlement_order.status not supported: 结算状态, 0:已撤销; 1:待转账; 2:转账中; 3:已转账

