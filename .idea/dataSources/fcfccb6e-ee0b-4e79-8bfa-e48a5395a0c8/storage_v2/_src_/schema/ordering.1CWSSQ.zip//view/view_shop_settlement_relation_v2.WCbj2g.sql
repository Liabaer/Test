create view view_shop_settlement_relation_v2 as
select `ordering`.`shop_settlement_relation`.`id`                            AS `id`,
       `ordering`.`shop_settlement_relation`.`relation_type`                 AS `relation_type`,
       `ordering`.`shop_settlement_relation`.`city_id`                       AS `city_id`,
       `ordering`.`shop_settlement_relation`.`shop_id`                       AS `shop_id`,
       `ordering`.`shop_settlement_relation`.`order_id`                      AS `order_id`,
       `ordering`.`shop_settlement_relation`.`courier_id`                    AS `courier_id`,
       `ordering`.`shop_settlement_relation`.`odb_id`                        AS `odb_id`,
       `ordering`.`shop_settlement_relation`.`adjustment_id`                 AS `adjustment_id`,
       `ordering`.`shop_settlement_relation`.`adjustment_schedule_id`        AS `adjustment_schedule_id`,
       `ordering`.`shop_settlement_relation`.`adjustment_schedule_target_id` AS `adjustment_schedule_target_id`,
       `ordering`.`shop_settlement_relation`.`wallet_detail_id`              AS `wallet_detail_id`,
       `ordering`.`shop_settlement_relation`.`transfer_id`                   AS `transfer_id`,
       `ordering`.`shop_settlement_relation`.`amount`                        AS `amount`,
       `ordering`.`shop_settlement_relation`.`status`                        AS `status`,
       `ordering`.`shop_settlement_relation`.`create_time`                   AS `create_time`,
       `ordering`.`shop_settlement_relation`.`update_time`                   AS `update_time`
from `ordering`.`shop_settlement_relation`;

-- comment on column view_shop_settlement_relation_v2.relation_type not supported: 类型, order=订单结算, adjustment=调账, journal=流水

-- comment on column view_shop_settlement_relation_v2.city_id not supported: 城市ID

-- comment on column view_shop_settlement_relation_v2.shop_id not supported: 商家ID

-- comment on column view_shop_settlement_relation_v2.order_id not supported: 订单ID

-- comment on column view_shop_settlement_relation_v2.courier_id not supported: 配送员ID

-- comment on column view_shop_settlement_relation_v2.odb_id not supported: ODB ID

-- comment on column view_shop_settlement_relation_v2.adjustment_id not supported: 调账ID

-- comment on column view_shop_settlement_relation_v2.adjustment_schedule_id not supported: 调账计划ID

-- comment on column view_shop_settlement_relation_v2.adjustment_schedule_target_id not supported: 调账计划ID

-- comment on column view_shop_settlement_relation_v2.wallet_detail_id not supported: 钱包明细ID

-- comment on column view_shop_settlement_relation_v2.transfer_id not supported: 转账ID

-- comment on column view_shop_settlement_relation_v2.amount not supported: 结算金额

-- comment on column view_shop_settlement_relation_v2.status not supported: 状态, pending=未转账, done=已转账, canceled=已撤销

