create view view_settlement_order_discount_balance_v2 as
select `sodb`.`id`            AS `id`,
       `sodb`.`settlement_id` AS `settlement_id`,
       `sodb`.`odb_id`        AS `odb_id`,
       `sodb`.`order_id`      AS `order_id`,
       `sodb`.`shop_id`       AS `shop_id`,
       `sodb`.`courier_id`    AS `courier_id`
from `ordering`.`settlement_order_discount_balance` `sodb`;

-- comment on column view_settlement_order_discount_balance_v2.settlement_id not supported: 结算记录ID

-- comment on column view_settlement_order_discount_balance_v2.odb_id not supported: ODB表记录ID

-- comment on column view_settlement_order_discount_balance_v2.order_id not supported: 订单id

-- comment on column view_settlement_order_discount_balance_v2.shop_id not supported: 商家id

-- comment on column view_settlement_order_discount_balance_v2.courier_id not supported: 配送员id

