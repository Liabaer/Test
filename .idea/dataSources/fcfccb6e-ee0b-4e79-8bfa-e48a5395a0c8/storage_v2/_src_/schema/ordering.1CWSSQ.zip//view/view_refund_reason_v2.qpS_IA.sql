create view view_refund_reason_v2 as
select `rr`.`id`         AS `id`,
       `rr`.`reason`     AS `reason`,
       `rr`.`created_by` AS `created_by`,
       `rr`.`updated_by` AS `updated_by`,
       `rr`.`created_at` AS `created_at`,
       `rr`.`updated_at` AS `updated_at`,
       `rr`.`is_valid`   AS `is_valid`
from `ordering`.`refund_reason` `rr`;

-- comment on column view_refund_reason_v2.is_valid not supported: 记录是否有效

