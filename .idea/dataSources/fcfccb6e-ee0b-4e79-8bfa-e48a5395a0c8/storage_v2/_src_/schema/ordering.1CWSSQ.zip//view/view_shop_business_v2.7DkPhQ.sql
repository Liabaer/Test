create view view_shop_business_v2 as
select `sb`.`id`                              AS `id`,
       `sb`.`shop_id`                         AS `shop_id`,
       `sb`.`platform`                        AS `platform`,
       `sb`.`opening`                         AS `opening`,
       `sb`.`business`                        AS `business`,
       `sb`.`status`                          AS `status`,
       `sb`.`discount_type`                   AS `discount_type`,
       `sb`.`discount`                        AS `discount`,
       `sb`.`threshold_amount`                AS `threshold_amount`,
       `sb`.`seq`                             AS `seq`,
       `sb`.`delivery_fee_discount_type`      AS `delivery_fee_discount_type`,
       `sb`.`delivery_fee_discount`           AS `delivery_fee_discount`,
       `sb`.`delivery_fee_discount_condition` AS `delivery_fee_discount_condition`,
       `sb`.`shop_order_fee_discount`         AS `shop_order_fee_discount`,
       `sb`.`cash_discount`                   AS `cash_discount`,
       `sb`.`cash_discount_seq`               AS `cash_discount_seq`,
       `sb`.`hot_sale`                        AS `hot_sale`,
       `sb`.`hot_sale_seq`                    AS `hot_sale_seq`,
       `sb`.`recommend`                       AS `recommend`,
       `sb`.`recommend_seq`                   AS `recommend_seq`,
       `sb`.`exclusive`                       AS `exclusive`,
       `sb`.`exclusive_seq`                   AS `exclusive_seq`,
       `sb`.`new_arrival`                     AS `new_arrival`,
       `sb`.`new_arrival_seq`                 AS `new_arrival_seq`,
       `sb`.`rank_seq`                        AS `rank_seq`,
       `sb`.`payment_type`                    AS `payment_type`,
       `sb`.`platform_settlement_status`      AS `platform_settlement_status`,
       `sb`.`cover_tag_key`                   AS `cover_tag_key`,
       `sb`.`operation_tag_key`               AS `operation_tag_key`,
       `sb`.`operation_desc`                  AS `operation_desc`,
       `sb`.`en_operation_desc`               AS `en_operation_desc`,
       `sb`.`reservation`                     AS `reservation`,
       `sb`.`delivery_type`                   AS `delivery_type`,
       `sb`.`reservation_max_days`            AS `reservation_max_days`,
       `sb`.`delivery_method`                 AS `delivery_method`,
       `sb`.`is_query`                        AS `is_query`,
       `sb`.`add_scale`                       AS `add_scale`,
       `sb`.`setting_ready_time`              AS `setting_ready_time`,
       `sb`.`public_holidays_opening`         AS `public_holidays_opening`,
       `sb`.`switch_business_time`            AS `switch_business_time`
from `ordering`.`shop_business` `sb`
where (`sb`.`platform` = 0);

-- comment on column view_shop_business_v2.shop_id not supported: 商家id

-- comment on column view_shop_business_v2.platform not supported: 送餐平台类型，0: xx送餐 1: 饭来了

-- comment on column view_shop_business_v2.opening not supported: 商家自定义营业状态

-- comment on column view_shop_business_v2.business not supported: 商家营业状态，同shop表的business字段

-- comment on column view_shop_business_v2.status not supported: 商家上架状态，同shop表的status字段

-- comment on column view_shop_business_v2.discount_type not supported: 商家折扣类型，同shop表的discount_type字段

-- comment on column view_shop_business_v2.threshold_amount not supported: 商家起送金额

-- comment on column view_shop_business_v2.seq not supported: 商家排名，同shop表的seq字段

-- comment on column view_shop_business_v2.exclusive not supported: 独家标签

-- comment on column view_shop_business_v2.new_arrival not supported: 新商家标签

-- comment on column view_shop_business_v2.payment_type not supported: 0: 不含任何支付方式; 1: 在线支付 2: 货到付款; 3: 在线支付和货到付款

-- comment on column view_shop_business_v2.platform_settlement_status not supported: 是否开启平台结算, 0关闭, 1开启

-- comment on column view_shop_business_v2.cover_tag_key not supported: 商家运营封面标签

-- comment on column view_shop_business_v2.operation_tag_key not supported: 商家运营标签

-- comment on column view_shop_business_v2.operation_desc not supported: 商家运营描述

-- comment on column view_shop_business_v2.en_operation_desc not supported: 英文商家运营描述

-- comment on column view_shop_business_v2.reservation not supported: 商家是否支持预定

-- comment on column view_shop_business_v2.delivery_type not supported: 商家配送方式(1:平台配送 2:自取 3:平台配送+自取)

-- comment on column view_shop_business_v2.reservation_max_days not supported: 商家允许最大预定天数，1 = 第二天，2 = 第三天，以此类推，默认1

-- comment on column view_shop_business_v2.delivery_method not supported: 配送方式 0-EASI配送 1-商家配送

-- comment on column view_shop_business_v2.is_query not supported: 用于首页排序字段

-- comment on column view_shop_business_v2.setting_ready_time not supported: 商家自行设定的备餐时间(分钟)

-- comment on column view_shop_business_v2.public_holidays_opening not supported: 公共节假日是否营业

-- comment on column view_shop_business_v2.switch_business_time not supported: 记录点击开关闭营业按钮的时间

