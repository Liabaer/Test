create view view_country as
select `c`.`id` AS `id`, `c`.`name` AS `name`, `c`.`name_en` AS `name_en`, `c`.`abbr` AS `abbr`, `c`.`code` AS `code`
from `ordering`.`country` `c`;

-- comment on column view_country.name not supported: 国家中文名称

-- comment on column view_country.name_en not supported: 国家英文名称

-- comment on column view_country.code not supported: 国家码

