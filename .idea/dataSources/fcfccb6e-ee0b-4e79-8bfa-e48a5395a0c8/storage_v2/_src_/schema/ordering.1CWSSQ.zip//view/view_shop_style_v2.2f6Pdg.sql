create view view_shop_style_v2 as
select `ss`.`id`      AS `id`,
       `ss`.`name`    AS `name`,
       `ss`.`name_en` AS `name_en`,
       `ss`.`seq`     AS `seq`,
       `ss`.`city_id` AS `city_id`
from `ordering`.`shop_style` `ss`;

