create view view_coupon_log as
select `l`.`id`          AS `id`,
       `l`.`create_time` AS `create_time`,
       `l`.`type`        AS `type`,
       `l`.`oper_id`     AS `oper_id`,
       `l`.`relate_id`   AS `relate_id`,
       `l`.`desc`        AS `desc`
from `ordering`.`log` `l`
where (`l`.`type` in (2001, 2002, 2005, 2010, 2011, 11100, 12001));

