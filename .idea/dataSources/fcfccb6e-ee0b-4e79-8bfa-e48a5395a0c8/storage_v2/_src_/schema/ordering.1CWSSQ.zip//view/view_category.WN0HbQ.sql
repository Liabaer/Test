create view view_category as
select `ic`.`id`          AS `id`,
       `ic`.`name`        AS `name`,
       `ic`.`name_en`     AS `name_en`,
       `ic`.`shop_id`     AS `shop_id`,
       `ic`.`image`       AS `image`,
       `ic`.`create_time` AS `create_time`,
       `ic`.`update_time` AS `update_time`
from `ordering`.`item_category` `ic`;

