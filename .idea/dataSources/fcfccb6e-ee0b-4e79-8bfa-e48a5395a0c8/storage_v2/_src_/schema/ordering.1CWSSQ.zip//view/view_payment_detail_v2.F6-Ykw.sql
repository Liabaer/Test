create view view_payment_detail_v2 as
select `pd`.`id`                        AS `id`,
       `pd`.`order_id`                  AS `order_id`,
       `pd`.`pay_type`                  AS `pay_type`,
       `pd`.`pay_method_id`             AS `pay_method_id`,
       `pd`.`pay_method_name`           AS `pay_method_name`,
       `pd`.`actual_pay_fee`            AS `actual_pay_fee`,
       `pd`.`order_transaction_fee`     AS `order_transaction_fee`,
       `pd`.`order_pay_fee_include_gst` AS `order_pay_fee_include_gst`,
       `pd`.`menu_fee`                  AS `menu_fee`,
       `pd`.`delivery_fee`              AS `delivery_fee`,
       `pd`.`vat_fee`                   AS `vat_fee`,
       `pd`.`coupon_id`                 AS `coupon_id`,
       `pd`.`coupon_fee`                AS `coupon_fee`,
       `pd`.`coupon_name`               AS `coupon_name`,
       `pd`.`shop_order_fee_discount`   AS `shop_order_fee_discount`,
       `pd`.`wallet_account_id`         AS `wallet_account_id`,
       `pd`.`wallet_fee`                AS `wallet_fee`,
       `pd`.`created_at`                AS `created_at`,
       `pd`.`updated_at`                AS `updated_at`
from `ordering`.`payment_detail` `pd`;

-- comment on column view_payment_detail_v2.pay_type not supported: 1:在线支付; 2:线下支付

-- comment on column view_payment_detail_v2.pay_method_id not supported: 0:货到付款; 其它数字代表在线支付方式

-- comment on column view_payment_detail_v2.actual_pay_fee not supported: 实际支付金额 = 订单计算出的金额 + 可能的手续费

-- comment on column view_payment_detail_v2.order_transaction_fee not supported: 可能的手续费

-- comment on column view_payment_detail_v2.order_pay_fee_include_gst not supported: 订单计算出的需支付金额；在线支付或货到付款支付金额

-- comment on column view_payment_detail_v2.menu_fee not supported: 菜单金额

-- comment on column view_payment_detail_v2.delivery_fee not supported: 配送费

-- comment on column view_payment_detail_v2.vat_fee not supported: 支付增值税

-- comment on column view_payment_detail_v2.coupon_id not supported: 优惠券ID

-- comment on column view_payment_detail_v2.coupon_fee not supported: 优惠券金额

-- comment on column view_payment_detail_v2.coupon_name not supported: 优惠券名称

-- comment on column view_payment_detail_v2.shop_order_fee_discount not supported: 店铺满减

-- comment on column view_payment_detail_v2.wallet_account_id not supported: 钱包账户ID

-- comment on column view_payment_detail_v2.wallet_fee not supported: 钱包金额

