create view view_shop_settlement_order_discount_balance_v2 as
select `ssodb`.`id`                 AS `id`,
       `ssodb`.`shop_settlement_id` AS `shop_settlement_id`,
       `ssodb`.`odb_id`             AS `odb_id`,
       `ssodb`.`order_id`           AS `order_id`,
       `ssodb`.`shop_id`            AS `shop_id`,
       `ssodb`.`courier_id`         AS `courier_id`
from `ordering`.`shop_settlement_order_discount_balance` `ssodb`;

-- comment on column view_shop_settlement_order_discount_balance_v2.shop_settlement_id not supported: 商家结算id

-- comment on column view_shop_settlement_order_discount_balance_v2.odb_id not supported: odb id

-- comment on column view_shop_settlement_order_discount_balance_v2.order_id not supported: 订单id

-- comment on column view_shop_settlement_order_discount_balance_v2.shop_id not supported: 商家id

-- comment on column view_shop_settlement_order_discount_balance_v2.courier_id not supported: 配送员id

