create view view_payment_config_v2 as
select `pc`.`id`                          AS `id`,
       `pc`.`type`                        AS `type`,
       `pc`.`seq`                         AS `seq`,
       `pc`.`pay_type`                    AS `pay_type`,
       `pc`.`pay_type_name`               AS `pay_type_name`,
       `pc`.`pay_type_name_en`            AS `pay_type_name_en`,
       `pc`.`name`                        AS `name`,
       `pc`.`service_provider`            AS `service_provider`,
       `pc`.`country_id`                  AS `country_id`,
       `pc`.`city_id`                     AS `city_id`,
       `pc`.`env`                         AS `env`,
       `pc`.`paypal_client_id`            AS `paypal_client_id`,
       `pc`.`paypal_client_secret`        AS `paypal_client_secret`,
       `pc`.`bt_merchant_id`              AS `bt_merchant_id`,
       `pc`.`bt_merchant_account_id`      AS `bt_merchant_account_id`,
       `pc`.`bt_public_key`               AS `bt_public_key`,
       `pc`.`bt_private_key`              AS `bt_private_key`,
       `pc`.`pl_merchant_code`            AS `pl_merchant_code`,
       `pc`.`pl_auth_code`                AS `pl_auth_code`,
       `pc`.`pl_notify_url`               AS `pl_notify_url`,
       `pc`.`ali_partner_code`            AS `ali_partner_code`,
       `pc`.`ali_credential_code`         AS `ali_credential_code`,
       `pc`.`ali_notify_url`              AS `ali_notify_url`,
       `pc`.`wx_app_id`                   AS `wx_app_id`,
       `pc`.`wx_mch_id`                   AS `wx_mch_id`,
       `pc`.`wx_sub_mch_id`               AS `wx_sub_mch_id`,
       `pc`.`wx_out_mch_id`               AS `wx_out_mch_id`,
       `pc`.`wx_out_sub_mch_id`           AS `wx_out_sub_mch_id`,
       `pc`.`wx_mob_app_id`               AS `wx_mob_app_id`,
       `pc`.`wx_device_id`                AS `wx_device_id`,
       `pc`.`wx_staff_id`                 AS `wx_staff_id`,
       `pc`.`wx_min_app_id`               AS `wx_min_app_id`,
       `pc`.`wx_mini_sub_app_id`          AS `wx_mini_sub_app_id`,
       `pc`.`wx_order_prefix`             AS `wx_order_prefix`,
       `pc`.`wx_private_key`              AS `wx_private_key`,
       `pc`.`wx_authenticate_key`         AS `wx_authenticate_key`,
       `pc`.`wx_out_shop_id`              AS `wx_out_shop_id`,
       `pc`.`adyen_merchant_account`      AS `adyen_merchant_account`,
       `pc`.`adyen_checkout_api_key`      AS `adyen_checkout_api_key`,
       `pc`.`adyen_ws_user_name`          AS `adyen_ws_user_name`,
       `pc`.`adyen_ws_password`           AS `adyen_ws_password`,
       `pc`.`adyen_report_user_name`      AS `adyen_report_user_name`,
       `pc`.`adyen_report_password`       AS `adyen_report_password`,
       `pc`.`adyen_fix_fee`               AS `adyen_fix_fee`,
       `pc`.`stripe_public_key`           AS `stripe_public_key`,
       `pc`.`stripe_secret_key`           AS `stripe_secret_key`,
       `pc`.`stripe_webhook_secret_key`   AS `stripe_webhook_secret_key`,
       `pc`.`transaction_fee_rate`        AS `transaction_fee_rate`,
       `pc`.`bank_merchant_id`            AS `bank_merchant_id`,
       `pc`.`bank_auth_pwd1`              AS `bank_auth_pwd1`,
       `pc`.`unionpay_merchant_id`        AS `unionpay_merchant_id`,
       `pc`.`unionpay_merchant_code`      AS `unionpay_merchant_code`,
       `pc`.`unionpay_merchant_name`      AS `unionpay_merchant_name`,
       `pc`.`unionpay_security_key`       AS `unionpay_security_key`,
       `pc`.`pay_desc`                    AS `pay_desc`,
       `pc`.`pay_desc_en`                 AS `pay_desc_en`,
       `pc`.`is_valid`                    AS `is_valid`,
       `pc`.`remark`                      AS `remark`,
       `pc`.`created_by`                  AS `created_by`,
       `pc`.`updated_by`                  AS `updated_by`,
       `pc`.`created_at`                  AS `created_at`,
       `pc`.`updated_at`                  AS `updated_at`,
       `pc`.`adyen_client_encryption_key` AS `adyen_client_encryption_key`
from `ordering`.`payment_config` `pc`;

-- comment on column view_payment_config_v2.type not supported: 1:线上支付  2:线下支付

-- comment on column view_payment_config_v2.seq not supported: 排序字段

-- comment on column view_payment_config_v2.pay_type not supported: 支付类型  1:weixin; 2:alipay; 3:paypal; 4:bankcard; 5:adyen

-- comment on column view_payment_config_v2.pay_type_name not supported: 支付类型中文名称

-- comment on column view_payment_config_v2.pay_type_name_en not supported: 支付类型英文名称

-- comment on column view_payment_config_v2.name not supported: 支付名称

-- comment on column view_payment_config_v2.country_id not supported:  国家编码

-- comment on column view_payment_config_v2.city_id not supported: 城市id

-- comment on column view_payment_config_v2.env not supported: 配置使用环境(dev;test;prod)

-- comment on column view_payment_config_v2.bt_merchant_account_id not supported: BrainTree 商家账户id

-- comment on column view_payment_config_v2.wx_app_id not supported: 微信分配给服务商的公众账号id

-- comment on column view_payment_config_v2.wx_mch_id not supported: 微信支付分配的服务商账号

-- comment on column view_payment_config_v2.wx_sub_mch_id not supported: 微信支付分配的子商户账号

-- comment on column view_payment_config_v2.wx_out_mch_id not supported: 云支付分配给服务商的帐号

-- comment on column view_payment_config_v2.wx_out_sub_mch_id not supported: 云支付分配给子商户的帐号

-- comment on column view_payment_config_v2.wx_mob_app_id not supported: 系统在微信开放平台绑定的 ID

-- comment on column view_payment_config_v2.wx_device_id not supported: 子商户自定义，终端设备号

-- comment on column view_payment_config_v2.wx_staff_id not supported: 子商户自定义，店员ID

-- comment on column view_payment_config_v2.wx_min_app_id not supported: 微信分配给服务商的小程序公众账号id

-- comment on column view_payment_config_v2.wx_mini_sub_app_id not supported: 小程序app_id

-- comment on column view_payment_config_v2.wx_order_prefix not supported: 云支付订单前缀

-- comment on column view_payment_config_v2.wx_private_key not supported: 云支付签名私钥

-- comment on column view_payment_config_v2.wx_authenticate_key not supported: 云支付认证秘钥

-- comment on column view_payment_config_v2.wx_out_shop_id not supported: 云支付唯一标识门店的账号

-- comment on column view_payment_config_v2.adyen_merchant_account not supported: adyen account

-- comment on column view_payment_config_v2.adyen_fix_fee not supported: adyen每单收取的固定费用

-- comment on column view_payment_config_v2.transaction_fee_rate not supported: 交易费用

-- comment on column view_payment_config_v2.bank_merchant_id not supported: 银行卡支付，商户号

-- comment on column view_payment_config_v2.bank_auth_pwd1 not supported: 银行卡授权支付密码1

-- comment on column view_payment_config_v2.unionpay_merchant_id not supported: 银联支付商户号

-- comment on column view_payment_config_v2.unionpay_merchant_code not supported: 银联支付商户编码

-- comment on column view_payment_config_v2.unionpay_merchant_name not supported: 银联支付商户名称

-- comment on column view_payment_config_v2.unionpay_security_key not supported: 银联支付 security_ke

-- comment on column view_payment_config_v2.pay_desc not supported: 支付描述内容，显示给前端

-- comment on column view_payment_config_v2.pay_desc_en not supported: 支付描述内容英文，显示给前端

-- comment on column view_payment_config_v2.is_valid not supported: 记录是否有效

-- comment on column view_payment_config_v2.remark not supported: 备注

-- comment on column view_payment_config_v2.created_by not supported: 创建人ID

-- comment on column view_payment_config_v2.updated_by not supported: 更新人ID

-- comment on column view_payment_config_v2.created_at not supported: 创建时间

-- comment on column view_payment_config_v2.updated_at not supported: 更新时间

-- comment on column view_payment_config_v2.adyen_client_encryption_key not supported: 客户端加密public key

