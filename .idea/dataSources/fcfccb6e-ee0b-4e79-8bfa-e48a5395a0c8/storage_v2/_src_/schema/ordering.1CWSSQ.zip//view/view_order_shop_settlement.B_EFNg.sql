create view view_order_shop_settlement as
select `o`.`id`          AS `order_id`,
       `o`.`courier_id`  AS `courier_id`,
       `o`.`shop_id`     AS `shop_id`,
       `o`.`create_time` AS `order_create_time`,
       `ss`.`id`         AS `shop_settlement_id`,
       `ss`.`status`     AS `settlement_status`
from (((`ordering`.`order` `o` left join `ordering`.`order_discount_balance` `odb` on ((`odb`.`order_id` = `o`.`id`))) left join `ordering`.`shop_settlement_order_discount_balance` `ssodb` on ((`ssodb`.`odb_id` = `odb`.`id`)))
         left join `ordering`.`shop_settlement` `ss` on ((`ssodb`.`shop_settlement_id` = `ss`.`id`)));

-- comment on column view_order_shop_settlement.settlement_status not supported: 结算状态, 0:已撤销; 1:待转账; 2:转账中; 3:已转账

