create view view_courier_transfer_v2 as
select `ct`.`id`             AS `id`,
       `ct`.`city_id`        AS `city_id`,
       `ct`.`direction`      AS `direction`,
       `ct`.`amount`         AS `amount`,
       `ct`.`image`          AS `image`,
       `ct`.`status`         AS `status`,
       `ct`.`label`          AS `label`,
       `ct`.`create_by`      AS `create_by`,
       `ct`.`create_by_name` AS `create_by_name`,
       `ct`.`create_time`    AS `create_time`,
       `ct`.`update_by`      AS `update_by`,
       `ct`.`update_by_name` AS `update_by_name`,
       `ct`.`update_time`    AS `update_time`
from `ordering`.`courier_transfer` `ct`;

-- comment on column view_courier_transfer_v2.city_id not supported: 城市id

-- comment on column view_courier_transfer_v2.direction not supported: 转账方向, -1=转账给配送员, 1=转账给平台

-- comment on column view_courier_transfer_v2.amount not supported: 转账金额

-- comment on column view_courier_transfer_v2.image not supported: 转账图片凭据

-- comment on column view_courier_transfer_v2.status not supported: 结算状态, canceled=已撤销, pending=待转账, transferred=已转账

-- comment on column view_courier_transfer_v2.label not supported: 用于标记转账

-- comment on column view_courier_transfer_v2.create_by not supported: 转账管理员id

-- comment on column view_courier_transfer_v2.create_by_name not supported: 转账管理员名称

-- comment on column view_courier_transfer_v2.update_by not supported: 更新管理员id

-- comment on column view_courier_transfer_v2.update_by_name not supported: 更新管理员名称

