create view view_courier_evaluation_score_detail_v2 as
select `ordering`.`courier_evaluation_score_detail`.`id`                   AS `id`,
       `ordering`.`courier_evaluation_score_detail`.`city_id`              AS `city_id`,
       `ordering`.`courier_evaluation_score_detail`.`courier_id`           AS `courier_id`,
       `ordering`.`courier_evaluation_score_detail`.`courier_name`         AS `courier_name`,
       `ordering`.`courier_evaluation_score_detail`.`evaluation_reason_id` AS `evaluation_reason_id`,
       `ordering`.`courier_evaluation_score_detail`.`evaluation_reason`    AS `evaluation_reason`,
       `ordering`.`courier_evaluation_score_detail`.`evaluation_reason_en` AS `evaluation_reason_en`,
       `ordering`.`courier_evaluation_score_detail`.`related_order_id`     AS `related_order_id`,
       `ordering`.`courier_evaluation_score_detail`.`last_score`           AS `last_score`,
       `ordering`.`courier_evaluation_score_detail`.`score`                AS `score`,
       `ordering`.`courier_evaluation_score_detail`.`current_score`        AS `current_score`,
       `ordering`.`courier_evaluation_score_detail`.`remark`               AS `remark`,
       `ordering`.`courier_evaluation_score_detail`.`created_by`           AS `created_by`,
       `ordering`.`courier_evaluation_score_detail`.`created_at`           AS `created_at`
from `ordering`.`courier_evaluation_score_detail`;

-- comment on column view_courier_evaluation_score_detail_v2.courier_name not supported: 送餐员名称

-- comment on column view_courier_evaluation_score_detail_v2.evaluation_reason_id not supported: 考评原因id

-- comment on column view_courier_evaluation_score_detail_v2.evaluation_reason not supported: 考评原因名称

-- comment on column view_courier_evaluation_score_detail_v2.evaluation_reason_en not supported: 考评原因名称英文

-- comment on column view_courier_evaluation_score_detail_v2.related_order_id not supported: 关联订单id

-- comment on column view_courier_evaluation_score_detail_v2.last_score not supported: 变更前分数

-- comment on column view_courier_evaluation_score_detail_v2.score not supported: 变更分数

-- comment on column view_courier_evaluation_score_detail_v2.current_score not supported: 变更后分数

-- comment on column view_courier_evaluation_score_detail_v2.remark not supported: 考评备注

-- comment on column view_courier_evaluation_score_detail_v2.created_by not supported: 操作人

