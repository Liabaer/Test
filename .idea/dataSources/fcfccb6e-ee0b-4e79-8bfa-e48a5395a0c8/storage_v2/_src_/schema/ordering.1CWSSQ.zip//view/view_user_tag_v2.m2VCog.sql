create view view_user_tag_v2 as
select `ordering`.`user_tag`.`id`          AS `id`,
       `ordering`.`user_tag`.`name`        AS `name`,
       `ordering`.`user_tag`.`city_id`     AS `city_id`,
       `ordering`.`user_tag`.`type`        AS `type`,
       `ordering`.`user_tag`.`rule`        AS `rule`,
       `ordering`.`user_tag`.`create_time` AS `create_time`,
       `ordering`.`user_tag`.`update_time` AS `update_time`,
       `ordering`.`user_tag`.`create_by`   AS `create_by`,
       `ordering`.`user_tag`.`update_by`   AS `update_by`,
       `ordering`.`user_tag`.`is_del`      AS `is_del`
from `ordering`.`user_tag`;

-- comment on column view_user_tag_v2.name not supported: 用户标签名

-- comment on column view_user_tag_v2.city_id not supported: 城市id

-- comment on column view_user_tag_v2.type not supported: 1代表excel文件导入的能够直接查询出来的用户id,2代表时规则类型,用户是按照规则筛选出来的

-- comment on column view_user_tag_v2.rule not supported: 如果type为2,则该字段保存的是规则,json格式的对象,type为1默认为空字符串

-- comment on column view_user_tag_v2.create_time not supported: 创建时间

-- comment on column view_user_tag_v2.update_time not supported: 更新时间

-- comment on column view_user_tag_v2.create_by not supported: 创建者

-- comment on column view_user_tag_v2.update_by not supported: 修改者

-- comment on column view_user_tag_v2.is_del not supported: 是否删除

