create view view_order_extension_v2 as
select `oe`.`id`                           AS `id`,
       `oe`.`order_id`                     AS `order_id`,
       `oe`.`city_id`                      AS `city_id`,
       `oe`.`shop_id`                      AS `shop_id`,
       `oe`.`shop_name`                    AS `shop_name`,
       `oe`.`user_id`                      AS `user_id`,
       `oe`.`user_phone_number`            AS `user_phone_number`,
       `oe`.`address_id`                   AS `address_id`,
       `oe`.`address_phone_number`         AS `address_phone_number`,
       `oe`.`address_contact_name`         AS `address_contact_name`,
       `oe`.`activity_id`                  AS `activity_id`,
       `oe`.`activity_title`               AS `activity_title`,
       `oe`.`activity_remark`              AS `activity_remark`,
       `oe`.`create_time`                  AS `create_time`,
       `oe`.`create_time_utc_str`          AS `create_time_utc_str`,
       `oe`.`create_timestamp`             AS `create_timestamp`,
       `oe`.`print_time`                   AS `print_time`,
       `oe`.`response_time`                AS `response_time`,
       `oe`.`status`                       AS `status`,
       `oe`.`confirm_receipt_time`         AS `confirm_receipt_time`,
       `oe`.`customer_delete_time`         AS `customer_delete_time`,
       `oe`.`customer_cancel_time`         AS `customer_cancel_time`,
       `oe`.`address_remark`               AS `address_remark`,
       `oe`.`platform_audit_time`          AS `platform_audit_time`,
       `oe`.`platform_audit_status`        AS `platform_audit_status`,
       `oe`.`platform_audit_remark`        AS `platform_audit_remark`,
       `oe`.`platform_audit_reject_reason` AS `platform_audit_reject_reason`,
       `oe`.`merchant_audit_time`          AS `merchant_audit_time`,
       `oe`.`merchant_audit_status`        AS `merchant_audit_status`,
       `oe`.`merchant_audit_remark`        AS `merchant_audit_remark`,
       `oe`.`preparation_delay_minutes`    AS `preparation_delay_minutes`
from `ordering`.`order_extension` `oe`;

-- comment on column view_order_extension_v2.user_phone_number not supported: 顾客注册电话号码

-- comment on column view_order_extension_v2.address_phone_number not supported: 收货电话留的号码

-- comment on column view_order_extension_v2.address_contact_name not supported: 收货电话联系人姓名

-- comment on column view_order_extension_v2.activity_title not supported: 活动标题

-- comment on column view_order_extension_v2.activity_remark not supported: 活动备注

-- comment on column view_order_extension_v2.print_time not supported: 订单打印时间

-- comment on column view_order_extension_v2.response_time not supported: 商家确认时间

-- comment on column view_order_extension_v2.status not supported: 扩充的状态字段, 从10开始. 10:隐藏(顾客删除订单); 20: 顾客已确认收货

-- comment on column view_order_extension_v2.confirm_receipt_time not supported: 顾客确认收货时间

-- comment on column view_order_extension_v2.customer_delete_time not supported: 顾客删除时间

-- comment on column view_order_extension_v2.customer_cancel_time not supported: 顾客取消时间

-- comment on column view_order_extension_v2.platform_audit_time not supported: 平台审核订单时间

-- comment on column view_order_extension_v2.platform_audit_status not supported: 平台审核状态

-- comment on column view_order_extension_v2.platform_audit_remark not supported: 平台审核备注

-- comment on column view_order_extension_v2.platform_audit_reject_reason not supported: 平台拒绝原因

-- comment on column view_order_extension_v2.merchant_audit_time not supported: 商家审核订单时间

-- comment on column view_order_extension_v2.merchant_audit_status not supported: 商家审核状态

-- comment on column view_order_extension_v2.merchant_audit_remark not supported: 商家审核备注

-- comment on column view_order_extension_v2.preparation_delay_minutes not supported: 订单准备加时分钟

