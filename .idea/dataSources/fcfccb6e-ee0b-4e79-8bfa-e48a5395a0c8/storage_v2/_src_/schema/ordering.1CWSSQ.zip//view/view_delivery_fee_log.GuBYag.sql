create view view_delivery_fee_log as
select `ordering`.`delivery_fee_log`.`id`            AS `id`,
       `ordering`.`delivery_fee_log`.`city_id`       AS `city_id`,
       `ordering`.`delivery_fee_log`.`operator_id`   AS `operator_id`,
       `ordering`.`delivery_fee_log`.`operator_name` AS `operator_name`,
       `ordering`.`delivery_fee_log`.`process_info`  AS `process_info`,
       `ordering`.`delivery_fee_log`.`remark`        AS `remark`,
       `ordering`.`delivery_fee_log`.`create_time`   AS `create_time`
from `ordering`.`delivery_fee_log`;

-- comment on column view_delivery_fee_log.operator_id not supported: 操作人ID

-- comment on column view_delivery_fee_log.operator_name not supported: 操作人名称

-- comment on column view_delivery_fee_log.process_info not supported: 操作数据

-- comment on column view_delivery_fee_log.remark not supported: 备注

