create view view_printer_queue_v2 as
select `pq`.`id`                      AS `id`,
       `pq`.`order_id`                AS `order_id`,
       `pq`.`code`                    AS `code`,
       `pq`.`printer_id`              AS `printer_id`,
       `pq`.`status`                  AS `status`,
       `pq`.`type`                    AS `type`,
       `pq`.`create_time`             AS `create_time`,
       `pq`.`print_time`              AS `print_time`,
       `pq`.`response_time`           AS `response_time`,
       `pq`.`printer_response`        AS `printer_response`,
       `pq`.`printer_deliverytime`    AS `printer_deliverytime`,
       `pq`.`printer_rejected_reason` AS `printer_rejected_reason`
from `ordering`.`printer_queue` `pq`;

