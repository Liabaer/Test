create view shop_scene_user_statistics as
select `ordering`.`stat_shop_scene_user`.`scene_id`    AS `scene_id`,
       `ordering`.`stat_shop_scene_user`.`shop_id`     AS `shop_id`,
       `ordering`.`stat_shop_scene_user`.`user_id`     AS `user_id`,
       `ordering`.`stat_shop_scene_user`.`update_time` AS `update_time`
from `ordering`.`stat_shop_scene_user`;

-- comment on column shop_scene_user_statistics.scene_id not supported: 营销场景id

-- comment on column shop_scene_user_statistics.shop_id not supported: 店铺id

-- comment on column shop_scene_user_statistics.user_id not supported: 满足营销场景的用户id

-- comment on column shop_scene_user_statistics.update_time not supported: 更新时间

