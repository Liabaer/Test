create view view_courier_review_v2 as
select `cr`.`id`                   AS `id`,
       `cr`.`courier_id`           AS `courier_id`,
       `cr`.`courier_display_name` AS `courier_display_name`,
       `cr`.`type`                 AS `type`,
       `cr`.`order_id`             AS `order_id`,
       `cr`.`shop_id`              AS `shop_id`,
       `cr`.`shop_name`            AS `shop_name`,
       `cr`.`user_id`              AS `user_id`,
       `cr`.`phone_number`         AS `phone_number`,
       `cr`.`status`               AS `status`,
       `cr`.`review`               AS `review`,
       `cr`.`speed`                AS `speed`,
       `cr`.`attitude`             AS `attitude`,
       `cr`.`shop_fast_review_ids` AS `shop_fast_review_ids`,
       `cr`.`shop_fast_review`     AS `shop_fast_review`,
       `cr`.`create_time`          AS `create_time`
from `ordering`.`courier_review` `cr`;

-- comment on column view_courier_review_v2.courier_id not supported: 配送员id

-- comment on column view_courier_review_v2.courier_display_name not supported: 配送员display name

-- comment on column view_courier_review_v2.type not supported: 1: 用户对配送员的评价 2:商家对配送员的评价

-- comment on column view_courier_review_v2.shop_id not supported: 商家评价不能为空

-- comment on column view_courier_review_v2.shop_name not supported: 商家名称

-- comment on column view_courier_review_v2.user_id not supported: 如果是用户评价不能为空

-- comment on column view_courier_review_v2.phone_number not supported: 用户电话

-- comment on column view_courier_review_v2.status not supported: 0: 正常 1:已删除

-- comment on column view_courier_review_v2.speed not supported: 配送速度

-- comment on column view_courier_review_v2.attitude not supported: 态度

