create view view_category_business_time_v2 as
select `icbt`.`id`               AS `id`,
       `icbt`.`open_time`        AS `open_time`,
       `icbt`.`close_time`       AS `close_time`,
       `icbt`.`week_day`         AS `week_day`,
       `icbt`.`item_category_id` AS `item_category_id`
from `ordering`.`item_category_business_time` `icbt`;

