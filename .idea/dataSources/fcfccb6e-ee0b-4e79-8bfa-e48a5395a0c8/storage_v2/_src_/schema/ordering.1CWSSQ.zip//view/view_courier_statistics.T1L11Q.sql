create view view_courier_statistics as
select `cs`.`id`                                 AS `id`,
       `cs`.`courier_id`                         AS `courier_id`,
       `cs`.`courier_name`                       AS `courier_name`,
       `cs`.`working_date`                       AS `working_date`,
       `cs`.`online_minutes`                     AS `online_minutes`,
       `cs`.`order_minutes`                      AS `order_minutes`,
       `cs`.`order_count`                        AS `order_count`,
       `cs`.`accept_auto_distribute_order_count` AS `accept_auto_distribute_order_count`,
       `cs`.`reject_auto_distribute_order_count` AS `reject_auto_distribute_order_count`,
       `cs`.`timeout_order_count`                AS `timeout_order_count`,
       `cs`.`total_delivery_fee`                 AS `total_delivery_fee`
from `ordering`.`courier_statistics` `cs`;

-- comment on column view_courier_statistics.courier_id not supported: 配送员id

-- comment on column view_courier_statistics.courier_name not supported: 配送员名称

-- comment on column view_courier_statistics.working_date not supported: 上班日期

-- comment on column view_courier_statistics.online_minutes not supported: 上班时长，按在线总时间

-- comment on column view_courier_statistics.order_minutes not supported: 上班时长，按配送总时间

-- comment on column view_courier_statistics.order_count not supported: 当日配送订单数

-- comment on column view_courier_statistics.accept_auto_distribute_order_count not supported: 接受的自动分单数

-- comment on column view_courier_statistics.reject_auto_distribute_order_count not supported: 拒绝的自动分单数

-- comment on column view_courier_statistics.timeout_order_count not supported: 超时的订单数

-- comment on column view_courier_statistics.total_delivery_fee not supported: 配送费总额

