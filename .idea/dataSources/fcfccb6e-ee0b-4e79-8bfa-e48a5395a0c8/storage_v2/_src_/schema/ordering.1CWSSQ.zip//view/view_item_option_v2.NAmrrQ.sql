create view view_item_option_v2 as
select `io`.`id`              AS `id`,
       `io`.`type`            AS `type`,
       `io`.`shop_id`         AS `shop_id`,
       `io`.`item_id`         AS `item_id`,
       `io`.`name`            AS `name`,
       `io`.`name_en`         AS `name_en`,
       `io`.`price`           AS `price`,
       `io`.`option_group_id` AS `option_group_id`,
       `io`.`stock`           AS `stock`,
       `io`.`mode`            AS `mode`,
       `io`.`limit`           AS `limit`,
       `io`.`opt_extra_id`    AS `opt_extra_id`,
       `io`.`stock_everyday`  AS `stock_everyday`,
       `io`.`adjust_price`    AS `adjust_price`
from `ordering`.`item_option` `io`;

-- comment on column view_item_option_v2.type not supported: sku, attr, extra

