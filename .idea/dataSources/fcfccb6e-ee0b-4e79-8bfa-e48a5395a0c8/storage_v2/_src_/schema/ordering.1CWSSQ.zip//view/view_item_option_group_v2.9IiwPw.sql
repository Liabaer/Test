create view view_item_option_group_v2 as
select `iog`.`id`      AS `id`,
       `iog`.`shop_id` AS `shop_id`,
       `iog`.`type`    AS `type`,
       `iog`.`name`    AS `name`,
       `iog`.`name_en` AS `name_en`,
       `iog`.`mode`    AS `mode`,
       `iog`.`limit`   AS `limit`,
       `iog`.`item_id` AS `item_id`,
       `iog`.`min`     AS `min`
from `ordering`.`item_option_group` `iog`;

-- comment on column view_item_option_group_v2.type not supported: sku, attr, extra

-- comment on column view_item_option_group_v2.min not supported: 最少添加数量, 0:不限制, n:最少添加n个

