create view view_courier_gps_online_record_v2 as
select `pfba`.`id`          AS `id`,
       `pfba`.`courier_id`  AS `courier_id`,
       `pfba`.`location`    AS `location`,
       `pfba`.`status`      AS `status`,
       `pfba`.`create_time` AS `create_time`
from `ordering`.`courier_gps_online_record` `pfba`;

-- comment on column view_courier_gps_online_record_v2.courier_id not supported: 配送员ID

-- comment on column view_courier_gps_online_record_v2.location not supported: 位置经纬度

-- comment on column view_courier_gps_online_record_v2.status not supported: 在线状态

-- comment on column view_courier_gps_online_record_v2.create_time not supported: 创建时间

