create view view_courier_settlement_v2 as
select `cs`.`id`                   AS `id`,
       `cs`.`city_id`              AS `city_id`,
       `cs`.`courier_id`           AS `courier_id`,
       `cs`.`courier_display_name` AS `courier_display_name`,
       `cs`.`order_count`          AS `order_count`,
       `cs`.`direction`            AS `direction`,
       `cs`.`amount`               AS `amount`,
       `cs`.`type`                 AS `type`,
       `cs`.`image`                AS `image`,
       `cs`.`wallet_amount`        AS `wallet_amount`,
       `cs`.`wallet_detail_id`     AS `wallet_detail_id`,
       `cs`.`settlement_code`      AS `settlement_code`,
       `cs`.`remark`               AS `remark`,
       `cs`.`status`               AS `status`,
       `cs`.`label`                AS `label`,
       `cs`.`create_by`            AS `create_by`,
       `cs`.`create_by_name`       AS `create_by_name`,
       `cs`.`create_time`          AS `create_time`,
       `cs`.`update_by`            AS `update_by`,
       `cs`.`update_by_name`       AS `update_by_name`,
       `cs`.`update_time`          AS `update_time`
from `ordering`.`courier_settlement` `cs`;

-- comment on column view_courier_settlement_v2.city_id not supported: 城市id

-- comment on column view_courier_settlement_v2.courier_id not supported: 配送员id

-- comment on column view_courier_settlement_v2.courier_display_name not supported: 配送员名称

-- comment on column view_courier_settlement_v2.order_count not supported: 订单数量

-- comment on column view_courier_settlement_v2.direction not supported: 结算方向, -1=结算给配送员, 1=结算给平台

-- comment on column view_courier_settlement_v2.amount not supported: 结算金额

-- comment on column view_courier_settlement_v2.type not supported: 结算类型, cash=现金, transfer=转账, system=系统(在线支付结算)

-- comment on column view_courier_settlement_v2.image not supported: 结算转账图片

-- comment on column view_courier_settlement_v2.wallet_amount not supported: 钱包抵扣金额, 默认为0

-- comment on column view_courier_settlement_v2.wallet_detail_id not supported: 钱包明细id, 默认为0

-- comment on column view_courier_settlement_v2.settlement_code not supported: 结算码

-- comment on column view_courier_settlement_v2.status not supported: 结算状态, canceled=已撤销, pending=待转账, transferring=转账中, transferred=已转账

-- comment on column view_courier_settlement_v2.label not supported: 用于标记转账

-- comment on column view_courier_settlement_v2.create_by not supported: 结算管理员id

-- comment on column view_courier_settlement_v2.create_by_name not supported: 结算管理员名称

-- comment on column view_courier_settlement_v2.update_by not supported: 更新管理员id

-- comment on column view_courier_settlement_v2.update_by_name not supported: 更新管理员名称

