create view view_delivery_fee as
select `df`.`id`                 AS `id`,
       `df`.`start_fee`          AS `start_fee`,
       `df`.`start_km`           AS `start_km`,
       `df`.`fee_per_km`         AS `fee_per_km`,
       `df`.`courier_start_fee`  AS `courier_start_fee`,
       `df`.`courier_start_km`   AS `courier_start_km`,
       `df`.`courier_fee_per_km` AS `courier_fee_per_km`,
       `df`.`shop_id`            AS `shop_id`
from `ordering`.`delivery_fee` `df`
where (`df`.`platform` = 0);

