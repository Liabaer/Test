create view view_delivery_fee_plan_detail_special_v2 as
select `ordering`.`delivery_fee_plan_detail_special`.`id`                   AS `id`,
       `ordering`.`delivery_fee_plan_detail_special`.`plan_id`              AS `plan_id`,
       `ordering`.`delivery_fee_plan_detail_special`.`type`                 AS `type`,
       `ordering`.`delivery_fee_plan_detail_special`.`min_distance`         AS `min_distance`,
       `ordering`.`delivery_fee_plan_detail_special`.`max_distance`         AS `max_distance`,
       `ordering`.`delivery_fee_plan_detail_special`.`fee`                  AS `fee`,
       `ordering`.`delivery_fee_plan_detail_special`.`fixed_fee`            AS `fixed_fee`,
       `ordering`.`delivery_fee_plan_detail_special`.`special_time_part_id` AS `special_time_part_id`
from `ordering`.`delivery_fee_plan_detail_special`;

-- comment on column view_delivery_fee_plan_detail_special_v2.type not supported: 1(正常距离)、2(额外距离)

-- comment on column view_delivery_fee_plan_detail_special_v2.min_distance not supported: 起始距离

-- comment on column view_delivery_fee_plan_detail_special_v2.max_distance not supported: 截止距离

-- comment on column view_delivery_fee_plan_detail_special_v2.fee not supported: 计费金额，与delivery_fee_plan_info中的distance_unit一起计算，比如：0.2刀每100米

-- comment on column view_delivery_fee_plan_detail_special_v2.fixed_fee not supported: 固定费用，默认为0

-- comment on column view_delivery_fee_plan_detail_special_v2.special_time_part_id not supported: 关联特殊时段表(delivery_fee_plan_special_time_part)

