create view view_courier_review as
select `cr`.`id`          AS `id`,
       `cr`.`order_id`    AS `order_id`,
       `cr`.`user_id`     AS `user_id`,
       `cr`.`courier_id`  AS `courier_id`,
       `cr`.`speed`       AS `speed`,
       `cr`.`attitude`    AS `attitude`,
       `cr`.`review`      AS `review`,
       `cr`.`create_time` AS `create_time`
from `ordering`.`courier_review` `cr`
where ((`cr`.`type` = 1) and (`cr`.`status` = 0));

-- comment on column view_courier_review.user_id not supported: 如果是用户评价不能为空

-- comment on column view_courier_review.courier_id not supported: 配送员id

-- comment on column view_courier_review.speed not supported: 配送速度

-- comment on column view_courier_review.attitude not supported: 态度

