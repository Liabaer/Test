create view view_shop_settlement_transfer_v2 as
select `ordering`.`shop_settlement_transfer`.`id`              AS `id`,
       `ordering`.`shop_settlement_transfer`.`city_id`         AS `city_id`,
       `ordering`.`shop_settlement_transfer`.`start_datetime`  AS `start_datetime`,
       `ordering`.`shop_settlement_transfer`.`end_datetime`    AS `end_datetime`,
       `ordering`.`shop_settlement_transfer`.`amount`          AS `amount`,
       `ordering`.`shop_settlement_transfer`.`transfer_amount` AS `transfer_amount`,
       `ordering`.`shop_settlement_transfer`.`max_amount`      AS `max_amount`,
       `ordering`.`shop_settlement_transfer`.`group_name`      AS `group_name`,
       `ordering`.`shop_settlement_transfer`.`transfer_date`   AS `transfer_date`,
       `ordering`.`shop_settlement_transfer`.`remark`          AS `remark`,
       `ordering`.`shop_settlement_transfer`.`status`          AS `status`,
       `ordering`.`shop_settlement_transfer`.`create_id`       AS `create_id`,
       `ordering`.`shop_settlement_transfer`.`create_name`     AS `create_name`,
       `ordering`.`shop_settlement_transfer`.`create_time`     AS `create_time`,
       `ordering`.`shop_settlement_transfer`.`update_time`     AS `update_time`
from `ordering`.`shop_settlement_transfer`;

-- comment on column view_shop_settlement_transfer_v2.city_id not supported: 城市id

-- comment on column view_shop_settlement_transfer_v2.start_datetime not supported: 周期开始时间

-- comment on column view_shop_settlement_transfer_v2.end_datetime not supported: 周期结束时间

-- comment on column view_shop_settlement_transfer_v2.amount not supported: 转账金额

-- comment on column view_shop_settlement_transfer_v2.transfer_amount not supported: 转账金额

-- comment on column view_shop_settlement_transfer_v2.max_amount not supported: 转账文件最大金额

-- comment on column view_shop_settlement_transfer_v2.group_name not supported: 分组名称

-- comment on column view_shop_settlement_transfer_v2.transfer_date not supported: 转账日期

-- comment on column view_shop_settlement_transfer_v2.remark not supported: 转账备注

-- comment on column view_shop_settlement_transfer_v2.status not supported: 转账状态, pending=待转账, done=已转账, canceled=已撤销

-- comment on column view_shop_settlement_transfer_v2.create_id not supported: 发起人ID

-- comment on column view_shop_settlement_transfer_v2.create_name not supported: 发起人名称

