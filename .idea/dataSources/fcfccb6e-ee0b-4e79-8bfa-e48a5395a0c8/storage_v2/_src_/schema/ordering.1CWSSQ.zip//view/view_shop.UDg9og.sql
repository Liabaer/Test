create view view_shop as
select `s`.`id`                               AS `id`,
       `s`.`city_id`                          AS `city_id`,
       `sa`.`name`                            AS `area`,
       `ss`.`name`                            AS `style`,
       `s`.`name`                             AS `name`,
       `s`.`name_en`                          AS `name_en`,
       `s`.`type`                             AS `type`,
       `s`.`create_time`                      AS `create_time`,
       `s`.`status`                           AS `status`,
       `s`.`addr`                             AS `addr`,
       `s`.`addr_remark`                      AS `addr_remark`,
       `s`.`location`                         AS `location`,
       `s`.`location_post_code`               AS `location_post_code`,
       `s`.`abn`                              AS `abn`,
       `s`.`is_registered_for_gst`            AS `is_registered_for_gst`,
       `s`.`vat_rate`                         AS `vat_rate`,
       `s`.`leader_name`                      AS `leader_name`,
       `s`.`leader_mobile`                    AS `leader_mobile`,
       `s`.`sign_person_name`                 AS `sign_person_name`,
       `s`.`sign_person_phone_number`         AS `sign_person_phone_number`,
       `s`.`sim`                              AS `sim`,
       `s`.`bank_code`                        AS `bank_code`,
       `s`.`bsb`                              AS `bsb`,
       `s`.`acc`                              AS `acc`,
       `s`.`acc_name`                         AS `acc_name`,
       `s`.`platform_settlement_frequency`    AS `platform_settlement_frequency`,
       `s`.`branch_name`                      AS `branch_name`,
       `sb`.`payment_type`                    AS `payment_type`,
       `sb`.`discount`                        AS `discount`,
       `sb`.`discount_type`                   AS `discount_type`,
       `sb`.`delivery_fee_discount_type`      AS `delivery_fee_discount_type`,
       `sb`.`delivery_fee_discount`           AS `delivery_fee_discount`,
       `sb`.`delivery_fee_discount_condition` AS `delivery_fee_discount_condition`,
       `sb`.`shop_order_fee_discount`         AS `shop_order_fee_discount`
from ((((`ordering`.`shop` `s` left join `ordering`.`city` `c` on ((`s`.`city_id` = `c`.`id`))) left join `ordering`.`shop_area` `sa` on ((`s`.`shop_area_id` = `sa`.`id`))) left join `ordering`.`shop_style` `ss` on ((`s`.`shop_style_id` = `ss`.`id`)))
         left join `ordering`.`shop_business` `sb` on ((`s`.`id` = `sb`.`shop_id`)))
where ((`sb`.`platform` = 0) or isnull(`sb`.`id`));

-- comment on column view_shop.addr_remark not supported: 地址备注

-- comment on column view_shop.abn not supported: 商家ABN

-- comment on column view_shop.is_registered_for_gst not supported: 商家是否注册GST, 0未注册 1已注册

-- comment on column view_shop.vat_rate not supported: 商家增值税率

-- comment on column view_shop.leader_name not supported: 商家负责人名称

-- comment on column view_shop.leader_mobile not supported: 商家负责人电话

-- comment on column view_shop.sign_person_name not supported: ﻿平台销售签约人名称

-- comment on column view_shop.sign_person_phone_number not supported: ﻿平台销售签约人电话

-- comment on column view_shop.sim not supported: sim卡号

-- comment on column view_shop.bank_code not supported: 商家银行码

-- comment on column view_shop.bsb not supported: BSB

-- comment on column view_shop.acc not supported: ACC

-- comment on column view_shop.acc_name not supported: AccountName

-- comment on column view_shop.platform_settlement_frequency not supported: 结算频次

-- comment on column view_shop.branch_name not supported: 商家分店名字

-- comment on column view_shop.payment_type not supported: 0: 不含任何支付方式; 1: 在线支付 2: 货到付款; 3: 在线支付和货到付款

-- comment on column view_shop.discount_type not supported: 商家折扣类型，同shop表的discount_type字段

