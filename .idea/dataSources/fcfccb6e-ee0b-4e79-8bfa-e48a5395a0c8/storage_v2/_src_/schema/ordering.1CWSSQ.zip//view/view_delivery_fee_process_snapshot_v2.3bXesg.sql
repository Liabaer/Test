create view view_delivery_fee_process_snapshot_v2 as
select `ordering`.`delivery_fee_process_snapshot`.`id`          AS `id`,
       `ordering`.`delivery_fee_process_snapshot`.`filter_type` AS `filter_type`,
       `ordering`.`delivery_fee_process_snapshot`.`distance`    AS `distance`,
       `ordering`.`delivery_fee_process_snapshot`.`object_id`   AS `object_id`,
       `ordering`.`delivery_fee_process_snapshot`.`plan_info`   AS `plan_info`,
       `ordering`.`delivery_fee_process_snapshot`.`total_fee`   AS `total_fee`,
       `ordering`.`delivery_fee_process_snapshot`.`create_time` AS `create_time`
from `ordering`.`delivery_fee_process_snapshot`;

-- comment on column view_delivery_fee_process_snapshot_v2.filter_type not supported: 对应的过滤类型---1（客人）2（配送员）3（商家）

-- comment on column view_delivery_fee_process_snapshot_v2.distance not supported: 配送距离

-- comment on column view_delivery_fee_process_snapshot_v2.object_id not supported: 商家ID/order_id 只有是客人时才是商家ID，其他都是order_id

-- comment on column view_delivery_fee_process_snapshot_v2.plan_info not supported: 配送方案基本信息json，包含基本信息+计费规则

-- comment on column view_delivery_fee_process_snapshot_v2.total_fee not supported: 配送费金额

