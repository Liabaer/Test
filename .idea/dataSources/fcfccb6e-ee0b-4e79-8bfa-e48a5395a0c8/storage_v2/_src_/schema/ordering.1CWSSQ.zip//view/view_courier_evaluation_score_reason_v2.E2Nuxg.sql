create view view_courier_evaluation_score_reason_v2 as
select `ordering`.`courier_evaluation_score_reason`.`id`         AS `id`,
       `ordering`.`courier_evaluation_score_reason`.`name`       AS `name`,
       `ordering`.`courier_evaluation_score_reason`.`name_en`    AS `name_en`,
       `ordering`.`courier_evaluation_score_reason`.`score`      AS `score`,
       `ordering`.`courier_evaluation_score_reason`.`score_type` AS `score_type`,
       `ordering`.`courier_evaluation_score_reason`.`is_valid`   AS `is_valid`
from `ordering`.`courier_evaluation_score_reason`;

-- comment on column view_courier_evaluation_score_reason_v2.name not supported: 考评原因名称

-- comment on column view_courier_evaluation_score_reason_v2.name_en not supported: 考评原因名称英文

-- comment on column view_courier_evaluation_score_reason_v2.score not supported: 分数值

-- comment on column view_courier_evaluation_score_reason_v2.score_type not supported: 分数类型, 1系统使用, 2管理员操作

-- comment on column view_courier_evaluation_score_reason_v2.is_valid not supported: 是否有效

