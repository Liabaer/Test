create view view_courier_v2 as
select `c`.`id`                       AS `id`,
       `c`.`login_name`               AS `login_name`,
       `c`.`password`                 AS `password`,
       `c`.`display_name`             AS `display_name`,
       `c`.`phone_number`             AS `phone_number`,
       `c`.`email`                    AS `email`,
       `c`.`head_icon`                AS `head_icon`,
       `c`.`create_time`              AS `create_time`,
       `c`.`duty_area`                AS `duty_area`,
       `c`.`first_name`               AS `first_name`,
       `c`.`last_name`                AS `last_name`,
       `c`.`birthday`                 AS `birthday`,
       `c`.`address`                  AS `address`,
       `c`.`passport_no`              AS `passport_no`,
       `c`.`driver_no`                AS `driver_no`,
       `c`.`tfn`                      AS `tfn`,
       `c`.`abn`                      AS `abn`,
       `c`.`bsb_number`               AS `bsb_number`,
       `c`.`sort_code`                AS `sort_code`,
       `c`.`acc_number`               AS `acc_number`,
       `c`.`acc_name`                 AS `acc_name`,
       `c`.`remark`                   AS `remark`,
       `c`.`status`                   AS `status`,
       `c`.`device_token`             AS `device_token`,
       `c`.`latitude`                 AS `latitude`,
       `c`.`longitude`                AS `longitude`,
       `c`.`heading`                  AS `heading`,
       `c`.`location_text`            AS `location_text`,
       `c`.`location_post_code`       AS `location_post_code`,
       `c`.`location_update_time`     AS `location_update_time`,
       `c`.`online_update_time`       AS `online_update_time`,
       `c`.`location_update_disabled` AS `location_update_disabled`,
       `c`.`weixin_open_id`           AS `weixin_open_id`,
       `c`.`shop_id`                  AS `shop_id`,
       `c`.`shop_area_id`             AS `shop_area_id`,
       `c`.`login_device_type`        AS `login_device_type`,
       `c`.`login_language`           AS `login_language`,
       `c`.`is_auto_distribute_order` AS `is_auto_distribute_order`,
       `c`.`is_ready`                 AS `is_ready`,
       `c`.`app_language`             AS `app_language`,
       `c`.`city_id`                  AS `city_id`,
       `c`.`group_id`                 AS `group_id`,
       `c`.`driving_type`             AS `driving_type`,
       `c`.`working_status`           AS `working_status`,
       `c`.`is_visible_to_pin`        AS `is_visible_to_pin`,
       `c`.`has_uniform`              AS `has_uniform`,
       `c`.`has_delivery_box`         AS `has_delivery_box`,
       `c`.`has_passport`             AS `has_passport`,
       `c`.`has_abn`                  AS `has_abn`,
       `c`.`custom_manage_fee`        AS `custom_manage_fee`,
       `c`.`min_fee`                  AS `min_fee`,
       `c`.`is_registered_for_gst`    AS `is_registered_for_gst`,
       `c`.`plate_number`             AS `plate_number`,
       `c`.`invite_id`                AS `invite_id`,
       `c`.`is_visa_valid`            AS `is_visa_valid`,
       `c`.`settlement_code`          AS `settlement_code`,
       `c`.`qualified`                AS `qualified`,
       `c`.`company_name`             AS `company_name`,
       `c`.`company_addr`             AS `company_addr`,
       `c`.`is_full_time`             AS `is_full_time`,
       `c`.`salary`                   AS `salary`,
       `c`.`information_is_complete`  AS `information_is_complete`,
       `c`.`invite_code`              AS `invite_code`,
       `c`.`order_pay_type`           AS `order_pay_type`,
       `c`.`evaluation_score`         AS `evaluation_score`,
       `c`.`custom_manage_fee_ratio`  AS `custom_manage_fee_ratio`,
       `c`.`communication_language`   AS `communication_language`,
       `c`.`coding`                   AS `coding`,
       `c`.`delivery_type`            AS `delivery_type`
from `ordering`.`courier` `c`;

-- comment on column view_courier_v2.bsb_number not supported: 配送员BSB number

-- comment on column view_courier_v2.sort_code not supported: 英国配送员银行sort code

-- comment on column view_courier_v2.acc_number not supported: 配送员ACC number

-- comment on column view_courier_v2.acc_name not supported: AccountName

-- comment on column view_courier_v2.login_language not supported: 登录语言

-- comment on column view_courier_v2.driving_type not supported: 配送员驾驶类型, -1:未设定, 0:自行车, 1:摩托车, 2: 汽车

-- comment on column view_courier_v2.working_status not supported: 快递员在职状态：-1未设定, 0离职, 1在职

-- comment on column view_courier_v2.has_uniform not supported: 是否有制服

-- comment on column view_courier_v2.has_delivery_box not supported: 是否有送餐箱

-- comment on column view_courier_v2.has_passport not supported: 是否有护照，0未知 1有 2无

-- comment on column view_courier_v2.has_abn not supported: 是否有ABN，0未知 1有 2无

-- comment on column view_courier_v2.custom_manage_fee not supported: 配送员管理费

-- comment on column view_courier_v2.min_fee not supported: 快递员保底金额

-- comment on column view_courier_v2.is_registered_for_gst not supported: 配送员是否注册GST, 0未注册 1已注册

-- comment on column view_courier_v2.plate_number not supported: 配送员车牌号

-- comment on column view_courier_v2.is_visa_valid not supported: 签证是否有效

-- comment on column view_courier_v2.settlement_code not supported: 应收款结算码

-- comment on column view_courier_v2.qualified not supported: 配送员是否合格, 0未设置 1合格 2不合格

-- comment on column view_courier_v2.company_name not supported: 配送员公司名称

-- comment on column view_courier_v2.company_addr not supported: 配送员公司地址

-- comment on column view_courier_v2.is_full_time not supported: 是否是全职

-- comment on column view_courier_v2.salary not supported: 配送员薪水

-- comment on column view_courier_v2.information_is_complete not supported: 资料是否齐全

-- comment on column view_courier_v2.invite_code not supported: 邀请码

-- comment on column view_courier_v2.order_pay_type not supported: 订单支付类型，表示只配送某种支付类型的订单。0：任何类型都送；1：只送货到付款；2：只送在线支付

-- comment on column view_courier_v2.evaluation_score not supported: 送餐员考评分

-- comment on column view_courier_v2.custom_manage_fee_ratio not supported: 管理费百分比

-- comment on column view_courier_v2.coding not supported: 配送员编码

-- comment on column view_courier_v2.delivery_type not supported: 配送类型 0-EASI配送 1-商家配送

