create view view_shop_credit_note_item as
select `scni`.`id`             AS `id`,
       `scni`.`credit_note_id` AS `credit_note_id`,
       `scni`.`shop_id`        AS `shop_id`,
       `scni`.`order_id`       AS `order_id`,
       `scni`.`order_item_id`  AS `order_item_id`,
       `oi`.`name`             AS `name`,
       `oi`.`name_en`          AS `name_en`,
       `scni`.`amount`         AS `amount`,
       `scni`.`created_at`     AS `create_time`
from (`ordering`.`shop_credit_note_item` `scni`
         left join `ordering`.`order_item` `oi` on ((`scni`.`order_item_id` = `oi`.`id`)));

-- comment on column view_shop_credit_note_item.credit_note_id not supported: CreditNote id

-- comment on column view_shop_credit_note_item.shop_id not supported: 商家id

-- comment on column view_shop_credit_note_item.order_id not supported: 订单id

-- comment on column view_shop_credit_note_item.order_item_id not supported: 订单id

-- comment on column view_shop_credit_note_item.amount not supported: 金额

-- comment on column view_shop_credit_note_item.create_time not supported: 创建时间

