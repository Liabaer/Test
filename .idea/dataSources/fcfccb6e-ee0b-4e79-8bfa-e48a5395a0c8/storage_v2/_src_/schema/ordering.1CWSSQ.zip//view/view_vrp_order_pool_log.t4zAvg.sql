create view view_vrp_order_pool_log as
select `ordering`.`vrp_order_pool_log`.`id`                            AS `id`,
       `ordering`.`vrp_order_pool_log`.`order_id`                      AS `order_id`,
       `ordering`.`vrp_order_pool_log`.`city_id`                       AS `city_id`,
       `ordering`.`vrp_order_pool_log`.`courier_id`                    AS `courier_id`,
       `ordering`.`vrp_order_pool_log`.`courier_un_complete_order_ids` AS `courier_un_complete_order_ids`,
       `ordering`.`vrp_order_pool_log`.`courier_un_complete_order_sum` AS `courier_un_complete_order_sum`,
       `ordering`.`vrp_order_pool_log`.`courier_package`               AS `courier_package`,
       `ordering`.`vrp_order_pool_log`.`batch_number`                  AS `batch_number`,
       `ordering`.`vrp_order_pool_log`.`status`                        AS `status`,
       `ordering`.`vrp_order_pool_log`.`create_time`                   AS `create_time`
from `ordering`.`vrp_order_pool_log`;

-- comment on column view_vrp_order_pool_log.order_id not supported: 订单号

-- comment on column view_vrp_order_pool_log.city_id not supported: 城市id

-- comment on column view_vrp_order_pool_log.courier_id not supported: 分配的骑手id

-- comment on column view_vrp_order_pool_log.courier_un_complete_order_ids not supported: 配送员的身上的订单id

-- comment on column view_vrp_order_pool_log.courier_un_complete_order_sum not supported: 配送员神上的未完成订单总数

-- comment on column view_vrp_order_pool_log.courier_package not supported: 配送员的背包上限

-- comment on column view_vrp_order_pool_log.batch_number not supported: 批次id

-- comment on column view_vrp_order_pool_log.status not supported: 0:未接单 1:已分配 2:分配失败 3：未分配 4:已接单

-- comment on column view_vrp_order_pool_log.create_time not supported: 结束调度时间

