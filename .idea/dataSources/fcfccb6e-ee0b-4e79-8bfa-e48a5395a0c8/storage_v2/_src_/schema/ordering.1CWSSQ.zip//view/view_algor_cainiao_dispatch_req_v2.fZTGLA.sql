create view view_algor_cainiao_dispatch_req_v2 as
select `acdr`.`id`                      AS `id`,
       `acdr`.`des`                     AS `des`,
       `acdr`.`result_code`             AS `result_code`,
       `acdr`.`transaction`             AS `transaction`,
       `acdr`.`status`                  AS `status`,
       `acdr`.`timestamp`               AS `timestamp`,
       `acdr`.`trace_id`                AS `trace_id`,
       `acdr`.`create_time`             AS `create_time`,
       `acdr`.`current_time`            AS `current_time`,
       `acdr`.`req_order_id_list`       AS `req_order_id_list`,
       `acdr`.`req_courier_id_list`     AS `req_courier_id_list`,
       `acdr`.`data_body_dispatch`      AS `data_body_dispatch`,
       `acdr`.`data_body_dispatch_resp` AS `data_body_dispatch_resp`
from `ordering`.`algor_cainiao_dispatch_req` `acdr`;

-- comment on column view_algor_cainiao_dispatch_req_v2.des not supported: 返回信息描述

-- comment on column view_algor_cainiao_dispatch_req_v2.result_code not supported: 返回码

-- comment on column view_algor_cainiao_dispatch_req_v2.transaction not supported: 求解批次ID

-- comment on column view_algor_cainiao_dispatch_req_v2.status not supported: 算法计算状态

-- comment on column view_algor_cainiao_dispatch_req_v2.timestamp not supported: 算法返回时间戳

-- comment on column view_algor_cainiao_dispatch_req_v2.trace_id not supported: 跟踪ID

-- comment on column view_algor_cainiao_dispatch_req_v2.`current_time` not supported: 算法请求时间

-- comment on column view_algor_cainiao_dispatch_req_v2.data_body_dispatch not supported: 派单请求消息体

-- comment on column view_algor_cainiao_dispatch_req_v2.data_body_dispatch_resp not supported: 派单请求返回消息

