create view view_order as
select `o`.`id`                                                                                                    AS `id`,
       `o`.`status`                                                                                                AS `status`,
       `o`.`city_id`                                                                                               AS `city_id`,
       `o`.`user_id`                                                                                               AS `user_id`,
       `o`.`shop_id`                                                                                               AS `shop_id`,
       `o`.`courier_id`                                                                                            AS `courier_id`,
       `o`.`delivery_type`                                                                                         AS `delivery_type`,
       `s`.`name`                                                                                                  AS `shop_name`,
       `s`.`type`                                                                                                  AS `shop_type`,
       if(isnull(`t`.`pay_type`), 2, `t`.`pay_type`)                                                               AS `pay_type`,
       if((`t`.`pay_type` = 2), '货到付款', `t`.`paid_channel_name`)                                                   AS `paid_channel_name`,
       `odb`.`order_fee`                                                                                           AS `order_fee`,
       `odb`.`delivery_fee`                                                                                        AS `delivery_fee`,
       `odb`.`courier_delivery_fee`                                                                                AS `courier_delivery_fee`,
       `odb`.`order_fee_adjust`                                                                                    AS `order_fee_adjust`,
       `odb`.`coupon_fee`                                                                                          AS `coupon_fee`,
       `o`.`delivery_fee_rate`                                                                                     AS `delivery_fee_rate`,
       `odb`.`manage_fee`                                                                                          AS `manage_fee`,
       `uc`.`coupon_id`                                                                                            AS `coupon_id`,
       `cpn`.`name`                                                                                                AS `coupon_name`,
       `cpn`.`discount`                                                                                            AS `coupon_discount`,
       `uc`.`shop_id`                                                                                              AS `coupon_shop_id`,
       `odb`.`commission_fee`                                                                                      AS `commission_fee`,
       `o`.`shop_discount`                                                                                         AS `shop_discount`,
       `o`.`shop_order_fee_discount`                                                                               AS `shop_order_fee_discount`,
       `o`.`delivery_fee_discount`                                                                                 AS `delivery_fee_discount`,
       `t`.`transaction_fee`                                                                                       AS `customer_transaction_fee`,
       `t`.`transaction_fee`                                                                                       AS `transaction_fee`,
       `t`.`transaction_fee_rate`                                                                                  AS `transaction_fee_rate`,
       `o`.`create_time`                                                                                           AS `create_time`,
       `o`.`confirm_time`                                                                                          AS `confirm_time`,
       `o`.`distributing_time`                                                                                     AS `distributing_time`,
       `o`.`deliverying_time`                                                                                      AS `deliverying_time`,
       `o`.`complete_time`                                                                                         AS `complete_time`,
       `o`.`delivery_time`                                                                                         AS `delivery_time`,
       `o`.`is_ready`                                                                                              AS `is_ready`,
       `o`.`goods_ready_time`                                                                                      AS `goods_ready_time`,
       `o`.`src_location`                                                                                          AS `src_location`,
       `o`.`src_location_text`                                                                                     AS `src_location_text`,
       `o`.`location`                                                                                              AS `location`,
       `o`.`location_text`                                                                                         AS `location_text`,
       `o`.`post_code`                                                                                             AS `post_code`,
       `o`.`distance`                                                                                              AS `distance`,
       `o`.`delivery_start_fee`                                                                                    AS `delivery_start_fee`,
       `o`.`delivery_start_km`                                                                                     AS `delivery_start_km`,
       `o`.`delivery_fee_per_km`                                                                                   AS `delivery_fee_per_km`,
       `o`.`limit_time`                                                                                            AS `limit_time`,
       if((`scn`.`id` is not null), 2, if((`ra`.`id` is not null), 1, 0))                                          AS `refund_type`,
       if((`scn`.`id` is not null), `scn`.`amount`,
          if((`ra`.`id` is not null), `ra`.`real_refund_fee`, 0))                                                  AS `refund_fee`,
       if((`scn`.`id` is not null), `scn`.`refund_reason`,
          if((`ra`.`id` is not null), `ra`.`apply_remark`, NULL))                                                  AS `refund_reason`
from (((((((`ordering`.`order` `o` left join `ordering`.`shop` `s` on ((`o`.`shop_id` = `s`.`id`))) left join `ordering`.`trade` `t` on ((`o`.`id` = `t`.`order_id`))) left join `ordering`.`order_discount_balance` `odb` on ((`o`.`id` = `odb`.`order_id`))) left join `ordering`.`user_coupon` `uc` on ((`o`.`id` = `uc`.`order_id`))) left join `ordering`.`coupon` `cpn` on ((`uc`.`coupon_id` = `cpn`.`id`))) left join `ordering`.`shop_credit_note` `scn` on ((`o`.`id` = `scn`.`order_id`)))
         left join `ordering`.`refund_audit` `ra` on ((`o`.`id` = `ra`.`order_id`)))
where (isnull(`scn`.`id`) or (`scn`.`status` = 2));

-- comment on column view_order.courier_delivery_fee not supported: 配送员实际配送费收入，按配送员配送费计算规则得出

-- comment on column view_order.order_fee_adjust not supported: 订单费用调整

-- comment on column view_order.coupon_shop_id not supported: 所属商家ID

-- comment on column view_order.customer_transaction_fee not supported: 交易费用

-- comment on column view_order.transaction_fee not supported: 交易费用

-- comment on column view_order.transaction_fee_rate not supported: 交易费用

-- comment on column view_order.goods_ready_time not supported: 商家出餐时间

