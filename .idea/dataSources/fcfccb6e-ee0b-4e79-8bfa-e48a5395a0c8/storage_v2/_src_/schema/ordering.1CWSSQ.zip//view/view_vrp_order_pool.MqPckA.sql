create view view_vrp_order_pool as
select `ordering`.`vrp_order_pool`.`id`                  AS `id`,
       `ordering`.`vrp_order_pool`.`order_id`            AS `order_id`,
       `ordering`.`vrp_order_pool`.`city_id`             AS `city_id`,
       `ordering`.`vrp_order_pool`.`vrp_status`          AS `vrp_status`,
       `ordering`.`vrp_order_pool`.`distribution_status` AS `distribution_status`,
       `ordering`.`vrp_order_pool`.`create_time`         AS `create_time`,
       `ordering`.`vrp_order_pool`.`update_time`         AS `update_time`,
       `ordering`.`vrp_order_pool`.`group_id`            AS `group_id`
from `ordering`.`vrp_order_pool`;

-- comment on column view_vrp_order_pool.order_id not supported: 订单号

-- comment on column view_vrp_order_pool.city_id not supported: 城市id

-- comment on column view_vrp_order_pool.vrp_status not supported: 0:未求解 1: 求解中 2: 求解失败 3:求解成功 4: 生命周期超时

-- comment on column view_vrp_order_pool.distribution_status not supported: 0: 未分配 1: 接单中 2: 已接单 3: 接单超时

-- comment on column view_vrp_order_pool.create_time not supported: 开始时间

-- comment on column view_vrp_order_pool.update_time not supported: 更新时间

