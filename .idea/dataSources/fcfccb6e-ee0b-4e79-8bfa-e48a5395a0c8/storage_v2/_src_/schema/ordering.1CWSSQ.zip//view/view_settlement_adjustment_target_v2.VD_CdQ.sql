create view view_settlement_adjustment_target_v2 as
select `sat`.`id`                       AS `id`,
       `sat`.`city_id`                  AS `city_id`,
       `sat`.`settlement_adjustment_id` AS `settlement_adjustment_id`,
       `sat`.`target_type`              AS `target_type`,
       `sat`.`target_id`                AS `target_id`,
       `sat`.`target_name`              AS `target_name`
from `ordering`.`settlement_adjustment_target` `sat`;

-- comment on column view_settlement_adjustment_target_v2.settlement_adjustment_id not supported: 调账id

-- comment on column view_settlement_adjustment_target_v2.target_type not supported: 调账对象, courier配送员, shop商家

-- comment on column view_settlement_adjustment_target_v2.target_id not supported: 调账对象id

-- comment on column view_settlement_adjustment_target_v2.target_name not supported: 调账对象名称

