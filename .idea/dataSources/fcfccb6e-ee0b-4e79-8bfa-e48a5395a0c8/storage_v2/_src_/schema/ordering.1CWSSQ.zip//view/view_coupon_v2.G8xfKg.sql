create view view_coupon_v2 as
select `c`.`id`                 AS `id`,
       `c`.`name`               AS `name`,
       `c`.`name_en`            AS `name_en`,
       `c`.`type`               AS `type`,
       `c`.`discount`           AS `discount`,
       `c`.`threshold_fee`      AS `threshold_fee`,
       `c`.`goods`              AS `goods`,
       `c`.`count`              AS `count`,
       `c`.`valid_date`         AS `valid_date`,
       `c`.`valid_type`         AS `valid_type`,
       `c`.`valid_days`         AS `valid_days`,
       `c`.`valid_unit`         AS `valid_unit`,
       `c`.`valid_start_time`   AS `valid_start_time`,
       `c`.`valid_end_time`     AS `valid_end_time`,
       `c`.`send_start_time`    AS `send_start_time`,
       `c`.`send_end_time`      AS `send_end_time`,
       `c`.`send_type`          AS `send_type`,
       `c`.`send_condition`     AS `send_condition`,
       `c`.`status`             AS `status`,
       `c`.`create_time`        AS `create_time`,
       `c`.`update_time`        AS `update_time`,
       `c`.`city_id`            AS `city_id`,
       `c`.`scene_business`     AS `scene_business`,
       `c`.`scene_shop`         AS `scene_shop`,
       `c`.`is_use_time`        AS `is_use_time`,
       `c`.`desc`               AS `desc`,
       `c`.`desc_en`            AS `desc_en`,
       `c`.`platform`           AS `platform`,
       `c`.`created_by`         AS `created_by`,
       `c`.`is_can_manual_send` AS `is_can_manual_send`,
       `c`.`payment_type`       AS `payment_type`,
       `c`.`distance`           AS `distance`,
       `c`.`discount_type`      AS `discount_type`,
       `c`.`discount_max`       AS `discount_max`
from `ordering`.`coupon` `c`;

-- comment on column view_coupon_v2.threshold_fee not supported: 门槛金额

-- comment on column view_coupon_v2.valid_type not supported: 有效期类型

-- comment on column view_coupon_v2.valid_unit not supported: 有效期单位

-- comment on column view_coupon_v2.valid_start_time not supported: 有效期开始时间

-- comment on column view_coupon_v2.valid_end_time not supported: 有效期结束时间

-- comment on column view_coupon_v2.send_start_time not supported: 发券开始时间

-- comment on column view_coupon_v2.send_end_time not supported: 发券结束时间

-- comment on column view_coupon_v2.scene_business not supported: 场景-业务

-- comment on column view_coupon_v2.scene_shop not supported: 场景-商家

-- comment on column view_coupon_v2.is_use_time not supported: 是否有使用时段

-- comment on column view_coupon_v2.`desc` not supported: 优惠券描述

-- comment on column view_coupon_v2.desc_en not supported: 优惠券描述

-- comment on column view_coupon_v2.platform not supported: 送餐平台类型，0: xx送餐 1: 饭来了

-- comment on column view_coupon_v2.created_by not supported: 创建者类型, 0:管理员, 1:系统

-- comment on column view_coupon_v2.is_can_manual_send not supported: 是否可以手动发放

-- comment on column view_coupon_v2.payment_type not supported: 优惠券支付方式

-- comment on column view_coupon_v2.distance not supported: 优惠券距离限制

-- comment on column view_coupon_v2.discount_type not supported: 0(普通),1(折扣)

-- comment on column view_coupon_v2.discount_max not supported: 最大抵扣金额

