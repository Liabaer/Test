create view view_setting as
select `ordering`.`setting`.`id`       AS `id`,
       `ordering`.`setting`.`key`      AS `key`,
       `ordering`.`setting`.`value`    AS `value`,
       `ordering`.`setting`.`value_en` AS `value_en`,
       `ordering`.`setting`.`city_id`  AS `city_id`
from `ordering`.`setting`;

