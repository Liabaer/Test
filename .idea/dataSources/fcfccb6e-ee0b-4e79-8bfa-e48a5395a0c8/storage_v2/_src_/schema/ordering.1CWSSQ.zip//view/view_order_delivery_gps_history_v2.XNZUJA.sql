create view view_order_delivery_gps_history_v2 as
select `odgh`.`id`          AS `id`,
       `odgh`.`order_id`    AS `order_id`,
       `odgh`.`courier_id`  AS `courier_id`,
       `odgh`.`gps_data`    AS `gps_data`,
       `odgh`.`create_time` AS `create_time`,
       `odgh`.`update_time` AS `update_time`
from `ordering`.`order_delivery_gps_history` `odgh`;

-- comment on column view_order_delivery_gps_history_v2.order_id not supported: 订单ID

-- comment on column view_order_delivery_gps_history_v2.courier_id not supported: 配送员ID

-- comment on column view_order_delivery_gps_history_v2.gps_data not supported: gps数据，格式：lat,lng,time|lat,lng,time

