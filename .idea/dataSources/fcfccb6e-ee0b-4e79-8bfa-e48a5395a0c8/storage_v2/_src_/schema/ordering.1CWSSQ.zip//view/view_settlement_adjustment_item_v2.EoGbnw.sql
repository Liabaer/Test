create view view_settlement_adjustment_item_v2 as
select `sai`.`id`              AS `id`,
       `sai`.`city_id`         AS `city_id`,
       `sai`.`name`            AS `name`,
       `sai`.`name_en`         AS `name_en`,
       `sai`.`adjustment_type` AS `adjustment_type`,
       `sai`.`status`          AS `status`,
       `sai`.`create_time`     AS `create_time`,
       `sai`.`update_time`     AS `update_time`
from `ordering`.`settlement_adjustment_item` `sai`;

-- comment on column view_settlement_adjustment_item_v2.name not supported: 项目名称

-- comment on column view_settlement_adjustment_item_v2.name_en not supported: 项目名称英文

-- comment on column view_settlement_adjustment_item_v2.adjustment_type not supported: 调整类型, courier配送员，shop商家

-- comment on column view_settlement_adjustment_item_v2.status not supported: 状态, normal正常, deleted已删除

