create view view_shop_credit_note_item_v2 as
select `scni`.`id`             AS `id`,
       `scni`.`credit_note_id` AS `credit_note_id`,
       `scni`.`shop_id`        AS `shop_id`,
       `scni`.`order_id`       AS `order_id`,
       `scni`.`order_item_id`  AS `order_item_id`,
       `scni`.`amount`         AS `amount`,
       `scni`.`created_at`     AS `created_at`
from `ordering`.`shop_credit_note_item` `scni`;

-- comment on column view_shop_credit_note_item_v2.credit_note_id not supported: CreditNote id

-- comment on column view_shop_credit_note_item_v2.shop_id not supported: 商家id

-- comment on column view_shop_credit_note_item_v2.order_id not supported: 订单id

-- comment on column view_shop_credit_note_item_v2.order_item_id not supported: 订单id

-- comment on column view_shop_credit_note_item_v2.amount not supported: 金额

-- comment on column view_shop_credit_note_item_v2.created_at not supported: 创建时间

