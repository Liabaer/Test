create view view_courier_group_v2 as
select `cg`.`id`           AS `id`,
       `cg`.`name`         AS `name`,
       `cg`.`create_time`  AS `create_time`,
       `cg`.`city_id`      AS `city_id`,
       `cg`.`phone_number` AS `phone_number`
from `ordering`.`courier_group` `cg`;

-- comment on column view_courier_group_v2.phone_number not supported: 分组联系电话

