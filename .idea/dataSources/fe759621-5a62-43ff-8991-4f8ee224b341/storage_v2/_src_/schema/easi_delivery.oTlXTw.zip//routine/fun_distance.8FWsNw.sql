create
    definer = ordering@`%` function fun_distance(lat1 float, lng1 float, lat2 float, lng2 float) returns float
BEGIN
set @num=6378.138*2*ASIN(SQRT(POW(SIN((lat1*PI()/180-lat2*PI()/180)/2),2)+COS(lat1*PI()/180)*COS(lat2*PI()/180)*POW(SIN((lng1*PI()/180-lng2*PI()/180)/2),2)))*1000;
RETURN @num;
END;

